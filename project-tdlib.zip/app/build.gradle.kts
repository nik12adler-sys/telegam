plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// api_id / api_hash come from GitHub secrets (TG_API_ID, TG_API_HASH) at build time.
// Without them the app builds in demo mode, exactly like before.
val tgApiId = System.getenv("TG_API_ID")?.trim()?.toIntOrNull() ?: 0
val tgApiHash = System.getenv("TG_API_HASH")?.trim() ?: ""

android {
    namespace = "com.mahan.mahantgram"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mahan.mahantgram"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.2.0"
        buildConfigField("int", "TG_API_ID", "$tgApiId")
        buildConfigField("String", "TG_API_HASH", "\"$tgApiHash\"")
    }

    // One APK per processor type, plus a universal one.
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a")
            isUniversalApk = true
        }
    }

    signingConfigs {
        create("mahan") {
            storeFile = file("mahan.keystore")
            storePassword = "mahan123"
            keyAlias = "mahan"
            keyPassword = "mahan123"
        }
    }

    buildTypes {
        // The workflow runs assembleDebug, so the debug build is optimized (no debug flag, R8 on)
        // to keep the UI smooth. A fixed key also lets new builds install over old ones.
        debug {
            isDebuggable = false
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("mahan")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("mahan")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("dev.chrisbanes.haze:haze:1.6.10")
    implementation("com.github.tdlibx:td:1.8.56")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("com.airbnb.android:lottie-compose:6.6.2")
}
