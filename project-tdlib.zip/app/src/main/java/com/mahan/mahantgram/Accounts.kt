package com.mahan.mahantgram

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import java.io.File

/**
 * Several accounts on one device. Each account has its own TDLib database folder and only one is
 * connected at a time: switching closes the running TDLib client and starts a new one on the other
 * folder (Td already restarts itself after a close, it just asks this object where the database is).
 */
object Accounts {
    private var sp: SharedPreferences? = null
    private var appCtx: Context? = null
    var slots by mutableStateOf(listOf(0))
        private set
    var active by mutableIntStateOf(0)
        private set
    var loggedIn by mutableStateOf(setOf<Int>())
        private set
    private var pendingRemove = false

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
        val p = ctx.getSharedPreferences("mahan_accounts", Context.MODE_PRIVATE)
        sp = p
        slots = (p.getString("slots", "0") ?: "0").split(",").mapNotNull { it.toIntOrNull() }.ifEmpty { listOf(0) }
        active = p.getInt("active", 0).takeIf { it in slots } ?: slots.first()
        loggedIn = (p.getString("in", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }.toSet()
        // The first account existed before this feature: treat its database as logged in if it exists.
        if (File(ctx.filesDir, "tdlib").exists() && 0 !in loggedIn && p.getString("in", null) == null) loggedIn = setOf(0)
    }

    private fun persist() {
        sp?.edit()?.putString("slots", slots.joinToString(","))?.putInt("active", active)?.putString("in", loggedIn.joinToString(","))?.apply()
    }

    fun label(slot: Int): String = sp?.getString("label_$slot", null)?.takeIf { it.isNotBlank() } ?: "${tr("حساب", "Account")} ${slot + 1}"

    fun dbDir(ctx: Context) = File(ctx.filesDir, if (active == 0) "tdlib" else "tdlib_$active")

    fun filesDir(ctx: Context): File {
        val base = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        return if (active == 0) base else File(base, "acc_$active").also { it.mkdirs() }
    }

    fun markReady(name: String, username: String) {
        sp?.edit()?.putString("label_$active", listOf(name, if (username.isNotEmpty()) "@$username" else "").filter { it.isNotEmpty() }.joinToString(" · "))?.apply()
        loggedIn = loggedIn + active
        persist()
    }

    fun isLoggedIn(slot: Int) = slot in loggedIn

    /** Switch to another account: the running client closes and Td reopens on that account's folder. */
    fun switchTo(slot: Int) {
        if (slot == active || slot !in slots) return
        active = slot
        persist()
        Td.fire(mk("Close"))
    }

    fun addNew() {
        val n = (slots.maxOrNull() ?: 0) + 1
        slots = slots + n
        active = n
        persist()
        Td.fire(mk("Close"))
    }

    /** The new (not yet logged in) account was abandoned: forget it and go back to a real one. */
    fun cancelAdd() {
        val dead = active
        val back = slots.firstOrNull { it != dead && it in loggedIn } ?: slots.firstOrNull { it != dead } ?: return
        removeFiles(dead)
        slots = slots - dead
        loggedIn = loggedIn - dead
        active = back
        persist()
        Td.fire(mk("Close"))
    }

    /** Called when the active account is logging out. Extra accounts disappear from the list afterwards. */
    fun onLogoutRequested() { pendingRemove = true }

    /** Called by Td after the client closed (on the main thread) and before it starts again. */
    fun afterClosed() {
        if (!pendingRemove) return
        pendingRemove = false
        val dead = active
        loggedIn = loggedIn - dead
        sp?.edit()?.remove("label_$dead")?.apply()
        if (slots.size > 1) {
            removeFiles(dead)
            slots = slots - dead
            active = slots.firstOrNull { it in loggedIn } ?: slots.first()
        }
        persist()
    }

    private fun removeFiles(slot: Int) {
        val c = appCtx ?: return
        if (slot == 0) return
        File(c.filesDir, "tdlib_$slot").deleteRecursively()
        File(c.getExternalFilesDir(null) ?: c.filesDir, "acc_$slot").deleteRecursively()
    }
}

/** Shown above the login screen of a freshly added account so the user can go back. */
@Composable
fun AddAccountCancelOverlay() {
    if (Accounts.slots.size < 2 || Accounts.isLoggedIn(Accounts.active)) return
    Box(Modifier.fillMaxSize().statusBarsPadding().padding(8.dp), contentAlignment = Alignment.TopStart) {
        TextButton(onClick = { Accounts.cancelAdd() }) { Text(tr("بازگشت به حساب قبلی", "Back to previous account")) }
    }
}

@Composable
internal fun AccountsPage(onBack: () -> Unit) {
    var confirmSwitch by remember { mutableStateOf<Int?>(null) }
    var confirmAdd by remember { mutableStateOf(false) }
    SPage(tr("حساب‌ها", "Accounts"), onBack) {
        SNote(tr("هر حساب اطلاعات جدا دارد. در هر لحظه یک حساب متصل است و با تعویض، برنامه به حساب دیگر وصل می‌شود.", "Each account keeps its own data. One account is connected at a time; switching reconnects the app to the other one."))
        Accounts.slots.forEach { slot ->
            val isActive = slot == Accounts.active
            val name = if (isActive) (Td.me?.name?.takeIf { it.isNotEmpty() } ?: Accounts.label(slot)) else Accounts.label(slot)
            SValueRow(name, if (isActive) tr("فعال ✓", "Active ✓") else if (Accounts.isLoggedIn(slot)) tr("تعویض", "Switch") else tr("وارد نشده", "Not signed in")) {
                if (!isActive && Accounts.isLoggedIn(slot)) confirmSwitch = slot
            }
        }
        SValueRow(tr("افزودن حساب", "Add account"), "+") { confirmAdd = true }
    }
    confirmSwitch?.let { slot ->
        ConfirmDialog(tr("به این حساب تعویض می‌کنید؟", "Switch to this account?"), tr("تعویض", "Switch"), { confirmSwitch = null }) { confirmSwitch = null; Accounts.switchTo(slot) }
    }
    if (confirmAdd) ConfirmDialog(tr("برای افزودن حساب جدید باید وارد شوید. حساب فعلی قطع می‌شود ولی داده‌اش می‌ماند.", "You will sign in to a new account. The current one disconnects but keeps its data."), tr("ادامه", "Continue"), { confirmAdd = false }) { confirmAdd = false; Accounts.addNew() }
}
