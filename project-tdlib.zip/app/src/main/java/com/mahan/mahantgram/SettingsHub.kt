package com.mahan.mahantgram

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material.icons.rounded.EmojiEmotions
import androidx.compose.material.icons.rounded.Help
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

/*
 * Full Telegram-style settings. It is reachable ONLY from the Settings tab (one row there) and
 * everything inside talks to real TDLib requests. Requests are built with mk() (by class name) like
 * the rest of the project, so a renamed TDLib field never breaks the build, only that one request.
 */

internal val Red = Color(0xFFFF6B6B)

@Composable
fun SettingsHub(cb: HubCallbacks, onBack: () -> Unit, onProxy: () -> Unit, onPremium: () -> Unit, onProfile: () -> Unit) {
    var page by rememberSaveable { mutableStateOf("root") }
    BackHandler(enabled = page != "root") { page = "root" }
    val back = { if (page == "root") onBack() else page = "root" }
    when (page) {
        "account" -> AccountPage(back, onProfile)
        "privacy" -> PrivacyPage(back, { page = "devices" }) { page = it }
        "blocked" -> BlockedPage { page = "privacy" }
        "notif" -> NotificationsPage(back)
        "data" -> DataPage(back)
        "help" -> HelpPage(back)
        "chat" -> ChatSettingsPage(back)
        "devices" -> DevicesPage(back)
        "lang" -> LanguagePage(cb, back)
        "look" -> AppearancePage(cb, back)
        "adv" -> AdvancedPage(back, onProxy)
        "accounts" -> AccountsPage(back)
        "stick" -> StickersPage(back)
        "prem" -> PremiumSettingsPage(back, onPremium)
        else -> SPage(tr("تنظیمات کامل", "All settings"), onBack) {
            SNavRow(Icons.Rounded.Person, tr("حساب‌ها (چند حساب)", "Accounts"), tr("تعویض و افزودن حساب", "Switch and add accounts")) { page = "accounts" }
            SNavRow(Icons.Rounded.Person, tr("حساب کاربری", "Account"), tr("نام، بیو، نام کاربری، شماره", "Name, bio, username, phone")) { page = "account" }
            SNavRow(Icons.Rounded.Lock, tr("حریم خصوصی و امنیت", "Privacy and security"), tr("آخرین بازدید، عکس، رمز دومرحله‌ای، حذف خودکار", "Last seen, photo, two-step, auto-delete")) { page = "privacy" }
            SNavRow(Icons.Rounded.Notifications, tr("اعلان‌ها", "Notifications"), tr("چت‌های خصوصی، گروه‌ها، کانال‌ها", "Private chats, groups, channels")) { page = "notif" }
            SNavRow(Icons.Rounded.Storage, tr("داده و حافظه", "Data and storage"), tr("حافظه، کش، دانلود خودکار، مصرف شبکه", "Storage, cache, auto-download, network usage")) { page = "data" }
            SNavRow(Icons.Rounded.ChatBubble, tr("تنظیمات گفتگو", "Chat settings"), tr("اندازه‌ی متن، گوشه‌ها، ارسال با Enter، واکنش", "Text size, corners, send by Enter, reaction")) { page = "chat" }
            SNavRow(Icons.Rounded.Devices, tr("دستگاه‌ها", "Devices"), tr("نشست‌های فعال و پایان نشست", "Active sessions and terminate")) { page = "devices" }
            SNavRow(Icons.Rounded.Language, tr("زبان", "Language"), tr("فارسی، English، Русский، Deutsch، Français", "Persian, English, Russian, German, French")) { page = "lang" }
            SNavRow(Icons.Rounded.Palette, tr("ظاهر", "Appearance"), tr("تم، AMOLED، رنگ، طرح پس‌زمینه", "Theme, AMOLED, color, background")) { page = "look" }
            SNavRow(Icons.Rounded.Tune, tr("تنظیمات پیشرفته", "Advanced"), tr("پروکسی، وضعیت اتصال، تشخیص شبکه", "Proxy, connection, diagnostics")) { page = "adv" }
            SNavRow(Icons.Rounded.EmojiEmotions, tr("استیکر و ایموجی", "Stickers and emoji"), tr("بسته‌ها، آرشیو، پرطرفدار", "Packs, archive, trending")) { page = "stick" }
            SNavRow(Icons.Rounded.Star, "Premium", tr("وضعیت و امکانات", "Status and features")) { page = "prem" }
            SNavRow(Icons.Rounded.Help, tr("راهنما", "Help"), tr("سوالات متداول، قوانین، نسخه", "FAQ, policies, version")) { page = "help" }
        }
    }
}

// ============================================================ Account

@Composable
private fun AccountPage(onBack: () -> Unit, onProfile: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var first by remember { mutableStateOf("") }
    var last by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    var dlg by remember { mutableStateOf("") }
    LaunchedEffect(tick) {
        runCatching {
            val me = Td.req(mk<TdApi.Object>("GetMe"))
            first = me.fieldOrNull("firstName") as? String ?: ""
            last = me.fieldOrNull("lastName") as? String ?: ""
            user = (me.fieldOrNull("usernames")?.fieldOrNull("editableUsername") as? String) ?: ""
            val full = Td.req(mk<TdApi.Object>("GetUserFullInfo", "userId" to Td.meId))
            val b = full.fieldOrNull("bio")
            bio = (b as? TdApi.FormattedText)?.text ?: (b as? String) ?: ""
        }
    }
    SPage(tr("حساب کاربری", "Account"), onBack) {
        SNavRow(Icons.Rounded.Person, tr("عکس پروفایل", "Profile photo"), tr("تغییر از صفحه‌ی پروفایل", "Change it on the profile page"), onProfile)
        SValueRow(tr("نام", "Name"), (first + " " + last).trim().ifEmpty { "—" }) { dlg = "name" }
        SValueRow(tr("بیو", "Bio"), bio.ifEmpty { tr("تنظیم نشده", "Not set") }) { dlg = "bio" }
        SValueRow(tr("نام کاربری", "Username"), if (user.isEmpty()) tr("تنظیم نشده", "Not set") else "@$user") { dlg = "user" }
        SValueRow(tr("شماره تلفن", "Phone number"), Td.me?.phone?.let { if (it.isEmpty()) "—" else "+$it" } ?: "—") { dlg = "phone" }
        SDanger(tr("خروج از حساب", "Log out")) { dlg = "logout" }
        SDanger(tr("حذف حساب کاربری", "Delete my account")) { dlg = "delete" }
    }
    when (dlg) {
        "name" -> TwoFieldDialog(tr("تغییر نام", "Change name"), tr("نام", "First name"), first, tr("نام خانوادگی", "Last name"), last, { dlg = "" }) { f, l ->
            scope.launch {
                val e = Td.tryReq(mk("SetName", "firstName" to f.trim(), "lastName" to l.trim()))
                if (e != null) toast(ctx, e) else { dlg = ""; tick++ }
            }
        }
        "bio" -> OneFieldDialog(tr("بیو", "Bio"), bio, 70, { dlg = "" }) { v ->
            scope.launch {
                val e = Td.tryReq(mk("SetBio", "bio" to v.trim()))
                if (e != null) toast(ctx, e) else { dlg = ""; tick++ }
            }
        }
        "user" -> OneFieldDialog(tr("نام کاربری (بدون @)", "Username (without @)"), user, 32, { dlg = "" }) { v ->
            scope.launch {
                val e = Td.tryReq(mk("SetUsername", "username" to v.trim().removePrefix("@")))
                if (e != null) toast(ctx, e) else { dlg = ""; tick++ }
            }
        }
        "logout" -> ConfirmDialog(tr("از حساب خارج می‌شوید؟", "Log out of this account?"), tr("خروج", "Log out"), { dlg = "" }) { dlg = ""; Td.logOut() }
        "delete" -> DeleteAccountDialog({ dlg = "" }, ctx)
        "phone" -> ChangePhoneDialog({ dlg = "" }, ctx)
    }
}

@Composable
private fun DeleteAccountDialog(onDismiss: () -> Unit, ctx: android.content.Context) {
    val scope = rememberCoroutineScope()
    var pw by remember { mutableStateOf("") }
    var typed by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("حذف دائمی حساب", "Delete account permanently")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("همه‌ی پیام‌ها و مخاطبین برای همیشه پاک می‌شوند و قابل بازگشت نیست. برای ادامه DELETE را تایپ کنید.", "All messages and contacts will be erased forever. Type DELETE to continue."))
                OutlinedTextField(typed, { typed = it }, singleLine = true)
                OutlinedTextField(pw, { pw = it }, singleLine = true, label = { Text(tr("رمز دومرحله‌ای (در صورت وجود)", "Two-step password (if set)")) }, visualTransformation = PasswordVisualTransformation())
            }
        },
        confirmButton = {
            TextButton(enabled = typed == "DELETE", onClick = {
                scope.launch {
                    val e = Td.tryReq(mk("DeleteAccount", "reason" to "", "password" to pw))
                    if (e != null) toast(ctx, e) else onDismiss()
                }
            }) { Text(tr("حذف", "Delete"), color = Red) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}

// ============================================================ Privacy and security

private data class PrivacyItem(val setting: String, val fa: String, val en: String)

private val PRIVACY_ITEMS = listOf(
    PrivacyItem("UserPrivacySettingShowStatus", "آخرین بازدید و آنلاین", "Last seen and online"),
    PrivacyItem("UserPrivacySettingShowProfilePhoto", "عکس پروفایل", "Profile photos"),
    PrivacyItem("UserPrivacySettingShowBio", "بیو", "Bio"),
    PrivacyItem("UserPrivacySettingShowPhoneNumber", "شماره تلفن", "Phone number"),
    PrivacyItem("UserPrivacySettingAllowFindingByPhoneNumber", "چه کسی با شماره‌ام پیدایم کند", "Who can find me by my number"),
    PrivacyItem("UserPrivacySettingShowLinkInForwardedMessages", "پیام‌های فوروارد شده", "Forwarded messages"),
    PrivacyItem("UserPrivacySettingAllowCalls", "تماس‌ها", "Calls"),
    PrivacyItem("UserPrivacySettingAllowChatInvites", "گروه‌ها و کانال‌ها", "Groups and channels"),
)

private fun levelText(l: Int) = when (l) {
    0 -> tr("همه", "Everybody")
    1 -> tr("مخاطبین من", "My contacts")
    2 -> tr("هیچ‌کس", "Nobody")
    else -> tr("سفارشی", "Custom")
}

private fun ruleArray(vararg names: String): Any {
    val base = Class.forName("org.drinkless.tdlib.TdApi\$UserPrivacySettingRule")
    val arr = java.lang.reflect.Array.newInstance(base, names.size)
    names.forEachIndexed { i, n -> java.lang.reflect.Array.set(arr, i, mk<TdApi.Object>(n)) }
    return arr
}

private suspend fun privacyLevel(setting: String): Int = runCatching {
    val r = Td.req(mk<TdApi.Object>("GetUserPrivacySettingRules", "setting" to mk<TdApi.Object>(setting)))
    val first = (r.fieldOrNull("rules") as? Array<*>)?.firstOrNull()?.javaClass?.simpleName ?: return@runCatching 2
    when {
        first.endsWith("AllowAll") -> 0
        first.endsWith("AllowContacts") -> 1
        first.endsWith("RestrictAll") -> 2
        else -> 3
    }
}.getOrDefault(0)

private suspend fun setPrivacyLevel(setting: String, level: Int): String? {
    val rules = when (level) {
        0 -> ruleArray("UserPrivacySettingRuleAllowAll")
        1 -> ruleArray("UserPrivacySettingRuleAllowContacts", "UserPrivacySettingRuleRestrictAll")
        else -> ruleArray("UserPrivacySettingRuleRestrictAll")
    }
    return Td.tryReq(mk("SetUserPrivacySettingRules", "setting" to mk<TdApi.Object>(setting), "rules" to mk<TdApi.Object>("UserPrivacySettingRules", "rules" to rules)))
}

@Composable
private fun PrivacyPage(onBack: () -> Unit, onSessions: () -> Unit, go: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var levels by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var pick by remember { mutableStateOf<PrivacyItem?>(null) }
    var ttl by remember { mutableIntStateOf(0) }
    var hasPw by remember { mutableStateOf(false) }
    var blockedCount by remember { mutableIntStateOf(0) }
    var dlg by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        levels = PRIVACY_ITEMS.associate { it.setting to privacyLevel(it.setting) }
        ttl = runCatching { (Td.req(mk<TdApi.Object>("GetAccountTtl")).fieldOrNull("days") as? Int) ?: 0 }.getOrDefault(0)
        hasPw = runCatching { Td.req(mk<TdApi.Object>("GetPasswordState")).fieldOrNull("hasPassword") == true }.getOrDefault(false)
        blockedCount = runCatching {
            (Td.req(mk<TdApi.Object>("GetBlockedMessageSenders", "offset" to 0, "limit" to 1)).fieldOrNull("totalCount") as? Int) ?: 0
        }.getOrDefault(0)
    }
    SPage(tr("حریم خصوصی و امنیت", "Privacy and security"), onBack) {
        SHeader(tr("چه کسی می‌تواند", "Who can"))
        PRIVACY_ITEMS.forEach { it -> SValueRow(tr(it.fa, it.en), levelText(levels[it.setting] ?: 0)) { pick = it } }
        SHeader(tr("امنیت", "Security"))
        SValueRow(tr("کاربران مسدود", "Blocked users"), blockedCount.toString()) { go("blocked") }
        SValueRow(tr("رمز دومرحله‌ای", "Two-step verification"), if (hasPw) tr("روشن", "On") else tr("خاموش", "Off")) { dlg = "twostep" }
        PasscodeRows()
        SNavRow(Icons.Rounded.Lock, tr("نشست‌های فعال و دستگاه‌ها", "Active sessions and devices"), "", onSessions)
        SValueRow(tr("حذف خودکار حساب", "Auto-delete account"), if (ttl == 0) "—" else ttlText(ttl)) { dlg = "ttl" }
    }
    pick?.let { item ->
        val cur = levels[item.setting] ?: 0
        RadioDialog(
            tr(item.fa, item.en),
            listOf(levelText(0), levelText(1), levelText(2)),
            cur, { pick = null },
        ) { i ->
            pick = null
            scope.launch {
                val e = setPrivacyLevel(item.setting, i)
                if (e != null) toast(ctx, e) else tick++
            }
        }
    }
    if (dlg == "ttl") {
        val opts = listOf(30, 90, 180, 365)
        RadioDialog(tr("حذف خودکار حساب در صورت عدم فعالیت", "Delete account if away for"), opts.map { ttlText(it) }, opts.indexOf(ttl), { dlg = "" }) { i ->
            dlg = ""
            scope.launch {
                val e = Td.tryReq(mk("SetAccountTtl", "ttl" to mk<TdApi.Object>("AccountTtl", "days" to opts[i])))
                if (e != null) toast(ctx, e) else tick++
            }
        }
    }
    if (dlg == "twostep") TwoStepDialog(hasPw, { dlg = "" }, ctx) { dlg = ""; tick++ }
}

private fun ttlText(days: Int) = when (days) {
    30 -> tr("۱ ماه", "1 month")
    90 -> tr("۳ ماه", "3 months")
    180 -> tr("۶ ماه", "6 months")
    365 -> tr("۱ سال", "1 year")
    else -> trf("{0} روز", "{0} days", days)
}

@Composable
private fun TwoStepDialog(hasPassword: Boolean, onDismiss: () -> Unit, ctx: android.content.Context, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var old by remember { mutableStateOf("") }
    var new by remember { mutableStateOf("") }
    var hint by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("رمز دومرحله‌ای", "Two-step verification")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (hasPassword) OutlinedTextField(old, { old = it }, singleLine = true, label = { Text(tr("رمز فعلی", "Current password")) }, visualTransformation = PasswordVisualTransformation())
                OutlinedTextField(new, { new = it }, singleLine = true, label = { Text(tr("رمز جدید (خالی = حذف رمز)", "New password (empty = remove)")) }, visualTransformation = PasswordVisualTransformation())
                if (new.isNotEmpty()) OutlinedTextField(hint, { hint = it }, singleLine = true, label = { Text(tr("راهنمای رمز", "Hint")) })
            }
        },
        confirmButton = {
            TextButton(enabled = new.isNotEmpty() || hasPassword, onClick = {
                scope.launch {
                    val e = Td.tryReq(
                        mk("SetPassword", "oldPassword" to old, "newPassword" to new, "newHint" to hint, "setRecoveryEmailAddress" to false, "newRecoveryEmailAddress" to ""),
                    )
                    if (e != null) toast(ctx, e) else onDone()
                }
            }) { Text(tr("ذخیره", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}

@Composable
private fun BlockedPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<Pair<Long, String>>>(emptyList()) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        list = runCatching {
            val r = Td.req(mk<TdApi.Object>("GetBlockedMessageSenders", "offset" to 0, "limit" to 100))
            (r.fieldOrNull("senders") as? Array<*>).orEmpty().mapNotNull { s ->
                val uid = s?.fieldOrNull("userId") as? Long ?: return@mapNotNull null
                val u = runCatching { Td.req(mk<TdApi.Object>("GetUser", "userId" to uid)) }.getOrNull()
                uid to (((u?.fieldOrNull("firstName") as? String ?: "") + " " + (u?.fieldOrNull("lastName") as? String ?: "")).trim().ifEmpty { uid.toString() })
            }
        }.getOrDefault(emptyList())
    }
    SPage(tr("کاربران مسدود", "Blocked users"), onBack) {
        if (list.isEmpty()) SNote(tr("کاربر مسدودی وجود ندارد.", "No blocked users."))
        list.forEach { (id, name) ->
            SValueRow(name, tr("برای رفع مسدودی بزنید", "Tap to unblock")) {
                scope.launch {
                    val sender = mk<TdApi.Object>("MessageSenderUser", "userId" to id)
                    val e = Td.tryReq(mk("SetMessageSenderBlockList", "senderId" to sender, "blockList" to null))
                    if (e != null) toast(ctx, e) else tick++
                }
            }
        }
    }
}

// ============================================================ Notifications

private data class Scope(val cls: String, val fa: String, val en: String)

private val SCOPES = listOf(
    Scope("NotificationSettingsScopePrivateChats", "چت‌های خصوصی", "Private chats"),
    Scope("NotificationSettingsScopeGroupChats", "گروه‌ها", "Groups"),
    Scope("NotificationSettingsScopeChannelChats", "کانال‌ها", "Channels"),
)

private suspend fun scopeGet(s: Scope): Any? = runCatching { Td.req(mk<TdApi.Object>("GetScopeNotificationSettings", "scope" to mk<TdApi.Object>(s.cls))) }.getOrNull()

internal fun Any.setF(name: String, v: Any?) { runCatching { javaClass.getField(name).set(this, v) } }

private suspend fun scopeSet(s: Scope, obj: Any): String? = Td.tryReq(mk("SetScopeNotificationSettings", "scope" to mk<TdApi.Object>(s.cls), "notificationSettings" to obj))

@Composable
private fun NotificationsPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    var data by remember { mutableStateOf<Map<String, Any?>>(emptyMap()) }
    var contactJoined by remember { mutableStateOf(true) }
    var confirmReset by remember { mutableStateOf(false) }
    LaunchedEffect(tick) {
        data = SCOPES.associate { it.cls to scopeGet(it) }
        contactJoined = runCatching {
            val o = Td.req(mk<TdApi.Object>("GetOption", "name" to "disable_contact_registered_notifications"))
            (o.fieldOrNull("value") as? Boolean) != true
        }.getOrDefault(true)
    }
    SPage(tr("اعلان‌ها", "Notifications"), onBack) {
        SCOPES.forEach { sc ->
            val cur = data[sc.cls]
            SHeader(tr(sc.fa, sc.en))
            if (cur == null) { SNote(tr("در حال بارگذاری…", "Loading…")); return@forEach }
            val on = ((cur.fieldOrNull("muteFor") as? Int) ?: 0) == 0
            val preview = cur.fieldOrNull("showPreview") as? Boolean ?: true
            val pinnedOff = cur.fieldOrNull("disablePinnedMessageNotifications") as? Boolean ?: false
            val mentionOff = cur.fieldOrNull("disableMentionNotifications") as? Boolean ?: false
            fun edit(name: String, v: Any) = scope.launch {
                cur.setF(name, v)
                val e = scopeSet(sc, cur)
                if (e != null) toast(ctx, e)
                tick++
            }
            SSwitchRow(tr("اعلان‌ها", "Notifications"), tr("اعلان پیام‌های جدید", "Alerts for new messages"), on) { edit("muteFor", if (it) 0 else 31622400) }
            SSwitchRow(tr("پیش‌نمایش پیام", "Message preview"), tr("نمایش متن پیام در اعلان", "Show message text in alerts"), preview) { edit("showPreview", it) }
            SSwitchRow(tr("اعلان پیام سنجاق‌شده", "Pinned message alerts"), "", !pinnedOff) { edit("disablePinnedMessageNotifications", !it) }
            SSwitchRow(tr("اعلان منشن‌ها", "Mention alerts"), "", !mentionOff) { edit("disableMentionNotifications", !it) }
        }
        SHeader(tr("سایر", "Other"))
        SSwitchRow(tr("عضو شدن مخاطب در تلگرام", "Contact joined Telegram"), tr("اعلان وقتی مخاطبی عضو می‌شود", "Alert when a contact signs up"), contactJoined) {
            scope.launch {
                val e = Td.tryReq(mk("SetOption", "name" to "disable_contact_registered_notifications", "value" to mk<TdApi.Object>("OptionValueBoolean", "value" to !it)))
                if (e != null) toast(ctx, e)
                tick++
            }
        }
        SDanger(tr("بازنشانی همه‌ی تنظیمات اعلان", "Reset all notification settings")) { confirmReset = true }
    }
    if (confirmReset) ConfirmDialog(tr("همه‌ی تنظیمات اعلان (حتی هر چت) به حالت پیش‌فرض برمی‌گردد.", "Every notification setting, including per-chat ones, returns to default."), tr("بازنشانی", "Reset"), { confirmReset = false }) {
        confirmReset = false
        scope.launch { Td.tryReq(mk("ResetAllNotificationSettings"))?.let { toast(ctx, it) }; tick++ }
    }
}

// ============================================================ Data and storage

internal fun fmtBytes(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024L * 1024 -> "${b / 1024} KB"
    b < 1024L * 1024 * 1024 -> String.format("%.1f MB", b / 1048576.0)
    else -> String.format("%.2f GB", b / 1073741824.0)
}

private fun sumEntries(stats: Any?, field: String): Long =
    (stats?.fieldOrNull("entries") as? Array<*>).orEmpty().sumOf { (it?.fieldOrNull(field) as? Long) ?: 0L }

@Composable
private fun DataPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("settings_hub", android.content.Context.MODE_PRIVATE) }
    var tick by remember { mutableIntStateOf(0) }
    var files by remember { mutableStateOf(0L) }
    var db by remember { mutableStateOf(0L) }
    var sent by remember { mutableStateOf(0L) }
    var recv by remember { mutableStateOf(0L) }
    var dlg by remember { mutableStateOf("") }
    val nets = listOf("NetworkTypeMobile" to tr("داده‌ی همراه", "Mobile data"), "NetworkTypeWiFi" to tr("وای‌فای", "Wi-Fi"), "NetworkTypeMobileRoaming" to tr("رومینگ", "Roaming"))
    var netTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        runCatching {
            val st = Td.req(mk<TdApi.Object>("GetStorageStatisticsFast"))
            files = st.fieldOrNull("filesSize") as? Long ?: 0L
            db = st.fieldOrNull("databaseSize") as? Long ?: 0L
        }
        runCatching {
            val ns = Td.req(mk<TdApi.Object>("GetNetworkStatistics", "onlyCurrent" to false))
            sent = sumEntries(ns, "sentBytes"); recv = sumEntries(ns, "receivedBytes")
        }
    }
    // Pushes the saved choice to TDLib (which does the real downloading).
    fun applyAutoDownload(net: String) {
        val key = "ad_$net"
        val on = prefs.getBoolean("${key}_on", true)
        val photoMb = prefs.getInt("${key}_photo", 10)
        val videoMb = prefs.getInt("${key}_video", 10)
        val fileMb = prefs.getInt("${key}_file", 3)
        val st = mk<TdApi.Object>(
            "AutoDownloadSettings",
            "isAutoDownloadEnabled" to on,
            "maxPhotoFileSize" to photoMb * 1048576,
            "maxVideoFileSize" to videoMb.toLong() * 1048576,
            "maxOtherFileSize" to fileMb.toLong() * 1048576,
            "videoUploadBitrate" to 0,
            "preloadLargeVideos" to false,
            "preloadNextAudio" to false,
            "preloadStories" to false,
            "useLessDataForCalls" to false,
        )
        scope.launch { Td.tryReq(mk("SetAutoDownloadSettings", "settings" to st, "type" to mk<TdApi.Object>(net)))?.let { toast(ctx, it) } }
    }
    SPage(tr("داده و حافظه", "Data and storage"), onBack) {
        SHeader(tr("حافظه", "Storage"))
        SValueRow(tr("فایل‌های ذخیره‌شده", "Cached files"), fmtBytes(files), null)
        SValueRow(tr("پایگاه داده", "Database"), fmtBytes(db), null)
        SDanger(tr("پاک کردن کش", "Clear cache")) { dlg = "cache" }
        SHeader(tr("دانلود خودکار رسانه", "Automatic media download"))
        nets.forEach { (net, label) ->
            val key = "ad_$net"
            key(netTick) {
                SSwitchRow(label, tr("دانلود خودکار عکس، ویدیو و فایل", "Auto-download photos, videos, files"), prefs.getBoolean("${key}_on", net != "NetworkTypeMobileRoaming")) {
                    prefs.edit().putBoolean("${key}_on", it).apply(); applyAutoDownload(net); netTick++
                }
                val photo = prefs.getInt("${key}_photo", 10)
                SValueRow(tr("حداکثر حجم عکس", "Max photo size"), "$photo MB") {
                    prefs.edit().putInt("${key}_photo", nextOf(photo, listOf(1, 5, 10, 20))).apply(); applyAutoDownload(net); netTick++
                }
                val video = prefs.getInt("${key}_video", 10)
                SValueRow(tr("حداکثر حجم ویدیو", "Max video size"), "$video MB") {
                    prefs.edit().putInt("${key}_video", nextOf(video, listOf(5, 10, 50, 100))).apply(); applyAutoDownload(net); netTick++
                }
                val file = prefs.getInt("${key}_file", 3)
                SValueRow(tr("حداکثر حجم فایل", "Max file size"), "$file MB") {
                    prefs.edit().putInt("${key}_file", nextOf(file, listOf(1, 3, 10, 50))).apply(); applyAutoDownload(net); netTick++
                }
            }
        }
        SHeader(tr("مصرف شبکه", "Network usage"))
        SValueRow(tr("ارسال‌شده", "Sent"), fmtBytes(sent), null)
        SValueRow(tr("دریافت‌شده", "Received"), fmtBytes(recv), null)
        SDanger(tr("بازنشانی آمار", "Reset statistics")) { dlg = "stats" }
    }
    if (dlg == "cache") ConfirmDialog(tr("فایل‌های کش‌شده پاک می‌شوند (پیام‌ها می‌مانند و دوباره دانلود می‌شوند).", "Cached files will be deleted (messages stay and re-download on demand)."), tr("پاک کردن", "Clear"), { dlg = "" }) {
        dlg = ""
        scope.launch {
            val e = Td.tryReq(mk("OptimizeStorage", "size" to 0L, "ttl" to -1, "count" to -1, "immunityDelay" to -1, "returnDeletedFileStatistics" to false, "chatLimit" to 0))
            if (e != null) toast(ctx, e)
            tick++
        }
    }
    if (dlg == "stats") ConfirmDialog(tr("آمار مصرف شبکه صفر می‌شود.", "Network usage counters will be zeroed."), tr("بازنشانی", "Reset"), { dlg = "" }) {
        dlg = ""
        scope.launch { Td.tryReq(mk("ResetNetworkStatistics"))?.let { toast(ctx, it) }; tick++ }
    }
}

private fun nextOf(cur: Int, opts: List<Int>): Int = opts[(opts.indexOf(cur) + 1).mod(opts.size)]

// ============================================================ Help

@Composable
private fun HelpPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    fun open(url: String) = runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    SPage(tr("راهنما", "Help"), onBack) {
        SValueRow(tr("سوالات متداول تلگرام", "Telegram FAQ"), "telegram.org/faq") { open("https://telegram.org/faq") }
        SValueRow(tr("گزارش مشکل", "Report a problem"), "telegram.org/support") { open("https://telegram.org/support") }
        SValueRow(tr("سیاست حریم خصوصی", "Privacy policy"), "telegram.org/privacy") { open("https://telegram.org/privacy") }
        SValueRow(tr("شرایط استفاده", "Terms of service"), "telegram.org/tos") { open("https://telegram.org/tos") }
        SValueRow(tr("نسخه‌ی برنامه", "App version"), BuildConfig.VERSION_NAME, null)
    }
}

// ============================================================ shared building blocks

@Composable
internal fun SPage(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    val c = LocalMahan.current
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BackButton(onBack)
            Text(title, color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        content()
        Spacer(Modifier.size(24.dp))
    }
}

@Composable
internal fun SHeader(text: String) {
    Text(text, color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp, start = 4.dp))
}

@Composable
internal fun SNote(text: String) {
    val c = LocalMahan.current
    Text(text, color = c.subtext, fontSize = 13.sp, modifier = Modifier.padding(4.dp))
}

@Composable
internal fun SRowBase(onClick: (() -> Unit)?, content: @Composable RowScope.() -> Unit) {
    val c = LocalMahan.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(c.glassTint.copy(alpha = 0.35f))
            .let { if (onClick != null) it.clickable(onClick = onClick) else it }.padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) { content() }
}

@Composable
internal fun SNavRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    val c = LocalMahan.current
    SRowBase(onClick) {
        Box(Modifier.size(38.dp).clip(CircleShape).background(Green.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Green, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = c.text, fontSize = 16.sp)
            if (sub.isNotEmpty()) Text(sub, color = c.subtext, fontSize = 12.sp)
        }
        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = Green)
    }
}

@Composable
internal fun SValueRow(title: String, value: String, onClick: (() -> Unit)? = {}) {
    val c = LocalMahan.current
    SRowBase(onClick) {
        Text(title, color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        Text(value, color = c.subtext, fontSize = 14.sp, maxLines = 1)
    }
}

@Composable
internal fun SSwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalMahan.current
    SRowBase({ onChange(!checked) }) {
        Column(Modifier.weight(1f)) {
            Text(title, color = c.text, fontSize = 16.sp)
            if (sub.isNotEmpty()) Text(sub, color = c.subtext, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedTrackColor = Green, checkedThumbColor = Color.White))
    }
}

@Composable
internal fun SDanger(text: String, onClick: () -> Unit) {
    SRowBase(onClick) { Text(text, color = Red, fontSize = 16.sp) }
}

@Composable
internal fun RadioDialog(title: String, options: List<String>, selected: Int, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                options.forEachIndexed { i, label ->
                    Row(Modifier.fillMaxWidth().clickable { onPick(i) }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = i == selected, onClick = { onPick(i) })
                        Text(label)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}

@Composable
internal fun ConfirmDialog(text: String, action: String, onDismiss: () -> Unit, onOk: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onOk) { Text(action, color = Red) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}

@Composable
internal fun OneFieldDialog(label: String, initial: String, max: Int, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(label) },
        text = { OutlinedTextField(v, { if (it.length <= max) v = it }, singleLine = false) },
        confirmButton = { TextButton(onClick = { onOk(v) }) { Text(tr("ذخیره", "Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}

@Composable
internal fun TwoFieldDialog(title: String, l1: String, v1: String, l2: String, v2: String, onDismiss: () -> Unit, onOk: (String, String) -> Unit) {
    var a by remember { mutableStateOf(v1) }
    var b by remember { mutableStateOf(v2) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(a, { a = it }, singleLine = true, label = { Text(l1) })
                OutlinedTextField(b, { b = it }, singleLine = true, label = { Text(l2) })
            }
        },
        confirmButton = { TextButton(enabled = a.isNotBlank(), onClick = { onOk(a, b) }) { Text(tr("ذخیره", "Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}
