package com.mahan.mahantgram

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

// ====================================================================== reflection helpers
// TDLib field names move a little between versions, so optional fields are read by name.

private fun Any?.f(name: String): Any? = this?.fieldOrNull(name)
private fun Any?.s(name: String): String = (this.f(name) as? String) ?: ""
private fun Any?.i(name: String): Int = (this.f(name) as? Number)?.toInt() ?: 0
private fun Any?.b(name: String): Boolean = (this.f(name) as? Boolean) ?: false
private fun textOf(x: Any?): String = when (x) {
    is String -> x
    is TdApi.FormattedText -> x.text
    else -> ""
}

private fun usernameOfAny(x: Any?): String {
    val names = x.f("usernames").f("activeUsernames") as? Array<*>
    return (names?.firstOrNull() as? String) ?: x.s("username")
}

// ====================================================================== data layer (all from TDLib)

private val RIGHTS = listOf(
    "canChangeInfo" to ("تغییر اطلاعات" to "Change info"),
    "canPostMessages" to ("ارسال پست" to "Post messages"),
    "canEditMessages" to ("ویرایش پیام‌ها" to "Edit messages"),
    "canDeleteMessages" to ("حذف پیام‌ها" to "Delete messages"),
    "canInviteUsers" to ("دعوت کاربران" to "Invite users"),
    "canRestrictMembers" to ("مدیریت اعضا" to "Ban members"),
    "canPinMessages" to ("سنجاق پیام" to "Pin messages"),
    "canManageTopics" to ("مدیریت موضوعات" to "Manage topics"),
    "canPromoteMembers" to ("افزودن مدیر" to "Add admins"),
    "canManageVideoChats" to ("مدیریت تماس‌های گروهی" to "Manage video chats"),
    "isAnonymous" to ("ناشناس" to "Anonymous"),
)

private fun rightsOf(status: Any?): List<String> {
    val src = status.f("rights") ?: status
    return RIGHTS.filter { src.b(it.first) }.map { tr(it.second.first, it.second.second) }
}

/** creator / admin / member / left / banned, from a real ChatMemberStatus. */
private fun roleOf(status: Any?): String = when (status) {
    is TdApi.ChatMemberStatusCreator -> if (status.b("isMember")) "creator" else "left"
    is TdApi.ChatMemberStatusAdministrator -> "admin"
    is TdApi.ChatMemberStatusMember -> "member"
    is TdApi.ChatMemberStatusRestricted -> if (status.b("isMember")) "member" else "left"
    is TdApi.ChatMemberStatusLeft -> "left"
    is TdApi.ChatMemberStatusBanned -> "banned"
    else -> "member"
}

private class GMember(
    val userId: Long, val name: String, val role: String, val title: String,
    val photoFileId: Int, val rights: List<String>, val status: String,
)

private class GroupData(
    val chatId: Long, val isChannel: Boolean, val description: String, val memberCount: Int,
    val username: String, val inviteLink: String, val role: String, val adminCount: Int,
    val canGetMembers: Boolean, val canInvite: Boolean, val canRestrict: Boolean, val canChangeInfo: Boolean,
    val supergroupId: Long, val basicGroupId: Long,
)

private suspend fun toGMember(m: TdApi.ChatMember): GMember? {
    val uid = (m.memberId as? TdApi.MessageSenderUser)?.userId ?: return null
    val ui = runCatching { Td.toUiUser(Td.loadUser(uid)) }.getOrNull()
    val role = roleOf(m.status)
    return GMember(
        uid, ui?.name?.ifEmpty { null } ?: uid.toString(), role, m.status.s("customTitle"),
        ui?.photoFileId ?: 0, if (role == "admin") rightsOf(m.status) else emptyList(), ui?.status ?: "",
    )
}

private suspend fun loadGroupData(chatId: Long): GroupData? {
    val chat = Td.rawChat(chatId) ?: return null
    val perms = chat.permissions
    var desc = ""
    var count = 0
    var uname = ""
    var link = ""
    var admins = 0
    var canGet = false
    var channel = false
    var sgId = 0L
    var bgId = 0L
    val status: Any?
    when (val t = chat.type) {
        is TdApi.ChatTypeSupergroup -> {
            sgId = t.supergroupId
            channel = t.isChannel
            val sg = Td.req(mk("GetSupergroup", "supergroupId" to sgId))
            status = sg.f("status")
            count = sg.i("memberCount")
            uname = usernameOfAny(sg)
            val full = runCatching { Td.req(mk("GetSupergroupFullInfo", "supergroupId" to sgId)) }.getOrNull()
            if (full != null) {
                desc = full.s("description")
                full.i("memberCount").let { if (it > 0) count = it }
                admins = full.i("administratorCount")
                canGet = full.b("canGetMembers")
                link = full.f("inviteLink").s("inviteLink")
            }
        }
        is TdApi.ChatTypeBasicGroup -> {
            bgId = t.basicGroupId
            val bg = Td.req(mk("GetBasicGroup", "basicGroupId" to bgId))
            status = bg.f("status")
            count = bg.i("memberCount")
            val full = runCatching { Td.req(mk("GetBasicGroupFullInfo", "basicGroupId" to bgId)) }.getOrNull()
            if (full != null) {
                desc = full.s("description")
                link = full.f("inviteLink").s("inviteLink")
                val ms = full.f("members") as? Array<*>
                if (ms != null) {
                    if (count == 0) count = ms.size
                    admins = ms.count { roleOf((it as? TdApi.ChatMember)?.status).let { r -> r == "admin" || r == "creator" } }
                }
            }
            canGet = true
        }
        else -> return null
    }
    val role = roleOf(status)
    val rs = status.f("rights") ?: status
    val admin = role == "admin"
    val creator = role == "creator"
    val member = role == "member"
    return GroupData(
        chatId, channel, desc, count, uname, link, role, admins, canGet,
        canInvite = creator || (admin && rs.b("canInviteUsers")) || (member && !channel && perms.b("canInviteUsers")),
        canRestrict = creator || (admin && rs.b("canRestrictMembers")),
        canChangeInfo = creator || (admin && rs.b("canChangeInfo")) || (member && !channel && perms.b("canChangeInfo")),
        supergroupId = sgId, basicGroupId = bgId,
    )
}

/** Returns members + total, or null when Telegram does not let this user see the list. */
private suspend fun loadMembers(g: GroupData, query: String, offset: Int): Pair<List<GMember>, Int>? = try {
    if (g.supergroupId != 0L) {
        val filter: TdApi.Object =
            if (query.isBlank()) TdApi.SupergroupMembersFilterRecent() else mk("SupergroupMembersFilterSearch", "query" to query)
        val r = Td.req(
            mk("GetSupergroupMembers", "supergroupId" to g.supergroupId, "filter" to filter, "offset" to offset, "limit" to 100),
        ) as TdApi.ChatMembers
        r.members.mapNotNull { toGMember(it) } to r.totalCount
    } else {
        val full = Td.req(mk("GetBasicGroupFullInfo", "basicGroupId" to g.basicGroupId))
        val all = (full.f("members") as? Array<*>)?.filterIsInstance<TdApi.ChatMember>()?.mapNotNull { toGMember(it) } ?: emptyList()
        val shown = if (query.isBlank()) all else all.filter { it.name.contains(query, true) }
        shown to all.size
    }
} catch (e: TdException) {
    null
}

private suspend fun loadAdmins(g: GroupData): List<GMember> = try {
    if (g.supergroupId != 0L) {
        val r = Td.req(
            mk(
                "GetSupergroupMembers", "supergroupId" to g.supergroupId,
                "filter" to TdApi.SupergroupMembersFilterAdministrators(), "offset" to 0, "limit" to 100,
            ),
        ) as TdApi.ChatMembers
        r.members.mapNotNull { toGMember(it) }
    } else {
        val full = Td.req(mk("GetBasicGroupFullInfo", "basicGroupId" to g.basicGroupId))
        (full.f("members") as? Array<*>)?.filterIsInstance<TdApi.ChatMember>()
            ?.filter { roleOf(it.status).let { r -> r == "admin" || r == "creator" } }
            ?.mapNotNull { toGMember(it) } ?: emptyList()
    }
} catch (e: TdException) {
    emptyList()
}

private class UserData(
    val ui: UiUser, val bio: String, val isBot: Boolean, val isContact: Boolean, val commonGroups: Int,
    val botDescription: String, val botAbout: String, val commands: List<Pair<String, String>>,
    val canJoinGroups: Boolean, val readsAll: Boolean, val inline: Boolean, val scam: Boolean, val fake: Boolean,
    val personalChatId: Long = 0L, val balance: String = "",
)

private suspend fun loadUserData(userId: Long): UserData? {
    val u = try { Td.loadUser(userId) } catch (e: TdException) { return null }
    val full = try { Td.req(mk("GetUserFullInfo", "userId" to userId)) } catch (e: TdException) { null }
    val bi = full.f("botInfo")
    val cmds = (bi.f("commands") as? Array<*>)?.mapNotNull { c ->
        val cmd = c.s("command")
        if (cmd.isEmpty()) null else cmd to c.s("description")
    } ?: emptyList()
    val type = u.type
    return UserData(
        ui = Td.toUiUser(u), bio = textOf(full.f("bio")), isBot = type is TdApi.UserTypeBot,
        isContact = u.b("isContact"), commonGroups = full.i("groupInCommonCount"),
        botDescription = bi.s("description"), botAbout = bi.s("shortDescription"), commands = cmds,
        canJoinGroups = type.b("canJoinGroups"), readsAll = type.b("canReadAllGroupMessages"),
        inline = type.b("isInline"), scam = u.b("isScam"), fake = u.b("isFake"),
        personalChatId = (full.f("personalChatId") as? Number)?.toLong() ?: 0L,
        balance = balanceOf(full),
    )
}

private class BotButton(val text: String, val url: String, val data: ByteArray?, val messageId: Long)

/** Buttons (inline or reply keyboard) of the bot's latest message, exactly as Telegram sent them. */
private suspend fun botButtons(chatId: Long): List<List<BotButton>> {
    val r = try {
        Td.req(mk("GetChatHistory", "chatId" to chatId, "fromMessageId" to 0L, "offset" to 0, "limit" to 1, "onlyLocal" to false)) as TdApi.Messages
    } catch (e: TdException) {
        return emptyList()
    }
    val m = r.messages.firstOrNull() ?: return emptyList()
    if (m.isOutgoing) return emptyList()
    val rows = m.replyMarkup.f("rows") as? Array<*> ?: return emptyList()
    return rows.map { row ->
        (row as? Array<*>)?.mapNotNull { b ->
            val text = b.s("text")
            if (text.isEmpty()) null else {
                val t = b.f("type")
                BotButton(text, t.s("url"), t.f("data") as? ByteArray, m.id)
            }
        } ?: emptyList()
    }.filter { it.isNotEmpty() }
}

// ====================================================================== small UI parts


@Composable
private fun InfoCard(content: @Composable () -> Unit) {
    val c = LocalMahan.current
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(c.glassTint.copy(alpha = 0.35f)).border(1.dp, c.glassBorder, shape).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) { content() }
}

@Composable
private fun InfoLine(value: String, label: String, onClick: (() -> Unit)? = null) {
    val c = LocalMahan.current
    Column(Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick) else Modifier)) {
        Text(value, color = c.text, fontSize = 16.sp)
        Text(label, color = c.subtext, fontSize = 12.sp)
    }
}

@Composable
private fun ActionTile(label: String, modifier: Modifier, danger: Boolean = false, onClick: () -> Unit) {
    val c = LocalMahan.current
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier.clip(shape).background(c.glassTint.copy(alpha = 0.45f)).border(1.dp, c.glassBorder, shape)
            .clickable(onClick = onClick).padding(vertical = 14.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = if (danger) Red else Green, fontSize = 14.sp, maxLines = 1, textAlign = TextAlign.Center) }
}

@Composable
private fun WideAction(text: String, danger: Boolean = false, onClick: () -> Unit) {
    val c = LocalMahan.current
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(c.glassTint.copy(alpha = 0.4f))
            .clickable(onClick = onClick).padding(16.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = if (danger) Red else Green, fontSize = 16.sp) }
}

private fun copyText(ctx: Context, text: String) {
    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("text", text))
    toast(ctx, tr("کپی شد", "Copied"))
}

private fun openUrl(ctx: Context, url: String) {
    runCatching {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }.onFailure { toast(ctx, tr("لینک باز نشد", "Could not open the link")) }
}

private fun roleLabel(role: String, title: String): String = when (role) {
    "creator" -> tr("سازنده", "Owner")
    "admin" -> tr("مدیر", "Admin")
    else -> ""
}.let { r -> if (title.isNotEmpty()) (if (r.isEmpty()) title else "$r · $title") else r }

@Composable
private fun MemberRow(m: GMember, onClick: () -> Unit, trailing: @Composable () -> Unit = {}) {
    val c = LocalMahan.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(m.photoFileId, m.name, 42.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(m.name, color = c.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val sub = roleLabel(m.role, m.title)
            if (sub.isNotEmpty()) Text(sub, color = Green, fontSize = 12.sp)
            else if (m.status.isNotEmpty()) Text(m.status, color = c.subtext, fontSize = 12.sp)
            if (m.rights.isNotEmpty()) {
                Text(m.rights.joinToString("، "), color = c.subtext, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        trailing()
    }
}

@Composable
private fun TextInputDialog(title: String, initial: String, hint: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { InputField(v, { v = it }, hint, Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { onOk(v) }) { Text(tr("ذخیره", "Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}

// ====================================================================== shared media (real search results)

@Composable
private fun SharedMedia(chatId: Long, onPhoto: (String) -> Unit) {
    val c = LocalMahan.current
    var counts by remember(chatId) { mutableStateOf<List<Pair<String, Int>>>(emptyList()) }
    var items by remember(chatId) { mutableStateOf<List<UiMessage>>(emptyList()) }
    LaunchedEffect(chatId) {
        if (Td.rawChat(chatId) == null) return@LaunchedEffect
        suspend fun count(filter: String): Int = try {
            Td.req(mk("GetChatMessageCount", "chatId" to chatId, "filter" to mk<TdApi.Object>(filter), "returnLocal" to false)).i("count")
        } catch (e: TdException) { 0 }
        counts = listOf(
            tr("عکس و ویدئو", "Photos & videos") to count("SearchMessagesFilterPhotoAndVideo"),
            tr("فایل‌ها", "Files") to count("SearchMessagesFilterDocument"),
            tr("موسیقی", "Music") to count("SearchMessagesFilterAudio"),
            tr("پیام‌های صوتی", "Voice messages") to count("SearchMessagesFilterVoiceNote"),
            tr("لینک‌ها", "Links") to count("SearchMessagesFilterUrl"),
        ).filter { it.second > 0 }
        items = try {
            val r = Td.req(
                mk(
                    "SearchChatMessages", "chatId" to chatId, "query" to "", "fromMessageId" to 0L, "offset" to 0, "limit" to 18,
                    "filter" to mk<TdApi.Object>("SearchMessagesFilterPhotoAndVideo"),
                ),
            ) as TdApi.FoundChatMessages
            r.messages.map { Td.toUi(it) }
        } catch (e: TdException) { emptyList() }
    }
    if (counts.isEmpty()) return
    InfoCard {
        Text(tr("رسانه‌های مشترک", "Shared media"), color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        counts.forEach { (label, n) ->
            Row(Modifier.fillMaxWidth()) {
                Text(label, color = c.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
                Text(n.toString(), color = c.subtext, fontSize = 15.sp)
            }
        }
        items.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                row.forEach { m ->
                    val path = Td.files[if (m.kind == MsgKind.PHOTO) m.fileId else m.thumbFileId]
                    val bmp = rememberBitmap(path, 300)
                    Box(
                        Modifier.weight(1f).height(100.dp).clip(RoundedCornerShape(10.dp)).background(c.glassTint.copy(alpha = 0.5f))
                            .clickable(enabled = path != null && m.kind == MsgKind.PHOTO) { path?.let(onPhoto) },
                    ) {
                        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        if (m.kind != MsgKind.PHOTO) Text("▶", color = Color.White, fontSize = 22.sp, modifier = Modifier.align(Alignment.Center))
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

/** Gifts of a user or channel, from TDLib; hidden when there are none. Also shows the paid-message price. */
@Composable
private fun GiftsSection(ownerId: Long, isUser: Boolean) {
    val c = LocalMahan.current
    var gifts by remember(ownerId) { mutableStateOf<Pair<Int, List<Td.UiGift>>>(0 to emptyList()) }
    var paid by remember(ownerId) { mutableStateOf(0) }
    var openGift by remember(ownerId) { mutableStateOf<Td.UiGift?>(null) }
    LaunchedEffect(ownerId) {
        gifts = Td.receivedGifts(ownerId, isUser)
        paid = if (isUser) Td.paidMessageStarsOfUser(ownerId) else Td.paidMessageStars(ownerId)
    }
    if (paid > 0) {
        InfoCard {
            Text("$paid Tony", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(tr("هزینه‌ی هر پیام به این گفتگو (Tony)", "Tony per message to this chat"), color = c.subtext, fontSize = 12.sp)
        }
    }
    if (gifts.second.isEmpty()) return
    InfoCard {
        Text(trf("هدیه‌ها ({0})", "Gifts ({0})", gifts.first), color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        gifts.second.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { g ->
                    val tinted = g.upgraded && g.bgEdge != 0
                    val ink = if (tinted) Color.White else c.text
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                            .then(
                                if (tinted) Modifier.background(
                                    androidx.compose.ui.graphics.Brush.radialGradient(
                                        listOf(Color(0xFF000000.toInt() or g.bgCenter), Color(0xFF000000.toInt() or g.bgEdge)),
                                    ),
                                ) else Modifier.background(c.glassTint.copy(alpha = 0.5f)),
                            )
                            .clickable { openGift = g }
                            .padding(vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        if (g.sticker != null) StickerImage(g.sticker, Modifier.size(64.dp), animate = false)
                        else Text(g.emoji, fontSize = 32.sp)
                        if (g.name.isNotEmpty()) Text(g.name, color = ink, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (g.number > 0) Text("#${g.number}", color = ink.copy(alpha = 0.8f), fontSize = 10.sp)
                        if (g.stars > 0) Text("${g.stars} Tony", color = if (tinted) ink.copy(alpha = 0.8f) else c.subtext, fontSize = 11.sp)
                        if (g.upgraded) Text(tr("منحصربه‌فرد", "Unique"), color = if (tinted) ink else Green, fontSize = 10.sp)
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
    openGift?.let { g ->
        AlertDialog(
            onDismissRequest = { openGift = null },
            title = { Text(g.name.ifEmpty { tr("هدیه", "Gift") } + if (g.number > 0) " #${g.number}" else "") },
            text = {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    val tinted = g.upgraded && g.bgEdge != 0
                    Box(
                        Modifier.size(220.dp).clip(RoundedCornerShape(20.dp)).then(
                            if (tinted) Modifier.background(
                                androidx.compose.ui.graphics.Brush.radialGradient(
                                    listOf(Color(0xFF000000.toInt() or g.bgCenter), Color(0xFF000000.toInt() or g.bgEdge)),
                                ),
                            ) else Modifier,
                        ),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (g.sticker != null) StickerImage(g.sticker, Modifier.size(180.dp), animate = true)
                        else Text(g.emoji, fontSize = 80.sp)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { openGift = null }) { Text(tr("بستن", "Close")) } },
        )
    }
}


// ====================================================================== profile header pieces

/** Optional balance shown as a chip. TDLib only exposes it for some accounts, so an unknown value stays empty (chip hidden). */
private fun balanceOf(full: Any?): String {
    for (name in listOf("starCount", "balance")) {
        val v = full.f(name)
        val n = (v as? Number)?.toDouble() ?: (v.f("starCount") as? Number)?.toDouble()
        if (n != null && n > 0) return "%,.2f".format(n)
    }
    return ""
}

private fun compactCount(n: Int): String = when {
    n >= 1_000_000 -> "%.1fM".format(n / 1_000_000.0).replace(".0M", "M")
    n >= 1_000 -> "%.1fK".format(n / 1_000.0).replace(".0K", "K")
    else -> n.toString()
}

private class PersonalChannel(
    val chatId: Long, val title: String, val photoFileId: Int, val subscribers: Int,
    val lastText: String, val lastTime: String,
)

private suspend fun loadPersonalChannel(chatId: Long): PersonalChannel? {
    if (chatId == 0L) return null
    val chat = try { Td.req(mk("GetChat", "chatId" to chatId)) as TdApi.Chat } catch (e: Throwable) { return null }
    val small = chat.photo?.small
    if (small != null) Td.registerFile(small, true)
    var subs = 0
    (chat.type as? TdApi.ChatTypeSupergroup)?.let { t ->
        subs = runCatching { Td.req(mk("GetSupergroup", "supergroupId" to t.supergroupId)).i("memberCount") }.getOrDefault(0)
    }
    val last = chat.lastMessage?.let { runCatching { Td.toUi(it) }.getOrNull() }
    return PersonalChannel(
        chatId, chat.title, small?.id ?: 0, subs,
        last?.text.orEmpty(), last?.let { Td.fmtTime(it.date) }.orEmpty(),
    )
}

private class StoryThumb(val fileId: Int, val duration: Int)

/** Stories pinned to a user's profile (the "Posts" tab). Read by field name because TDLib story types differ between versions. */
private suspend fun loadProfileStories(userId: Long): List<StoryThumb> {
    val res = try {
        Td.req(mk("GetChatPostedToChatPageStories", "chatId" to userId, "fromStoryId" to 0, "limit" to 30))
    } catch (e: Throwable) { return emptyList() }
    val arr = res.f("stories") as? Array<*> ?: return emptyList()
    return arr.mapNotNull { st ->
        val content = st.f("content") ?: return@mapNotNull null
        var duration = 0
        val file: TdApi.File? = run {
            val photoSizes = content.f("photo").f("sizes") as? Array<*>
            if (photoSizes != null && photoSizes.isNotEmpty()) {
                val pick = photoSizes.firstOrNull { (it.f("width") as? Number)?.toInt()?.let { w -> w >= 200 } == true } ?: photoSizes.last()
                pick.f("photo") as? TdApi.File
            } else {
                val video = content.f("video")
                duration = (video.f("duration") as? Number)?.toInt() ?: 0
                video.f("thumbnail").f("file") as? TdApi.File
            }
        }
        if (file == null) null else { Td.registerFile(file, true); StoryThumb(file.id, duration) }
    }
}

@Composable
private fun ProfileAction(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    val c = LocalMahan.current
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier.clip(shape).background(c.glassTint.copy(alpha = 0.55f)).border(1.dp, c.glassBorder, shape)
            .clickable(onClick = onClick).padding(vertical = 14.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, null, tint = c.text, modifier = Modifier.size(24.dp))
        Text(label, color = c.text, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
private fun ProfileTab(label: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalMahan.current
    Text(
        label, color = if (selected) Green else c.subtext, fontSize = 15.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (selected) Green.copy(alpha = 0.18f) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 22.dp, vertical = 9.dp),
    )
}

@Composable
private fun StoryGrid(items: List<StoryThumb>, onClick: () -> Unit) {
    val c = LocalMahan.current
    items.chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            row.forEach { t ->
                val bmp = rememberBitmap(Td.files[t.fileId], 300)
                Box(Modifier.weight(1f).height(130.dp).clip(RoundedCornerShape(10.dp)).background(c.glassTint.copy(alpha = 0.5f)).clickable(onClick = onClick)) {
                    if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    if (t.duration > 0) Text(
                        "%d:%02d".format(t.duration / 60, t.duration % 60), color = Color.White, fontSize = 12.sp,
                        modifier = Modifier.align(Alignment.BottomStart).padding(6.dp),
                    )
                }
            }
            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

// ====================================================================== user / bot profile

@Composable
fun UserProfileScreen(userId: Long, onBack: () -> Unit, onChat: (Long) -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var data by remember(userId) { mutableStateOf<UserData?>(null) }
    var failed by remember(userId) { mutableStateOf(false) }
    var buttons by remember(userId) { mutableStateOf<List<List<BotButton>>>(emptyList()) }
    var storyOpen by remember { mutableStateOf(false) }
    var photo by remember { mutableStateOf<String?>(null) }
    var channel by remember(userId) { mutableStateOf<PersonalChannel?>(null) }
    var stories by remember(userId) { mutableStateOf<List<StoryThumb>>(emptyList()) }
    var storiesLoaded by remember(userId) { mutableStateOf(false) }
    var added by remember(userId) { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    // A private chat has the same id as its user. If that chat is hidden in AjiMaji, nothing here may open it.
    val chatLocked = Vault.isHidden(userId) && !Vault.unlocked
    LaunchedEffect(userId) {
        data = loadUserData(userId)
        failed = data == null
        if (data?.isBot == true && !chatLocked) {
            val chatId = runCatching { Td.openPrivateChat(userId) }.getOrNull()
            if (chatId != null) buttons = botButtons(chatId)
        }
        if (!chatLocked) {
            channel = loadPersonalChannel(data?.personalChatId ?: 0L)
            stories = loadProfileStories(userId)
        }
        storiesLoaded = true
    }
    val d = data
    val story = Td.storyInfoFor(userId)
    val big = Td.bigUserPhotoId(userId)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // ---- header: gradient, back button, big round photo, name, status
        Column(
            Modifier.fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Green.copy(alpha = 0.32f), c.glassTint.copy(alpha = 0.0f))))
                .statusBarsPadding().padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(Modifier.fillMaxWidth()) { BackButton(onBack) }
            if (d == null) {
                Text(
                    if (failed) tr("اطلاعات این کاربر در دسترس نیست", "This user's information is not available")
                    else tr("در حال بارگذاری…", "Loading…"),
                    color = c.subtext, modifier = Modifier.padding(32.dp),
                )
                return@Column
            }
            Box(
                Modifier.clip(CircleShape).clickable(enabled = story != null || big != 0) {
                    if (story != null) storyOpen = true else Td.files[big]?.let { photo = it }
                },
            ) {
                StoryAvatar(if (big != 0) big else d.ui.photoFileId, d.ui.name, 140.dp, story?.let { if (it.second) 2 else 1 } ?: 0)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(d.ui.name, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                if (d.ui.verified) {
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Rounded.Verified, null, tint = VerifiedBlue, modifier = Modifier.size(22.dp))
                }
                if (d.ui.premium) {
                    Spacer(Modifier.width(6.dp))
                    PremiumBadge(d.ui.statusEmojiId, 22.dp)
                }
                if (d.isBot) {
                    Spacer(Modifier.width(8.dp))
                    Text(
                        tr("ربات", "BOT"), color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.background(VerifiedBlue, RoundedCornerShape(4.dp)).padding(horizontal = 5.dp, vertical = 1.dp),
                    )
                }
            }
            if (d.scam || d.fake) {
                Text(
                    if (d.scam) tr("⚠ تلگرام این حساب را کلاهبرداری علامت زده است", "⚠ Telegram marked this account as a scam")
                    else tr("⚠ تلگرام این حساب را جعلی علامت زده است", "⚠ Telegram marked this account as fake"),
                    color = Red, fontSize = 13.sp, textAlign = TextAlign.Center,
                )
            }
            // Status exactly as Telegram's privacy rules allow it; hidden statuses come back empty.
            val statusText = when {
                d.isBot -> tr("ربات", "bot")
                d.ui.status.isEmpty() -> tr("آخرین بازدید در دسترس نیست", "last seen not available")
                else -> d.ui.status
            }
            Text(statusText, color = if (d.ui.status == tr("آنلاین", "online")) Green else c.subtext, fontSize = 15.sp)
            if (d.balance.isNotEmpty()) {
                Text(
                    tr("موجودی: ", "Balance: ") + d.balance, color = c.text, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(c.glassTint.copy(alpha = 0.6f)).padding(horizontal = 14.dp, vertical = 6.dp),
                )
            }
        }
        if (d == null) return@Column

        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // ---- three action buttons: message / mute / call
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!chatLocked) {
                    ProfileAction(
                        Icons.Rounded.ChatBubble, if (d.isBot) tr("شروع ربات", "Start bot") else tr("پیام", "Message"), Modifier.weight(1f),
                    ) {
                        scope.launch {
                            try {
                                val id = Td.openPrivateChat(userId)
                                if (d.isBot) Td.tryReq(mk("SendBotStartMessage", "botUserId" to userId, "chatId" to id, "parameter" to ""))
                                onChat(id)
                            } catch (e: Exception) {
                                toast(ctx, e.message ?: "error")
                            }
                        }
                    }
                }
                if (!chatLocked && !d.isBot) {
                    ProfileAction(Icons.Rounded.Notifications, tr("بی‌صدا", "Mute"), Modifier.weight(1f)) {
                        scope.launch {
                            val id = runCatching { Td.openPrivateChat(userId) }.getOrNull() ?: return@launch
                            when (Td.toggleMute(id)) {
                                true -> toast(ctx, tr("اعلان‌ها بی‌صدا شد", "Notifications muted"))
                                false -> toast(ctx, tr("اعلان‌ها فعال شد", "Notifications on"))
                                null -> toast(ctx, tr("انجام نشد", "Could not change"))
                            }
                        }
                    }
                    ProfileAction(Icons.Rounded.Call, tr("تماس", "Call"), Modifier.weight(1f)) {
                        toast(ctx, tr("تماس به‌زودی اضافه می‌شود", "Calls are coming soon"))
                    }
                }
                if (d.isBot && !chatLocked) ActionTile(tr("باز کردن گفتگو", "Open chat"), Modifier.weight(1f)) {
                    scope.launch { runCatching { Td.openPrivateChat(userId) }.getOrNull()?.let(onChat) }
                }
                if (story != null && d.isBot) ActionTile(tr("مشاهده استوری", "View story"), Modifier.weight(1f)) { storyOpen = true }
            }

            // ---- channel card
            channel?.let { ch ->
                InfoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(tr("کانال", "Channel"), color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        if (ch.subscribers > 0) {
                            Spacer(Modifier.width(8.dp))
                            Text(
                                trf("{0} مشترک", "{0} subscribers", compactCount(ch.subscribers)), color = c.subtext, fontSize = 12.sp,
                                modifier = Modifier.clip(RoundedCornerShape(50)).background(c.glassTint.copy(alpha = 0.6f)).padding(horizontal = 10.dp, vertical = 3.dp),
                            )
                        }
                    }
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onChat(ch.chatId) },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Avatar(ch.photoFileId, ch.title, 56.dp)
                        Column(Modifier.weight(1f)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(ch.title, color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                if (ch.lastTime.isNotEmpty()) Text(ch.lastTime, color = c.subtext, fontSize = 12.sp)
                            }
                            if (ch.lastText.isNotEmpty()) Text(ch.lastText, color = c.subtext, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }

            // ---- username + ID card
            InfoCard {
                if (d.ui.phone.isNotEmpty()) InfoLine("+" + d.ui.phone, tr("موبایل", "Mobile")) { copyText(ctx, "+" + d.ui.phone) }
                if (d.ui.username.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            InfoLine("@" + d.ui.username, tr("نام کاربری", "Username")) { copyText(ctx, "@" + d.ui.username) }
                        }
                        Icon(
                            Icons.Rounded.QrCode2, null, tint = c.text,
                            modifier = Modifier.size(30.dp).clip(RoundedCornerShape(6.dp)).clickable { copyText(ctx, "https://t.me/" + d.ui.username) },
                        )
                    }
                }
                InfoLine(d.ui.id.toString(), tr("شناسه کاربر", "User ID")) { copyText(ctx, d.ui.id.toString()) }
                if (d.bio.isNotEmpty()) InfoLine(d.bio, tr("بیوگرافی", "Bio"))
                if (d.commonGroups > 0) InfoLine(d.commonGroups.toString(), tr("گروه‌های مشترک", "Groups in common"))
                if (d.ui.phone.isEmpty() && !d.isBot) {
                    Text(
                        tr("شماره‌ی موبایل طبق تنظیمات حریم خصوصی این کاربر دیده نمی‌شود.", "The phone number is hidden by this user's privacy settings."),
                        color = c.subtext, fontSize = 12.sp,
                    )
                }
            }

            // ---- add to contacts (only for people who are not contacts yet)
            if (!d.isBot && !d.isContact && !added && userId != Td.me?.id) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(c.glassTint.copy(alpha = 0.4f))
                        .clickable {
                            scope.launch {
                                val u = runCatching { Td.loadUser(userId) }.getOrNull() ?: return@launch
                                val err = Td.tryReq(
                                    mk(
                                        "AddContact",
                                        "contact" to mk<TdApi.Object>(
                                            "Contact", "phoneNumber" to u.phoneNumber, "firstName" to u.firstName,
                                            "lastName" to u.lastName, "vcard" to "", "userId" to userId,
                                        ),
                                        "sharePhoneNumber" to false,
                                    ),
                                )
                                if (err == null) { added = true; toast(ctx, tr("به مخاطبین اضافه شد", "Added to contacts")) }
                                else toast(ctx, err)
                            }
                        }.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Icon(Icons.Rounded.PersonAdd, null, tint = c.subtext, modifier = Modifier.size(26.dp))
                    Text(tr("افزودن به مخاطبین", "Add to contacts"), color = c.text, fontSize = 17.sp)
                }
            }

        if (d.isBot) {
            InfoCard {
                Text(tr("درباره‌ی ربات", "About this bot"), color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                val about = d.botDescription.ifEmpty { d.botAbout }
                Text(about.ifEmpty { tr("توضیحی ثبت نشده", "No description") }, color = c.text, fontSize = 15.sp, lineHeight = 22.sp)
                InfoLine(
                    if (d.canJoinGroups) tr("بله", "Yes") else tr("خیر", "No"),
                    tr("می‌تواند به گروه اضافه شود", "Can be added to groups"),
                )
                InfoLine(
                    if (d.readsAll) tr("بله", "Yes") else tr("خیر", "No"),
                    tr("همه‌ی پیام‌های گروه را می‌خواند", "Reads all group messages"),
                )
                InfoLine(if (d.inline) tr("پشتیبانی می‌شود", "Supported") else tr("ندارد", "No"), tr("حالت Inline", "Inline mode"))
            }
            if (d.commands.isNotEmpty() && !chatLocked) {
                InfoCard {
                    Text(tr("دستورهای ربات", "Bot commands"), color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    d.commands.forEach { (cmd, desc) ->
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable {
                                scope.launch {
                                    val id = runCatching { Td.openPrivateChat(userId) }.getOrNull() ?: return@launch
                                    Td.sendText(id, "/$cmd")?.let { toast(ctx, it) }
                                    onChat(id)
                                }
                            }.padding(vertical = 4.dp),
                        ) {
                            Text("/$cmd", color = Green, fontSize = 15.sp)
                            if (desc.isNotEmpty()) Text(desc, color = c.subtext, fontSize = 12.sp)
                        }
                    }
                }
            }
            if (buttons.isNotEmpty()) {
                InfoCard {
                    Text(tr("دکمه‌های ربات", "Bot buttons"), color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    buttons.forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { b ->
                                ActionTile(b.text, Modifier.weight(1f)) {
                                    scope.launch {
                                        when {
                                            b.url.isNotEmpty() -> openUrl(ctx, b.url)
                                            b.data != null -> {
                                                val id = runCatching { Td.openPrivateChat(userId) }.getOrNull() ?: return@launch
                                                try {
                                                    val ans = Td.req(
                                                        mk(
                                                            "GetCallbackQueryAnswer", "chatId" to id, "messageId" to b.messageId,
                                                            "payload" to mk<TdApi.Object>("CallbackQueryPayloadData", "data" to b.data),
                                                        ),
                                                    )
                                                    ans.s("text").takeIf { it.isNotEmpty() }?.let { toast(ctx, it) }
                                                } catch (e: TdException) {
                                                    toast(ctx, e.message ?: "error")
                                                }
                                            }
                                            else -> {
                                                val id = runCatching { Td.openPrivateChat(userId) }.getOrNull() ?: return@launch
                                                Td.sendText(id, b.text)?.let { toast(ctx, it) }
                                                onChat(id)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
            // ---- tabs: posts / gifts
            if (!chatLocked) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    Row(
                        Modifier.clip(RoundedCornerShape(50)).background(c.glassTint.copy(alpha = 0.45f)).padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        ProfileTab(tr("پست‌ها", "Posts"), tab == 0) { tab = 0 }
                        ProfileTab(tr("هدیه‌ها", "Gifts"), tab == 1) { tab = 1 }
                    }
                }
                if (tab == 0) {
                    if (stories.isNotEmpty()) StoryGrid(stories) { if (story != null) storyOpen = true }
                    else if (storiesLoaded) Text(
                        tr("پستی برای نمایش نیست", "No posts to show"), color = c.subtext, fontSize = 14.sp,
                        modifier = Modifier.fillMaxWidth().padding(8.dp), textAlign = TextAlign.Center,
                    )
                    SharedMedia(userId) { photo = it }
                } else {
                    GiftsSection(userId, true)
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
    if (storyOpen && story != null) StoryViewer(userId) { storyOpen = false }
    photo?.let { PhotoDialog(it) { photo = null } }
}

// ====================================================================== chat info entry point

/** Info page of any chat: user / bot profile, group, or channel, all read from TDLib. */
@Composable
fun LiveChatInfo(
    chatId: Long,
    onBack: () -> Unit,
    onLeft: () -> Unit,
    onUser: (Long) -> Unit = {},
    onOpenChat: (Long) -> Unit = {},
    onBoost: () -> Unit = {},
) {
    val chat = Td.chatById(chatId)
    if (chat == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    if (chat.kind == ChatKind.PRIVATE && chat.userId != 0L) {
        UserProfileScreen(chat.userId, onBack, onOpenChat)
    } else {
        GroupChannelInfo(chatId, onBack, onLeft, onUser, onOpenChat, onBoost)
    }
}

// ====================================================================== group / channel

@Composable
private fun GroupChannelInfo(chatId: Long, onBack: () -> Unit, onLeft: () -> Unit, onUser: (Long) -> Unit, onOpenChat: (Long) -> Unit, onBoost: () -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    var g by remember(chatId) { mutableStateOf<GroupData?>(null) }
    var loadFailed by remember(chatId) { mutableStateOf(false) }
    var admins by remember(chatId) { mutableStateOf<List<GMember>>(emptyList()) }
    var members by remember(chatId) { mutableStateOf<List<GMember>>(emptyList()) }
    var total by remember(chatId) { mutableIntStateOf(0) }
    var membersHidden by remember(chatId) { mutableStateOf(false) }
    var query by remember(chatId) { mutableStateOf("") }
    var link by remember(chatId) { mutableStateOf("") }
    var adding by remember { mutableStateOf(false) }
    var editTitle by remember { mutableStateOf(false) }
    var editDesc by remember { mutableStateOf(false) }
    var confirmLeave by remember { mutableStateOf(false) }
    var banFor by remember { mutableStateOf<GMember?>(null) }
    val chat = Td.chatById(chatId)

    LaunchedEffect(chatId, tick) {
        val d = try { loadGroupData(chatId) } catch (e: TdException) { null }
        g = d
        loadFailed = d == null
        if (d != null) {
            if (link.isEmpty()) link = d.inviteLink
            admins = loadAdmins(d)
        }
    }
    // Member list: reloaded when the search text changes (small debounce to avoid a request per key).
    LaunchedEffect(g?.chatId, g?.canGetMembers, query, tick) {
        val d = g ?: return@LaunchedEffect
        if (!d.canGetMembers) { membersHidden = true; return@LaunchedEffect }
        if (query.isNotBlank()) kotlinx.coroutines.delay(350)
        val r = loadMembers(d, query, 0)
        if (r == null) {
            membersHidden = true
        } else {
            membersHidden = false
            members = r.first
            total = r.second
        }
    }

    val d = g
    val big = Td.bigChatPhotoId(chatId)
    val title = chat?.title ?: ""
    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp).navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(Modifier.fillMaxWidth()) { BackButton(onBack) }
        Avatar(if (big != 0) big else chat?.photoFileId ?: 0, title, 112.dp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            if (chat?.verified == true) {
                Spacer(Modifier.width(5.dp))
                Icon(Icons.Rounded.Verified, null, tint = VerifiedBlue, modifier = Modifier.size(20.dp))
            }
        }
        if (d == null) {
            Text(
                if (loadFailed) tr("اطلاعات در دسترس نیست", "Information is not available") else tr("در حال بارگذاری…", "Loading…"),
                color = c.subtext, modifier = Modifier.padding(24.dp),
            )
            return@Column
        }
        Text(
            if (d.isChannel) trf("{0} مشترک", "{0} subscribers", d.memberCount)
            else trf("{0} عضو", "{0} members", d.memberCount),
            color = c.subtext, fontSize = 14.sp,
        )

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionTile(tr("باز کردن گفتگو", "Open chat"), Modifier.weight(1f)) { onOpenChat(chatId) }
            if (d.canInvite && !d.isChannel) ActionTile(tr("افزودن عضو", "Add member"), Modifier.weight(1f)) { adding = true }
            if (d.canChangeInfo) ActionTile(tr("ویرایش", "Edit"), Modifier.weight(1f)) { editTitle = true }
        }

        InfoCard {
            InfoLine(
                d.description.ifEmpty { tr("توضیحی ثبت نشده", "No description") },
                tr("توضیحات", "Description"),
                if (d.canChangeInfo) ({ editDesc = true }) else null,
            )
            if (d.username.isNotEmpty()) {
                val url = "https://t.me/${d.username}"
                InfoLine(url, if (d.isChannel) tr("لینک کانال", "Channel link") else tr("لینک گروه", "Group link")) { copyText(ctx, url) }
                InfoLine("@" + d.username, tr("نام کاربری", "Username")) { copyText(ctx, "@" + d.username) }
            } else {
                InfoLine(
                    if (d.isChannel) tr("خصوصی", "Private") else tr("گروه خصوصی", "Private group"),
                    tr("نوع", "Type"),
                )
            }
            if (link.isNotEmpty()) {
                InfoLine(link, tr("لینک دعوت", "Invite link")) { copyText(ctx, link) }
            } else if (d.canInvite) {
                Text(
                    tr("ساخت لینک دعوت", "Create invite link"), color = Green, fontSize = 15.sp,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable {
                        scope.launch {
                            try { link = Td.inviteLink(chatId) } catch (e: Exception) { toast(ctx, e.message ?: "error") }
                        }
                    }.padding(vertical = 4.dp),
                )
            }
            InfoLine(Td.chatKindLabel(d.isChannel, d.supergroupId != 0L), tr("نوع گفتگو", "Chat type"))
            InfoLine(chatId.toString(), tr("شناسه گفتگو", "Chat ID")) { copyText(ctx, chatId.toString()) }
        }

        if (admins.isNotEmpty()) {
            InfoCard {
                Text(tr("مدیران", "Administrators") + " (${admins.size})", color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                admins.forEach { m -> MemberRow(m, onClick = { onUser(m.userId) }) }
            }
        } else if (d.isChannel && d.adminCount > 0) {
            Text(tr("فهرست مدیران برای شما در دسترس نیست", "The administrator list is not available to you"), color = c.subtext, fontSize = 12.sp)
        }

        if (membersHidden) {
            Text(
                if (d.isChannel) tr("فهرست مشترک‌ها فقط برای مدیران قابل مشاهده است.", "The subscriber list is visible to admins only.")
                else tr("تلگرام فهرست اعضای این گروه را نمایش نمی‌دهد.", "Telegram does not show this group's member list."),
                color = c.subtext, fontSize = 12.sp, textAlign = TextAlign.Center,
            )
        } else {
            InfoCard {
                Text(
                    (if (d.isChannel) tr("مشترک‌ها", "Subscribers") else tr("اعضا", "Members")) + " ($total)",
                    color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                )
                InputField(query, { query = it }, tr("جست‌وجو در اعضا", "Search members"), Modifier.fillMaxWidth())
                if (members.isEmpty()) {
                    Text(tr("عضوی پیدا نشد", "No members found"), color = c.subtext, fontSize = 13.sp)
                }
                members.forEach { m ->
                    MemberRow(m, onClick = { onUser(m.userId) }) {
                        if (d.canRestrict && m.role != "creator" && m.userId != Td.meId && !(m.role == "admin" && d.role != "creator")) {
                            Text(
                                "✕", color = Red, fontSize = 16.sp,
                                modifier = Modifier.clip(CircleShape).clickable { banFor = m }.padding(10.dp),
                            )
                        }
                    }
                }
            }
        }

        if (d.supergroupId != 0L && d.role != "banned") WideAction(tr("بوست‌ها 🚀", "Boosts 🚀")) { onBoost() }

        GiftsSection(chatId, false)

        // Join / leave follow Telegram's rules: the owner can't leave, a non-member joins instead.
        if (d.role == "left" || d.role == "banned") {
            if (d.role == "left") WideAction(tr("عضویت", "Join")) {
                scope.launch {
                    val err = Td.tryReq(mk("JoinChat", "chatId" to chatId))
                    if (err != null) toast(ctx, err) else tick++
                }
            }
        } else if (d.role == "creator") {
            Text(
                tr("سازنده نمی‌تواند ترک کند؛ ابتدا مالکیت را منتقل کن.", "The owner can't leave; transfer ownership first."),
                color = c.subtext, fontSize = 12.sp, textAlign = TextAlign.Center,
            )
        } else {
            WideAction(if (d.isChannel) tr("ترک کانال", "Leave channel") else tr("ترک گروه", "Leave group"), danger = true) { confirmLeave = true }
        }
    }

    if (confirmLeave) {
        AlertDialog(
            onDismissRequest = { confirmLeave = false },
            title = { Text(tr("ترک گفتگو", "Leave chat")) },
            text = { Text(trf("«{0}» ترک شود؟", "Leave “{0}”?", title)) },
            confirmButton = {
                TextButton(onClick = {
                    confirmLeave = false
                    scope.launch { val err = Td.leave(chatId); if (err != null) toast(ctx, err) else onLeft() }
                }) { Text(tr("ترک", "Leave"), color = Red) }
            },
            dismissButton = { TextButton(onClick = { confirmLeave = false }) { Text(tr("لغو", "Cancel")) } },
        )
    }
    banFor?.let { m ->
        AlertDialog(
            onDismissRequest = { banFor = null },
            title = { Text(tr("حذف عضو", "Remove member")) },
            text = { Text(trf("«{0}» از گفتگو حذف شود؟", "Remove “{0}” from this chat?", m.name)) },
            confirmButton = {
                TextButton(onClick = {
                    banFor = null
                    scope.launch {
                        val err = Td.banMember(chatId, m.userId)
                        if (err != null) toast(ctx, err) else { members = members.filter { it.userId != m.userId }; total-- }
                    }
                }) { Text(tr("حذف", "Remove"), color = Red) }
            },
            dismissButton = { TextButton(onClick = { banFor = null }) { Text(tr("لغو", "Cancel")) } },
        )
    }
    if (editTitle) {
        TextInputDialog(tr("ویرایش نام", "Edit name"), title, tr("نام", "Name"), { editTitle = false }) { v ->
            editTitle = false
            scope.launch {
                val err = if (v.isBlank()) null else Td.tryReq(mk("SetChatTitle", "chatId" to chatId, "title" to v.trim()))
                if (err != null) toast(ctx, err) else tick++
            }
        }
    }
    if (editDesc) {
        TextInputDialog(tr("ویرایش توضیحات", "Edit description"), g?.description ?: "", tr("توضیحات", "Description"), { editDesc = false }) { v ->
            editDesc = false
            scope.launch {
                val err = Td.tryReq(mk("SetChatDescription", "chatId" to chatId, "description" to v.trim()))
                if (err != null) toast(ctx, err) else tick++
            }
        }
    }
    if (adding) {
        LaunchedEffect(Unit) { runCatching { Td.loadContacts() } }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text(tr("افزودن عضو", "Add member")) },
            text = {
                Column(Modifier.height(300.dp).verticalScroll(rememberScrollState())) {
                    val hiddenUsers = Td.hiddenUserIds
                    Td.contacts.filter { it.id !in hiddenUsers }.forEach { u ->
                        Text(
                            u.name, fontSize = 16.sp,
                            modifier = Modifier.fillMaxWidth().clickable {
                                adding = false
                                scope.launch {
                                    val err = Td.addMember(chatId, u.id)
                                    if (err != null) toast(ctx, err) else { toast(ctx, tr("اضافه شد", "Added")); tick++ }
                                }
                            }.padding(vertical = 12.dp),
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { adding = false }) { Text(tr("لغو", "Cancel")) } },
        )
    }
}
