package com.mahan.mahantgram

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeEffect

/** Glass surface: real backdrop blur (when enabled) + gray tint. */
@Composable
fun Modifier.glass(hazeState: HazeState, blurOn: Boolean, alpha: Float, shape: Shape): Modifier {
    val c = LocalMahan.current
    val clipped = this.clip(shape)
    val blurred = if (blurOn) clipped.hazeEffect(state = hazeState) { blurRadius = 14.dp } else clipped
    val a = if (blurOn) alpha else maxOf(alpha, 0.88f)
    return blurred.background(c.glassTint.copy(alpha = a), shape)
}

data class TabItem(val icon: ImageVector, val label: String)

@Composable
fun GlassTopBar(
    title: String,
    hazeState: HazeState,
    blurOn: Boolean,
    glassAlpha: Float,
    searching: Boolean,
    query: String,
    onQuery: (String) -> Unit,
    onToggleSearch: () -> Unit,
    searchHint: String,
    modifier: Modifier = Modifier,
) {
    val c = LocalMahan.current
    Row(
        modifier
            .fillMaxWidth()
            .glass(hazeState, blurOn, glassAlpha, RectangleShape)
            .statusBarsPadding()
            .height(64.dp)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (searching) {
            androidx.compose.foundation.text.BasicTextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = c.text, fontSize = 18.sp),
                cursorBrush = androidx.compose.ui.graphics.SolidColor(Green),
                modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    Box {
                        if (query.isEmpty()) Text(searchHint, color = c.subtext, fontSize = 18.sp)
                        inner()
                    }
                },
            )
            Spacer(Modifier.width(8.dp))
            Icon(
                Icons.Rounded.Close,
                contentDescription = null,
                tint = c.text,
                modifier = Modifier.clip(CircleShape).clickable(onClick = onToggleSearch).padding(6.dp),
            )
            return@Row
        }
        Box(Modifier.size(28.dp).background(Green, CircleShape))
        Spacer(Modifier.width(10.dp))
        Text(
            title,
            color = c.text,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.width(4.dp))
        Icon(Icons.Rounded.Verified, contentDescription = null, tint = VerifiedBlue, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(6.dp))
        // The car faces the title: mirrored in left-to-right layouts.
        val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
        Image(
            painter = painterResource(R.drawable.car_gtr_small),
            contentDescription = null,
            modifier = Modifier
                .width(88.dp)
                .graphicsLayer { scaleX = if (rtl) 1f else -1f },
        )
        Spacer(Modifier.weight(1f))
        Icon(
            Icons.Rounded.Search,
            contentDescription = null,
            tint = c.text,
            modifier = Modifier.clip(CircleShape).clickable(onClick = onToggleSearch).padding(6.dp),
        )
    }
}

@Composable
fun GlassBottomBar(
    tabs: List<TabItem>,
    selected: Int,
    onSelect: (Int) -> Unit,
    hazeState: HazeState,
    blurOn: Boolean,
    glassAlpha: Float,
    modifier: Modifier = Modifier,
) {
    val c = LocalMahan.current
    val shape = RoundedCornerShape(30.dp)
    Box(
        modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 10.dp),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(68.dp)
                .glass(hazeState, blurOn, glassAlpha, shape)
                .border(1.dp, c.glassBorder, shape)
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            tabs.forEachIndexed { i, t ->
                val tint by animateColorAsState(
                    if (i == selected) Green else c.subtext,
                    label = "tabTint",
                )
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(22.dp))
                        .clickable { onSelect(i) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Icon(t.icon, contentDescription = t.label, tint = tint, modifier = Modifier.size(24.dp))
                    Text(t.label, color = tint, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
        // Two bikes ride on the bar. This overlay has no click handlers, so touches pass through to the tabs.
        Row(Modifier.fillMaxWidth().height(68.dp).padding(horizontal = 6.dp)) {
            repeat(tabs.size) { i ->
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.TopCenter) {
                    when (i) {
                        2 -> BarBike(R.drawable.bike_pink, PINK_ASPECT, 96.dp)
                        4 -> BarBike(R.drawable.bike_bmw, BMW_ASPECT, 80.dp)
                    }
                }
            }
        }
    }
}

@Composable
private fun BarBike(res: Int, aspect: Float, w: androidx.compose.ui.unit.Dp) {
    Image(
        painter = painterResource(res),
        contentDescription = null,
        modifier = Modifier
            .requiredWidth(w)
            .offset(y = -(w / aspect) + 12.dp),
    )
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalMahan.current
    Box(
        Modifier
            .clip(CircleShape)
            .background(if (selected) Green else c.glassTint.copy(alpha = 0.45f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    ) {
        Text(text, color = if (selected) Color.Black else c.text, fontSize = 14.sp)
    }
}
