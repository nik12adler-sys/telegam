package com.mahan.mahantgram

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.drinkless.tdlib.TdApi

@Composable
private fun AuthFrame(title: String, sub: String, onProxy: () -> Unit, content: @Composable () -> Unit) {
    val c = LocalMahan.current
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        HeroStage(R.drawable.bike_bmw, BMW_ASPECT, VerifiedBlue, height = 200.dp)
        Text(title, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(sub, color = c.subtext, fontSize = 14.sp, textAlign = TextAlign.Center)
        GlassCard { content() }
        Td.authError?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp, textAlign = TextAlign.Center) }
        if (Td.connection.isNotEmpty()) {
            Text(connectionText(), color = c.subtext, fontSize = 12.sp)
        }
        Text(
            tr("تنظیم پروکسی", "Proxy settings"),
            color = Green,
            fontSize = 15.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .clickable(onClick = onProxy)
                .padding(horizontal = 16.dp, vertical = 10.dp),
        )
    }
}

fun connectionText(): String = when (Td.connection) {
    "waiting" -> tr("در انتظار اینترنت…", "Waiting for network…")
    "proxy" -> tr("در حال اتصال به پروکسی…", "Connecting to proxy…")
    "connecting" -> tr("در حال اتصال…", "Connecting…")
    "updating" -> tr("در حال به‌روزرسانی…", "Updating…")
    else -> ""
}

@Composable
private fun BigButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Green)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = Color.Black, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun AuthScreen(onProxy: () -> Unit) {
    val st = Td.authState
    var phone by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("98") }
    var otp by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var first by remember { mutableStateOf("") }
    var last by remember { mutableStateOf("") }

    when (st) {
        null, is TdApi.AuthorizationStateWaitTdlibParameters, is TdApi.AuthorizationStateClosing,
        is TdApi.AuthorizationStateClosed, is TdApi.AuthorizationStateLoggingOut -> {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircularProgressIndicator(color = Green)
                    Text(connectionText().ifEmpty { tr("لطفاً صبر کن…", "Please wait…") }, color = LocalMahan.current.subtext)
                    Text(
                        tr("تنظیم پروکسی", "Proxy settings"), color = Green, fontSize = 15.sp,
                        modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onProxy).padding(16.dp, 10.dp),
                    )
                }
            }
        }
        is TdApi.AuthorizationStateWaitPhoneNumber -> AuthFrame(
            tr("ورود به MahanTgram", "Sign in to MahanTgram"),
            tr("شماره‌ات را با کد کشور وارد کن", "Enter your phone number with country code"),
            onProxy,
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InputField(code, { code = it.filter { ch -> ch.isDigit() }.take(4) }, "98", Modifier.width(90.dp), KeyboardType.Number, ltr = true)
                InputField(phone, { phone = it.filter { ch -> ch.isDigit() }.take(14) }, "9xx xxx xxxx", Modifier.weight(1f), KeyboardType.Phone, ltr = true)
            }
            BigButton(tr("ادامه", "Continue")) {
                Td.authError = null
                Td.setPhone("+" + code + phone.trimStart('0'))
            }
        }
        is TdApi.AuthorizationStateWaitCode -> AuthFrame(
            tr("کد تأیید", "Verification code"),
            tr("کد ارسال‌شده به ", "The code was sent to ") + st.codeInfo.phoneNumber,
            onProxy,
        ) {
            InputField(otp, { otp = it.filter { ch -> ch.isDigit() }.take(8) }, tr("کد", "Code"), Modifier.fillMaxWidth(), KeyboardType.Number)
            BigButton(tr("تأیید", "Confirm")) {
                Td.authError = null
                Td.submit(mk("CheckAuthenticationCode", "code" to otp))
            }
        }
        is TdApi.AuthorizationStateWaitPassword -> AuthFrame(
            tr("رمز دومرحله‌ای", "Two-step password"),
            if (st.passwordHint.isNotEmpty()) tr("راهنما: ", "Hint: ") + st.passwordHint else tr("رمز حساب را وارد کن", "Enter your account password"),
            onProxy,
        ) {
            InputField(pass, { pass = it }, tr("رمز", "Password"), Modifier.fillMaxWidth(), KeyboardType.Password, password = true)
            BigButton(tr("ورود", "Sign in")) {
                Td.authError = null
                Td.submit(mk("CheckAuthenticationPassword", "password" to pass))
            }
        }
        is TdApi.AuthorizationStateWaitRegistration -> AuthFrame(
            tr("ساخت حساب", "Create account"),
            tr("نام خودت را وارد کن", "Enter your name"),
            onProxy,
        ) {
            InputField(first, { first = it }, tr("نام", "First name"), Modifier.fillMaxWidth())
            InputField(last, { last = it }, tr("نام خانوادگی (اختیاری)", "Last name (optional)"), Modifier.fillMaxWidth())
            BigButton(tr("ادامه", "Continue")) {
                Td.authError = null
                Td.submit(mk("RegisterUser", "firstName" to first, "lastName" to last))
            }
        }
        is TdApi.AuthorizationStateReady -> Unit
        else -> AuthFrame(
            tr("این روش ورود هنوز پشتیبانی نمی‌شود", "This sign-in method is not supported yet"),
            tr("لطفاً با شماره و کد وارد شو.", "Please sign in with a phone number and code."),
            onProxy,
        ) { BigButton(tr("تلاش دوباره", "Try again")) { Td.logOut() } }
    }
}
