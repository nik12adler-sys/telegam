package com.mahan.mahantgram

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

data class DemoChat(val name: String, val last: String, val time: String, val unread: Int, val verified: Boolean = false)

fun demoChats(fa: Boolean): List<DemoChat> = if (fa) listOf(
    DemoChat("علی", "سلام، امروز وقت داری؟", "۲۱:۴۰", 2),
    DemoChat("گروه دوستان", "مهدی: فردا ساعت ۸ همدیگه رو ببینیم", "۲۰:۱۵", 14),
    DemoChat("پیام‌های ذخیره‌شده", "یادداشت ذخیره‌شده", "۱۹:۰۲", 0),
    DemoChat("کانال اخبار", "خبر جدید منتشر شد", "۱۸:۳۰", 5, true),
    DemoChat("مریم", "باشه، ممنون", "۱۷:۴۸", 0),
    DemoChat("پشتیبانی", "درخواست شما ثبت شد", "دیروز", 0, true),
    DemoChat("رضا", "عکس‌ها رو فرستادم", "دیروز", 1),
    DemoChat("گروه کاری", "جلسه فردا لغو شد", "شنبه", 0),
) else listOf(
    DemoChat("Ali", "Hi, are you free today?", "9:40 PM", 2),
    DemoChat("Friends", "Mehdi: Let's meet tomorrow at 8", "8:15 PM", 14),
    DemoChat("Saved Messages", "A saved note", "7:02 PM", 0),
    DemoChat("News Channel", "New article published", "6:30 PM", 5, true),
    DemoChat("Maryam", "Okay, thanks", "5:48 PM", 0),
    DemoChat("Support", "Your request was received", "Yesterday", 0, true),
    DemoChat("Reza", "I sent the photos", "Yesterday", 1),
    DemoChat("Work Group", "Tomorrow's meeting is cancelled", "Sat", 0),
)

private val avatarColors = listOf(
    Color(0xFF2E9E6B), Color(0xFF3B82C4), Color(0xFFB5572F),
    Color(0xFF8A5BC4), Color(0xFFC4455F), Color(0xFF3D8E9E),
)

@Composable
fun ChatListScreen(s: Str, fa: Boolean, topPad: Dp, bottomPad: Dp, query: String, onOpen: (Int) -> Unit) {
    val c = LocalMahan.current
    var folder by remember { mutableIntStateOf(0) }
    val all = remember(fa) { demoChats(fa) }
    val byFolder = when (folder) {
        1 -> all.filter { it.unread > 0 }
        2 -> all.filter { it.name.contains("کانال") || it.name.contains("News") }
        else -> all
    }
    val chats = if (query.isBlank()) byFolder else byFolder.filter {
        it.name.contains(query, ignoreCase = true) || it.last.contains(query, ignoreCase = true)
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = topPad, bottom = bottomPad),
    ) {
        item {
            Row(
                Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Pill(s.folderAll, folder == 0) { folder = 0 }
                Pill(s.folderUnread, folder == 1) { folder = 1 }
                Pill(s.folderNews, folder == 2) { folder = 2 }
            }
        }
        item {
            Text(
                s.demo,
                color = c.subtext,
                fontSize = 12.sp,
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(c.glassTint.copy(alpha = 0.35f))
                    .padding(12.dp),
            )
        }
        items(chats) { ch -> ChatRow(ch) { onOpen(all.indexOf(ch)) } }
    }
}

@Composable
fun ChatRow(chat: DemoChat, onClick: () -> Unit) {
    val c = LocalMahan.current
    val color = avatarColors[abs(chat.name.hashCode()) % avatarColors.size]
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(54.dp).background(color, CircleShape), contentAlignment = Alignment.Center) {
            Text(chat.name.take(1), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    chat.name, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                if (chat.verified) {
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Rounded.Verified, contentDescription = null, tint = VerifiedBlue, modifier = Modifier.size(16.dp))
                }
            }
            Text(
                chat.last, color = c.subtext, fontSize = 14.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(chat.time, color = c.subtext, fontSize = 12.sp)
            if (chat.unread > 0) {
                Box(
                    Modifier
                        .padding(top = 6.dp)
                        .defaultMinSize(minWidth = 22.dp)
                        .height(22.dp)
                        .background(Green, CircleShape)
                        .padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(chat.unread.toString(), color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun PlaceholderScreen(text: String) {
    val c = LocalMahan.current
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = c.subtext, fontSize = 15.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun SettingsScreen(
    s: Str,
    lang: String,
    onLang: (String) -> Unit,
    themeMode: String,
    onTheme: (String) -> Unit,
    blurOn: Boolean,
    onBlur: (Boolean) -> Unit,
    glassAlpha: Float,
    onAlpha: (Float) -> Unit,
    onAccent: (Int) -> Unit = {},
    pattern: Int = 0,
    onPattern: (Int) -> Unit = {},
    topPad: Dp,
    bottomPad: Dp,
    onOpenProfile: () -> Unit,
    onOpenProxy: () -> Unit,
    onShowLogin: () -> Unit,
    live: Boolean = false,
    onSessions: () -> Unit = {},
    onLogout: () -> Unit = {},
    onOpenVault: () -> Unit = {},
    onOpenPremium: () -> Unit = {},
    onOpenHub: () -> Unit = {},
    premium: Boolean = false,
    profileName: String = "MahanTgram",
    profileUser: String = "@username",
) {
    val c = LocalMahan.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(top = topPad, bottom = bottomPad, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // Profile card; the pink bike pops out over its top edge.
        Box(Modifier.fillMaxWidth().padding(top = 70.dp)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(c.glassTint.copy(alpha = 0.45f))
                    .clickable(onClick = onOpenProfile)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(
                    Modifier.size(56.dp).background(Green, CircleShape),
                    contentAlignment = Alignment.Center,
                ) { Text("M", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(profileName, color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(5.dp))
                        Icon(Icons.Rounded.Verified, contentDescription = null, tint = VerifiedBlue, modifier = Modifier.size(18.dp))
                        if (premium) {
                            Spacer(Modifier.width(5.dp))
                            PremiumBadge(Td.me?.statusEmojiId ?: 0L, 18.dp)
                        }
                    }
                    Text(profileUser, color = c.subtext, fontSize = 13.sp)
                }
            }
        }

        if (live) Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                .background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(Color(0xFF8E6CFF), Color(0xFFFF6FB5))))
                .clickable(onClick = onOpenPremium).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(Icons.Rounded.Star, null, tint = Color.White, modifier = Modifier.size(28.dp))
            Column(Modifier.weight(1f)) {
                Text("Telegram Premium", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (premium) tr("فعال است", "Active") else tr("خرید پرمیوم و امکانات ویژه", "Buy Premium and unlock features"),
                    color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp,
                )
            }
            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = Color.White)
        }

        Text(s.appearance, color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold)

        SettingsCard {
            Text(s.language, color = c.text, fontSize = 16.sp)
            Row(
                Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                APP_LANGS.forEach { (code, name) -> Pill(name, lang == code) { onLang(code) } }
            }
        }

        SettingsCard {
            Text(s.theme, color = c.text, fontSize = 16.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill(s.themeSystem, themeMode == "system") { onTheme("system") }
                Pill(s.themeDark, themeMode == "dark") { onTheme("dark") }
                Pill(s.themeLight, themeMode == "light") { onTheme("light") }
            }
        }

        SettingsCard {
            Text(tr("رنگ برنامه", "App color"), color = c.text, fontSize = 16.sp)
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                listOf(
                    0xFF22D17B, 0xFF2D9CFF, 0xFFFF7AB8, 0xFFA66BFF,
                    0xFFFF9F43, 0xFFFF5C5C, 0xFFFFD23F, 0xFF22D3EE,
                ).forEach { argb ->
                    val col = Color(argb.toInt())
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(col)
                            .clickable { onAccent(argb.toInt()) },
                    )
                }
            }
            Text(tr("رنگ دلخواه", "Custom color"), color = c.subtext, fontSize = 13.sp)
            var hue by androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(140f) }
            Slider(
                value = hue,
                onValueChange = { h -> hue = h; onAccent(Color.hsv(h, 0.72f, 0.92f).toArgb()) },
                valueRange = 0f..360f,
            )
        }

        SettingsCard {
            Text(tr("طرح پس‌زمینه", "Background pattern"), color = c.text, fontSize = 16.sp)
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Pill(tr("ساده", "None"), pattern == 0) { onPattern(0) }
                Pill(tr("نقطه", "Dots"), pattern == 1) { onPattern(1) }
                Pill(tr("حلقه", "Rings"), pattern == 2) { onPattern(2) }
                Pill(tr("بعلاوه", "Plus"), pattern == 3) { onPattern(3) }
            }
        }

        SettingsCard {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(s.blur, color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Switch(
                    checked = blurOn,
                    onCheckedChange = onBlur,
                    colors = SwitchDefaults.colors(checkedTrackColor = Green, checkedThumbColor = Color.White),
                )
            }
            Text(s.glassOpacity, color = c.text, fontSize = 16.sp)
            Slider(value = glassAlpha, onValueChange = onAlpha, valueRange = 0.1f..0.9f)
        }

        if (live) SettingsLinkRow(tr("تنظیمات کامل (حساب، حریم خصوصی، اعلان‌ها، داده)", "All settings (account, privacy, notifications, data)"), onOpenHub)
        if (live) SettingsLinkRow(tr("اجی‌مجی (فضای خصوصی رمزدار)", "AjiMaji (private space)"), onOpenVault)
        SettingsLinkRow(s.proxy, onOpenProxy)
        if (live) {
            SettingsLinkRow(tr("دستگاه‌های متصل", "Active sessions"), onSessions)
            SettingsLinkRow(tr("خروج از حساب", "Log out"), onLogout)
        } else {
            SettingsLinkRow(s.showLogin, onShowLogin)
        }

        Text(s.version, color = c.subtext, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun SettingsLinkRow(label: String, onClick: () -> Unit) {
    val c = LocalMahan.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(c.glassTint.copy(alpha = 0.35f))
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = null, tint = Green)
    }
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    val c = LocalMahan.current
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(c.glassTint.copy(alpha = 0.35f))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) { content() }
}
