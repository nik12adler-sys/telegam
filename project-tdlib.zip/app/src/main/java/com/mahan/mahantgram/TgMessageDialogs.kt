package com.mahan.mahantgram

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val Danger = Color(0xFFFF6B6B)

// ====================================================================== forward to one or more chats

@Composable
fun ForwardDialog(m: UiMessage, canCopy: Boolean, onDismiss: () -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val selected = remember { mutableStateListOf<Long>() }
    var query by remember { mutableStateOf("") }
    var asCopy by remember { mutableStateOf(false) }
    var sending by remember { mutableStateOf(false) }
    // Forwarding from inside AjiMaji may target other hidden chats; the public UI never lists them.
    val source = if (Vault.isHidden(m.chatId)) Td.allChats else Td.chats
    // Telegram only lets you forward where you may post, so read-only channels and restricted groups are left out.
    var blocked by remember { mutableStateOf(setOf<Long>()) }
    LaunchedEffect(source.size) {
        val no = HashSet<Long>()
        for (ch in source) if (!Td.canPost(ch.id)) no.add(ch.id)
        blocked = no
    }
    val list = source.filter { it.id !in blocked && (query.isBlank() || it.title.contains(query.trim(), true)) }
    AlertDialog(
        onDismissRequest = { if (!sending) onDismiss() },
        title = { Text(tr("ارسال به…", "Forward to…")) },
        text = {
            Column {
                InputField(query, { query = it }, tr("جست‌وجو", "Search"), Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                LazyColumn(Modifier.height(280.dp)) {
                    items(list, key = { it.id }) { ch ->
                        val on = ch.id in selected
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(enabled = !sending) {
                                if (on) selected.remove(ch.id) else selected.add(ch.id)
                            }.padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Text(if (on) "☑" else "☐", color = if (on) Green else c.subtext, fontSize = 20.sp)
                            Avatar(ch.photoFileId, ch.title, 36.dp)
                            Text(
                                if (ch.saved) tr("پیام‌های ذخیره‌شده", "Saved Messages") else ch.title,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
                if (canCopy) {
                    Text(
                        (if (asCopy) "☑ " else "☐ ") + tr("بدون نام فرستنده اصلی", "Hide original sender"),
                        color = c.text, fontSize = 14.sp,
                        modifier = Modifier.fillMaxWidth().clickable(enabled = !sending) { asCopy = !asCopy }.padding(top = 8.dp),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = selected.isNotEmpty() && !sending,
                onClick = {
                    sending = true
                    scope.launch {
                        val (failed, err) = MsgOps.forwardTo(selected.toList(), m.chatId, m.id, asCopy)
                        when {
                            failed == 0 -> toast(ctx, tr("ارسال شد", "Forwarded"))
                            err != null -> toast(ctx, friendlyError(err))
                        }
                        onDismiss()
                    }
                },
            ) { Text(if (selected.isEmpty()) tr("ارسال", "Send") else trf("ارسال ({0})", "Send ({0})", selected.size)) }
        },
        dismissButton = { TextButton(enabled = !sending, onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}

// ====================================================================== delete

/** Offers exactly the delete choices Telegram allows for this message. */
@Composable
fun DeleteDialog(m: UiMessage, caps: MsgCaps, partner: String, onDismiss: () -> Unit, onDelete: (revoke: Boolean) -> Unit) {
    val both = caps.canDeleteSelf && caps.canDeleteAll
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("حذف پیام", "Delete message")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (both) {
                    val everyone = if (MsgOps.isPrivate(m.chatId) && partner.isNotEmpty())
                        trf("حذف برای من و {0}", "Delete for me and {0}", partner)
                    else tr("حذف برای همه", "Delete for everyone")
                    TextButton(onClick = { onDelete(true) }) { Text(everyone, color = Danger) }
                    TextButton(onClick = { onDelete(false) }) { Text(tr("فقط برای من", "Delete just for me"), color = Danger) }
                } else {
                    Text(tr("این پیام حذف شود؟", "Delete this message?"))
                }
            }
        },
        confirmButton = {
            if (!both) TextButton(onClick = { onDelete(caps.canDeleteAll) }) { Text(tr("حذف", "Delete"), color = Danger) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}

// ====================================================================== pin (private chats: for both or only for me)

@Composable
fun PinDialog(partner: String, onDismiss: () -> Unit, onPin: (onlyForSelf: Boolean) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("سنجاق کردن پیام", "Pin message")) },
        text = {
            Column {
                TextButton(onClick = { onPin(false) }) {
                    Text(if (partner.isNotEmpty()) trf("سنجاق برای من و {0}", "Pin for me and {0}", partner) else tr("سنجاق برای هر دو", "Pin for both"))
                }
                TextButton(onClick = { onPin(true) }) { Text(tr("فقط برای من", "Pin just for me")) }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}

// ====================================================================== report (Telegram's own multi-step dialog)

@Composable
fun ReportDialog(m: UiMessage, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var step by remember { mutableStateOf<ReportStep?>(null) }
    var text by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { step = MsgOps.report(m) }
    when (val s = step) {
        null -> {}
        is ReportStep.Done -> LaunchedEffect(s) { toast(ctx, tr("گزارش ارسال شد", "Report sent")); onDismiss() }
        is ReportStep.Failed -> LaunchedEffect(s) { toast(ctx, s.message); onDismiss() }
        is ReportStep.Options -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(s.title.ifEmpty { tr("گزارش پیام", "Report message") }) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    s.options.forEach { o ->
                        Text(
                            o.text, fontSize = 16.sp,
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable {
                                step = null
                                scope.launch { step = MsgOps.report(m, o.id) }
                            }.padding(vertical = 12.dp),
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
        )
        is ReportStep.Text -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(tr("توضیحات گزارش", "Add details")) },
            text = { InputField(text, { text = it }, if (s.optional) tr("اختیاری", "Optional") else tr("توضیح بده", "Describe the problem"), Modifier.fillMaxWidth()) },
            confirmButton = {
                TextButton(
                    enabled = s.optional || text.isNotBlank(),
                    onClick = {
                        val t = text.trim()
                        step = null
                        scope.launch { step = MsgOps.report(m, s.optionId, t) }
                    },
                ) { Text(tr("ارسال گزارش", "Send report")) }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
        )
    }
}

// ====================================================================== who reacted

@Composable
fun ReactorsDialog(m: UiMessage, emoji: String?, onDismiss: () -> Unit) {
    val c = LocalMahan.current
    var loaded by remember { mutableStateOf(false) }
    var list by remember { mutableStateOf<List<Reactor>?>(null) }
    LaunchedEffect(m.id, emoji) {
        list = MsgOps.reactors(m, emoji)
        loaded = true
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (emoji != null) "$emoji " + tr("واکنش‌ها", "Reactions") else tr("واکنش‌ها", "Reactions")) },
        text = {
            val l = list
            when {
                !loaded -> Text(tr("در حال بارگذاری…", "Loading…"), color = c.subtext)
                l == null -> Text(tr("تلگرام فهرست واکنش‌دهندگان این پیام را نمایش نمی‌دهد.", "Telegram doesn't show who reacted to this message."), color = c.subtext)
                l.isEmpty() -> Text(tr("هنوز واکنشی ثبت نشده", "No reactions yet"), color = c.subtext)
                else -> Column(Modifier.height(260.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    l.forEach { r ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(r.emoji, fontSize = 22.sp)
                            Text(
                                if (r.mine) tr("تو", "You") else r.name,
                                color = c.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f),
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("بستن", "Close")) } },
    )
}
