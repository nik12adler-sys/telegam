@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mahan.mahantgram

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Warn = Color(0xFFFF6B6B)

// ====================================================================== transfer status inside a bubble

/** Upload / download progress with cancel, or the failure reason with retry and delete. */
@Composable
fun TransferBar(m: UiMessage, progress: Float?, onCancel: () -> Unit, onRetry: () -> Unit) {
    val c = LocalMahan.current
    if (m.failed) {
        Column(Modifier.padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "⚠ " + friendlyError(m.sendError.ifEmpty { tr("ارسال ناموفق بود", "Sending failed") }),
                color = Warn, fontSize = 12.sp,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                if (m.canRetry) Text(
                    "🔁 " + tr("تلاش مجدد", "Retry"), color = Green, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onRetry).padding(vertical = 4.dp),
                )
                Text(
                    "🗑 " + tr("حذف", "Delete"), color = c.subtext, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onCancel).padding(vertical = 4.dp),
                )
            }
        }
    } else if (progress != null) {
        Row(Modifier.padding(top = 4.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.weight(1f).height(4.dp), color = Green)
            Text("${(progress * 100).toInt()}%", color = c.subtext, fontSize = 11.sp)
            Text(
                "✕", color = c.subtext, fontSize = 15.sp,
                modifier = Modifier.clip(CircleShape).clickable(onClick = onCancel).padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
    }
}

// ====================================================================== location

@SuppressLint("MissingPermission")
private fun fetchLocation(ctx: Context, onResult: (Double, Double, Double) -> Unit) {
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    try {
        val providers = lm.getProviders(true)
        if (providers.isEmpty()) {
            toast(ctx, tr("موقعیت‌یابی گوشی خاموش است", "Location is turned off on this phone"))
            return
        }
        val last = providers.mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
        if (last != null && System.currentTimeMillis() - last.time < 120_000) {
            onResult(last.latitude, last.longitude, last.accuracy.toDouble())
            return
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val prov = if (LocationManager.GPS_PROVIDER in providers) LocationManager.GPS_PROVIDER else providers.first()
            lm.getCurrentLocation(prov, null, ctx.mainExecutor) { loc ->
                when {
                    loc != null -> onResult(loc.latitude, loc.longitude, loc.accuracy.toDouble())
                    last != null -> onResult(last.latitude, last.longitude, last.accuracy.toDouble())
                    else -> toast(ctx, tr("موقعیت پیدا نشد؛ دوباره امتحان کن", "Could not get a location fix"))
                }
            }
        } else if (last != null) {
            onResult(last.latitude, last.longitude, last.accuracy.toDouble())
        } else {
            toast(ctx, tr("موقعیت پیدا نشد؛ دوباره امتحان کن", "Could not get a location fix"))
        }
    } catch (e: SecurityException) {
        toast(ctx, tr("اجازه‌ی موقعیت مکانی داده نشد", "Location permission denied"))
    }
}

/** Returns a function that asks for the location permission when needed and then reports the position. */
@Composable
fun rememberLocationRequester(onResult: (Double, Double, Double) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) fetchLocation(ctx, onResult)
        else toast(ctx, tr("اجازه‌ی موقعیت مکانی داده نشد", "Location permission denied"))
    }
    return {
        val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fine || coarse) fetchLocation(ctx, onResult)
        else launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }
}

// ====================================================================== contact

private class PickPhone : ActivityResultContract<Unit, Uri?>() {
    override fun createIntent(context: Context, input: Unit): Intent =
        Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)

    override fun parseResult(resultCode: Int, intent: Intent?): Uri? =
        if (resultCode == Activity.RESULT_OK) intent?.data else null
}

/** Picks one contact from the phone's address book. No READ_CONTACTS permission is needed: the system picker grants just that row. */
@Composable
fun rememberPhoneContactPicker(onPicked: (phone: String, first: String, last: String) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(PickPhone()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching {
            ctx.contentResolver.query(
                uri,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
                null, null, null,
            )?.use { cur ->
                if (cur.moveToFirst()) {
                    val number = cur.getString(0) ?: ""
                    val name = (cur.getString(1) ?: "").trim()
                    onPicked(number, name.substringBefore(' '), name.substringAfter(' ', ""))
                }
            }
        }.onFailure { toast(ctx, tr("مخاطب خوانده نشد", "Could not read the contact")) }
    }
    return { launcher.launch(Unit) }
}

@Composable
fun ContactSendDialog(onDismiss: () -> Unit, onPhone: () -> Unit, onTelegram: (UiUser) -> Unit) {
    val c = LocalMahan.current
    LaunchedEffect(Unit) { runCatching { Td.loadContacts() } }
    val hidden = Td.hiddenUserIds
    val list = Td.contacts.filter { it.phone.isNotEmpty() && it.id !in hidden }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("ارسال مخاطب", "Send a contact")) },
        text = {
            LazyColumn(Modifier.height(320.dp)) {
                item {
                    Text(
                        tr("📱 از دفترچه‌ی تلفن گوشی", "📱 From the phone's address book"), color = Green, fontSize = 16.sp,
                        modifier = Modifier.fillMaxWidth().clickable { onDismiss(); onPhone() }.padding(vertical = 12.dp),
                    )
                }
                items(list.size) { i ->
                    val u = list[i]
                    Row(
                        Modifier.fillMaxWidth().clickable { onDismiss(); onTelegram(u) }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Avatar(u.photoFileId, u.name, 36.dp)
                        Column {
                            Text(u.name, color = c.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("+" + u.phone, color = c.subtext, fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}

// ====================================================================== emoji / sticker / GIF panel

private val EMOJI = listOf(
    "😀" to "😀 😃 😄 😁 😆 😅 😂 🤣 🥲 ☺️ 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥸 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🫣 🤭 🫢 🤫 🤥 😶 😐 😑 😬 🫠 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 ☠️ 👽 👾 🤖 🎃",
    "👍" to "👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐 🖖 👋 🤝 🙏 ✍️ 💪 👏 🙌 👐 🤲 🫶 🫰 🤌 🤏 ✊ 👊 🤛 🤜",
    "❤️" to "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ♥️ 😻 💋 💯 💢 💥 💫 💦 💨 💬 💭 💤",
    "🐶" to "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🐢 🐍 🦎 🐙 🦑 🦀 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🐘 🦒 🐪 🌵 🌲 🌳 🌴 🌱 🌿 🍀 🌸 🌼 🌻 🌹 🍁 🍂",
    "🍎" to "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🥑 🥦 🥕 🌽 🌶 🍞 🧀 🍗 🍖 🌭 🍔 🍟 🍕 🌮 🌯 🥗 🍝 🍜 🍲 🍣 🍤 🍚 🍦 🍩 🍪 🎂 🍰 🍫 🍬 🍭 ☕ 🍵 🥤 🍺 🍻 🥂 🍷",
    "⚽" to "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🏸 🥊 🎯 ⛳ 🎣 🎮 🎲 🎰 🎳 🎭 🎨 🎬 🎤 🎧 🎸 🎹 🥁 🎺 🎻 🏆 🥇 🥈 🥉 🏅",
    "🚗" to "🚗 🚕 🚙 🚌 🏎 🚓 🚑 🚒 🚚 🏍 🚲 ✈️ 🚀 🛸 🚁 ⛵ 🚢 🏠 🏢 🏰 🗼 🗽 ⛰ 🌋 🏝 🌅 🌃 🌉 🌍 🌙 ⭐ 🌟 ☀️ ⛅ 🌧 ⛈ ❄️ 🌈 🔥 💧 🌊",
    "💡" to "⌚ 📱 💻 ⌨️ 🖥 📷 📹 📺 ☎️ 🔋 🔌 💡 🔦 💰 💳 💎 🔧 🔨 ⚙️ 🔒 🔓 🔑 📌 📎 ✂️ 📝 📚 📖 📅 ✉️ 📦 🎁 🎈 🎉 🎊",
    "✅" to "✅ ❌ ⭕ ❗ ❓ ‼️ ⚠️ 🚫 ✔️ ➕ ➖ ➡️ ⬅️ ⬆️ ⬇️ 🔄 🔔 🔕 🔊 🔇 ♻️ ⚡ ✨ 🆗 🆕 🆒 🔝 ℹ️ ©️ ®️ ™️",
).map { (icon, all) -> icon to all.split(' ').filter { it.isNotEmpty() } }

@Composable
fun MediaPanel(chatId: Long, onEmoji: (String) -> Unit, onSticker: (PanelSticker) -> Unit, onGif: (PanelGif) -> Unit) {
    val c = LocalMahan.current
    var tab by remember { mutableIntStateOf(1) }
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.fillMaxWidth().height(300.dp).clip(shape).background(c.glassTint.copy(alpha = 0.92f)).border(1.dp, c.glassBorder, shape),
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1 to "😀 " + tr("ایموجی", "Emoji"), 2 to "🏷 " + tr("استیکر", "Stickers"), 3 to "GIF").forEach { (id, label) ->
                Text(
                    label, fontSize = 14.sp, color = if (tab == id) Color.Black else c.text,
                    modifier = Modifier.clip(CircleShape).background(if (tab == id) Green else Color.Transparent)
                        .clickable { tab = id }.padding(horizontal = 14.dp, vertical = 6.dp),
                )
            }
        }
        when (tab) {
            1 -> EmojiTab(onEmoji)
            2 -> StickerTab(onSticker)
            else -> GifTab(chatId, onGif)
        }
    }
}

@Composable
private fun EmojiTab(onEmoji: (String) -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    var recents by remember { mutableStateOf(EmojiStore.recent(ctx)) }
    var query by remember { mutableStateOf("") }
    var found by remember { mutableStateOf<List<String>>(emptyList()) }
    var cat by remember { mutableIntStateOf(if (recents.isEmpty()) 0 else -1) }
    LaunchedEffect(query) {
        if (query.isBlank()) { found = emptyList(); return@LaunchedEffect }
        delay(300)
        found = EmojiStore.search(query.trim())
    }
    val shown = when {
        query.isNotBlank() -> found
        cat == -1 -> recents
        else -> EMOJI[cat.coerceIn(0, EMOJI.size - 1)].second
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
        InputField(query, { query = it }, tr("جست‌وجوی ایموجی", "Search emoji"), Modifier.fillMaxWidth())
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            if (recents.isNotEmpty()) Text(
                "🕘", fontSize = 20.sp,
                modifier = Modifier.clip(CircleShape).background(if (cat == -1 && query.isBlank()) Green.copy(alpha = 0.35f) else Color.Transparent)
                    .clickable { cat = -1; query = "" }.padding(8.dp),
            )
            EMOJI.forEachIndexed { i, (icon, _) ->
                Text(
                    icon, fontSize = 20.sp,
                    modifier = Modifier.clip(CircleShape).background(if (cat == i && query.isBlank()) Green.copy(alpha = 0.35f) else Color.Transparent)
                        .clickable { cat = i; query = "" }.padding(8.dp),
                )
            }
        }
        if (shown.isEmpty()) {
            Text(
                if (query.isNotBlank()) tr("ایموجی‌ای پیدا نشد", "No emoji found") else tr("هنوز ایموجی اخیری نیست", "No recent emoji yet"),
                color = c.subtext, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(24.dp), textAlign = TextAlign.Center,
            )
        } else {
            LazyVerticalGrid(GridCells.Adaptive(42.dp), Modifier.fillMaxSize()) {
                items(shown) { e ->
                    Text(
                        e, fontSize = 26.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable {
                            EmojiStore.push(ctx, e)
                            recents = EmojiStore.recent(ctx)
                            onEmoji(e)
                        }.padding(vertical = 6.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun StickerCell(s: PanelSticker, onClick: () -> Unit, onLong: () -> Unit, menu: @Composable () -> Unit = {}) {
    val file = s.previewFile
    if (file != null) LaunchedEffect(file.id) { Td.registerFile(file, true) }
    val bmp = rememberBitmap(file?.let { Td.files[it.id] }, 200)
    Box(Modifier.size(76.dp).combinedClickable(onClick = onClick, onLongClick = onLong), contentAlignment = Alignment.Center) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize().padding(4.dp), contentScale = ContentScale.Fit)
        else Text(s.emoji, fontSize = 30.sp)
        menu()
    }
}

@Composable
private fun StickerTab(onSticker: (PanelSticker) -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var sets by remember { mutableStateOf<List<PanelSet>>(emptyList()) }
    var recents by remember { mutableStateOf<List<PanelSticker>>(emptyList()) }
    var favs by remember { mutableStateOf<List<PanelSticker>>(emptyList()) }
    var current by remember { mutableLongStateOf(-1L) } // -1 recents, -2 favorites, otherwise a set id
    var inSet by remember { mutableStateOf<List<PanelSticker>>(emptyList()) }
    var tick by remember { mutableIntStateOf(0) }
    var adding by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<PanelSticker?>(null) }
    var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(tick) {
        sets = StickerRepo.sets()
        recents = StickerRepo.recent()
        favs = StickerRepo.favorites()
        loaded = true
    }
    LaunchedEffect(current, tick) { if (current >= 0) inSet = StickerRepo.inSet(current) }
    val shown = when (current) {
        -1L -> recents
        -2L -> favs
        else -> inSet
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🕘", fontSize = 20.sp, modifier = Modifier.clip(CircleShape).background(if (current == -1L) Green.copy(alpha = 0.35f) else Color.Transparent).clickable { current = -1 }.padding(8.dp))
            Text("⭐", fontSize = 20.sp, modifier = Modifier.clip(CircleShape).background(if (current == -2L) Green.copy(alpha = 0.35f) else Color.Transparent).clickable { current = -2 }.padding(8.dp))
            sets.forEach { st ->
                val cover = st.cover
                if (cover != null) LaunchedEffect(cover.id) { Td.registerFile(cover, true) }
                val bmp = rememberBitmap(cover?.let { Td.files[it.id] }, 96)
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(if (current == st.id) Green.copy(alpha = 0.35f) else Color.Transparent)
                        .clickable { current = st.id }.padding(4.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    if (bmp != null) Image(bmp, null, Modifier.fillMaxSize()) else Text(st.title.take(1), color = c.text, fontSize = 14.sp)
                }
            }
            Text("＋", fontSize = 20.sp, color = Green, modifier = Modifier.clip(CircleShape).clickable { adding = true }.padding(8.dp))
        }
        if (shown.isEmpty()) {
            Text(
                when {
                    !loaded -> tr("در حال بارگذاری…", "Loading…")
                    current == -2L -> tr("استیکر محبوبی نداری؛ روی یک استیکر نگه دار.", "No favorites yet; long-press a sticker.")
                    current == -1L -> tr("هنوز استیکر اخیری نیست", "No recent stickers yet")
                    else -> tr("استیکری نیست", "No stickers")
                },
                color = c.subtext, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(24.dp), textAlign = TextAlign.Center,
            )
        } else {
            LazyVerticalGrid(GridCells.Adaptive(76.dp), Modifier.fillMaxSize()) {
                items(shown) { s ->
                    StickerCell(s, onClick = { onSticker(s) }, onLong = { menuFor = s }) {
                        DropdownMenu(expanded = menuFor === s, onDismissRequest = { menuFor = null }) {
                            val isFav = favs.any { it.fileId == s.fileId }
                            DropdownMenuItem(
                                text = { Text(if (isFav) tr("حذف از علاقه‌مندی‌ها", "Remove from favorites") else tr("افزودن به علاقه‌مندی‌ها", "Add to favorites")) },
                                onClick = {
                                    menuFor = null
                                    scope.launch {
                                        StickerRepo.setFavorite(s, !isFav)?.let { toast(ctx, friendlyError(it)) }
                                        tick++
                                    }
                                },
                            )
                        }
                    }
                }
            }
        }
    }
    if (adding) {
        var link by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { if (!busy) adding = false },
            title = { Text(tr("افزودن پک استیکر", "Add a sticker pack")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    InputField(link, { link = it }, "t.me/addstickers/…", Modifier.fillMaxWidth())
                    Text(tr("لینک یا نام پک را وارد کن.", "Enter the pack link or name."), color = c.subtext, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(enabled = !busy && link.isNotBlank(), onClick = {
                    busy = true
                    scope.launch {
                        val err = StickerRepo.addSet(link)
                        busy = false
                        if (err != null) toast(ctx, friendlyError(err)) else { adding = false; tick++ }
                    }
                }) { Text(tr("افزودن", "Add")) }
            },
            dismissButton = { TextButton(onClick = { if (!busy) adding = false }) { Text(tr("لغو", "Cancel")) } },
        )
    }
}

@Composable
private fun GifTab(chatId: Long, onGif: (PanelGif) -> Unit) {
    val c = LocalMahan.current
    var query by remember { mutableStateOf("") }
    var gifs by remember { mutableStateOf<List<PanelGif>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(query) {
        loading = true
        if (query.isNotBlank()) delay(400)
        gifs = if (query.isBlank()) GifRepo.saved().ifEmpty { GifRepo.search(chatId, "") } else GifRepo.search(chatId, query.trim())
        loading = false
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
        InputField(query, { query = it }, tr("جست‌وجوی GIF", "Search GIFs"), Modifier.fillMaxWidth())
        if (gifs.isEmpty()) {
            Text(
                if (loading) tr("در حال بارگذاری…", "Loading…") else tr("GIF پیدا نشد", "No GIFs found"),
                color = c.subtext, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(24.dp), textAlign = TextAlign.Center,
            )
        } else {
            LazyVerticalGrid(GridCells.Fixed(2), Modifier.fillMaxSize().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(gifs) { g ->
                    val file = g.previewFile
                    if (file != null) LaunchedEffect(file.id) { Td.registerFile(file, true) }
                    val bmp = rememberBitmap(file?.let { Td.files[it.id] }, 400)
                    Box(
                        Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(10.dp)).background(c.glassTint.copy(alpha = 0.6f)).clickable { onGif(g) },
                    ) {
                        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        Text("GIF", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomStart).padding(6.dp).background(Color(0x88000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp))
                    }
                }
            }
        }
    }
}

