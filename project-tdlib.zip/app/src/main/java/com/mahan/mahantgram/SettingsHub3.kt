package com.mahan.mahantgram

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi
import java.security.MessageDigest
import java.security.SecureRandom

/** App passcode (4-8 digits, stored only as a salted hash) with optional fingerprint unlock. */
object AppLock {
    private var sp: SharedPreferences? = null
    var hasPin by mutableStateOf(false)
    var useBio by mutableStateOf(false)
    var delaySec by mutableIntStateOf(0)
    var locked by mutableStateOf(false)
    private var leftAt = 0L
    private var external = false

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("mahan_lock", Context.MODE_PRIVATE)
        sp = p
        hasPin = p.getString("hash", null) != null
        useBio = p.getBoolean("bio", false)
        delaySec = p.getInt("delay", 0)
        locked = hasPin
    }

    private fun hash(salt: String, pin: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        sp?.edit()?.putString("salt", salt)?.putString("hash", hash(salt, pin))?.apply()
        hasPin = true
    }

    fun check(pin: String): Boolean {
        val p = sp ?: return false
        return p.getString("hash", null) == hash(p.getString("salt", "") ?: "", pin)
    }

    fun clear() {
        sp?.edit()?.clear()?.apply()
        hasPin = false; useBio = false; delaySec = 0; locked = false
    }

    fun saveBio(v: Boolean) { useBio = v; sp?.edit()?.putBoolean("bio", v)?.apply() }
    fun saveDelay(v: Int) { delaySec = v; sp?.edit()?.putInt("delay", v)?.apply() }

    fun noteExternalLaunch() { external = true }
    fun onStop(changingConfig: Boolean) { if (hasPin && !changingConfig && !external) leftAt = System.currentTimeMillis() }
    fun onStart() {
        if (hasPin && leftAt > 0 && System.currentTimeMillis() - leftAt >= delaySec * 1000L) locked = true
        leftAt = 0; external = false
    }

    fun bioAvailable(ctx: Context): Boolean =
        Build.VERSION.SDK_INT >= 29 && ctx.getSystemService(BiometricManager::class.java)?.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS

    fun promptBio(activity: Activity, onOk: () -> Unit) {
        if (Build.VERSION.SDK_INT < 28) return
        val prompt = BiometricPrompt.Builder(activity)
            .setTitle(tr("باز کردن قفل", "Unlock"))
            .setNegativeButton(tr("لغو", "Cancel"), activity.mainExecutor) { _, _ -> }
            .build()
        prompt.authenticate(CancellationSignal(), activity.mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) { onOk() }
        })
    }
}

@Composable
fun AppLockOverlay() {
    if (!AppLock.locked) return
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { if (AppLock.useBio && activity != null) AppLock.promptBio(activity) { AppLock.locked = false } }
    Box(Modifier.fillMaxSize().background(Color(0xFF0B0D10)).clickable(enabled = false) {}, contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text(tr("کد قفل را وارد کنید", "Enter passcode"), color = Color.White, fontSize = 20.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                repeat(maxOf(4, pin.length)) { i ->
                    Box(Modifier.size(14.dp).clip(CircleShape).background(if (i < pin.length) Green else Color(0x55FFFFFF)))
                }
            }
            if (wrong) Text(tr("کد اشتباه است", "Wrong passcode"), color = Red, fontSize = 14.sp)
            listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("bio", "0", "ok")).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    row.forEach { k ->
                        val label = when (k) { "bio" -> if (AppLock.useBio) "☝" else ""; "ok" -> "⌫"; else -> k }
                        Box(
                            Modifier.size(68.dp).clip(CircleShape).background(if (label.isEmpty()) Color.Transparent else Color(0x22FFFFFF)).clickable(enabled = label.isNotEmpty()) {
                                wrong = false
                                when (k) {
                                    "bio" -> activity?.let { a -> AppLock.promptBio(a) { AppLock.locked = false } }
                                    "ok" -> pin = pin.dropLast(1)
                                    else -> {
                                        if (pin.length < 8) pin += k
                                        if (pin.length >= 4 && AppLock.check(pin)) { AppLock.locked = false; pin = "" }
                                        else if (pin.length == 8) { wrong = true; pin = "" }
                                    }
                                }
                            },
                            contentAlignment = Alignment.Center,
                        ) { Text(label, color = Color.White, fontSize = 24.sp) }
                    }
                }
            }
        }
    }
}

@Composable
internal fun PasscodeRows() {
    val ctx = LocalContext.current
    var dlg by remember { mutableStateOf("") }
    SValueRow(tr("قفل با رمز", "Passcode lock"), if (AppLock.hasPin) tr("روشن", "On") else tr("خاموش", "Off")) { dlg = if (AppLock.hasPin) "off" else "set" }
    if (AppLock.hasPin) {
        SValueRow(tr("قفل خودکار بعد از", "Auto-lock after"), when (AppLock.delaySec) { 0 -> tr("بلافاصله", "Immediately"); 60 -> tr("۱ دقیقه", "1 minute"); 300 -> tr("۵ دقیقه", "5 minutes"); else -> tr("۱ ساعت", "1 hour") }) { dlg = "delay" }
        if (AppLock.bioAvailable(ctx)) SSwitchRow(tr("قفل با اثر انگشت", "Fingerprint unlock"), tr("باز کردن با اثر انگشت یا چهره", "Unlock with biometrics"), AppLock.useBio) { AppLock.saveBio(it) }
    }
    when (dlg) {
        "set" -> {
            var a by remember { mutableStateOf("") }
            var b by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { dlg = "" },
                title = { Text(tr("تعیین کد قفل (۴ تا ۸ رقم)", "Set passcode (4-8 digits)")) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(a, { a = it.filter(Char::isDigit).take(8) }, singleLine = true, label = { Text(tr("کد", "Passcode")) }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword), visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                        OutlinedTextField(b, { b = it.filter(Char::isDigit).take(8) }, singleLine = true, label = { Text(tr("تکرار کد", "Repeat")) }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword), visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                    }
                },
                confirmButton = { TextButton(enabled = a.length >= 4 && a == b, onClick = { AppLock.setPin(a); dlg = "" }) { Text(tr("ذخیره", "Save")) } },
                dismissButton = { TextButton(onClick = { dlg = "" }) { Text(tr("لغو", "Cancel")) } },
            )
        }
        "off" -> {
            var a by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { dlg = "" },
                title = { Text(tr("خاموش کردن قفل", "Turn off passcode")) },
                text = { OutlinedTextField(a, { a = it.filter(Char::isDigit).take(8) }, singleLine = true, label = { Text(tr("کد فعلی", "Current passcode")) }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword), visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()) },
                confirmButton = { TextButton(onClick = { if (AppLock.check(a)) { AppLock.clear(); dlg = "" } else toast(ctx, tr("کد اشتباه است", "Wrong passcode")) }) { Text(tr("خاموش", "Turn off"), color = Red) } },
                dismissButton = { TextButton(onClick = { dlg = "" }) { Text(tr("لغو", "Cancel")) } },
            )
        }
        "delay" -> {
            val opts = listOf(0, 60, 300, 3600)
            RadioDialog(tr("قفل خودکار", "Auto-lock"), listOf(tr("بلافاصله", "Immediately"), tr("۱ دقیقه", "1 minute"), tr("۵ دقیقه", "5 minutes"), tr("۱ ساعت", "1 hour")), opts.indexOf(AppLock.delaySec), { dlg = "" }) { AppLock.saveDelay(opts[it]); dlg = "" }
        }
    }
}

/** Change phone number: TDLib sends a code to the new number, then the code confirms it. */
@Composable
internal fun ChangePhoneDialog(onDismiss: () -> Unit, ctx: Context) {
    val scope = rememberCoroutineScope()
    var phone by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var sent by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("تغییر شماره", "Change number")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!sent) OutlinedTextField(phone, { phone = it.filter { c -> c.isDigit() || c == '+' } }, singleLine = true, label = { Text(tr("شماره‌ی جدید با کد کشور", "New number with country code")) }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Phone))
                else {
                    Text(tr("کد ارسال‌شده را وارد کنید.", "Enter the code that was sent."))
                    OutlinedTextField(code, { code = it.filter(Char::isDigit) }, singleLine = true, label = { Text(tr("کد", "Code")) }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number))
                }
            }
        },
        confirmButton = {
            TextButton(enabled = if (sent) code.isNotEmpty() else phone.length >= 7, onClick = {
                scope.launch {
                    if (!sent) {
                        val e = Td.tryReq(mk("ChangePhoneNumber", "phoneNumber" to phone, "settings" to mk<TdApi.Object>("PhoneNumberAuthenticationSettings")))
                        if (e != null) toast(ctx, e) else sent = true
                    } else {
                        val e = Td.tryReq(mk("CheckChangePhoneNumberCode", "code" to code))
                        if (e != null) toast(ctx, e) else onDismiss()
                    }
                }
            }) { Text(if (sent) tr("تأیید", "Confirm") else tr("ارسال کد", "Send code")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}
