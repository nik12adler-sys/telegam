package com.mahan.mahantgram

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

object Accent {
    var color by mutableStateOf(Color(0xFF22D17B))
}

val Green: Color get() = Accent.color
val VerifiedBlue = Color(0xFF2D9CFF)

data class MahanColors(
    val bg: Color,
    val bgTop: Color,
    val glassTint: Color,
    val glassBorder: Color,
    val text: Color,
    val subtext: Color,
)

val DarkMahan = MahanColors(
    bg = Color(0xFF0B0D10),
    bgTop = Color(0xFF171B21),
    glassTint = Color(0xFF2B3038),
    glassBorder = Color.White.copy(alpha = 0.14f),
    text = Color(0xFFF2F4F6),
    subtext = Color(0xFF9AA3AD),
)

val LightMahan = MahanColors(
    bg = Color(0xFFEDEFF1),
    bgTop = Color(0xFFFFFFFF),
    glassTint = Color.White,
    glassBorder = Color.Black.copy(alpha = 0.08f),
    text = Color(0xFF111418),
    subtext = Color(0xFF66707A),
)

val LocalMahan = staticCompositionLocalOf { DarkMahan }

@Composable
fun MahanTheme(dark: Boolean, content: @Composable () -> Unit) {
    val colors = (if (dark) DarkMahan else LightMahan).let { if (dark && AppPrefs.amoled) it.copy(bg = Color.Black, bgTop = Color.Black) else it }
    val scheme = if (dark) {
        darkColorScheme(primary = Green, background = colors.bg, surface = colors.bg)
    } else {
        lightColorScheme(primary = Green, background = colors.bg, surface = colors.bg)
    }
    CompositionLocalProvider(LocalMahan provides colors) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
