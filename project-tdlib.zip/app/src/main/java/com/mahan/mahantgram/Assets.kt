package com.mahan.mahantgram

// width / height of each vehicle image
const val CAR_ASPECT = 1912f / 1340f
const val BMW_ASPECT = 0.7733f
const val PINK_ASPECT = 0.9506f
