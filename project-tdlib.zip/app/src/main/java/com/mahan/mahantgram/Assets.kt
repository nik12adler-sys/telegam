package com.mahan.mahantgram

// width / height of the car image
const val CAR_ASPECT = 1912f / 1340f
