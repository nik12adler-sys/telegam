package com.mahan.mahantgram

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

// Decorative background pattern drawn with vectors (no image files).
// kind: 0 = none, 1 = dots, 2 = rings, 3 = plus signs
@Composable
fun PatternBackground(kind: Int, color: Color, modifier: Modifier = Modifier) {
    if (kind == 0) return
    Canvas(modifier) {
        val step = 56.dp.toPx()
        val cols = (size.width / step).toInt() + 2
        val rows = (size.height / step).toInt() + 2
        val stroke = 1.5.dp.toPx()
        for (r in 0 until rows) {
            for (i in 0 until cols) {
                val cx = i * step + (if (r % 2 == 0) 0f else step / 2f)
                val cy = r * step
                when (kind) {
                    1 -> drawCircle(color, 2.5.dp.toPx(), Offset(cx, cy))
                    2 -> drawCircle(color, 9.dp.toPx(), Offset(cx, cy), style = Stroke(stroke))
                    else -> {
                        val a = 7.dp.toPx()
                        drawLine(color, Offset(cx - a, cy), Offset(cx + a, cy), stroke)
                        drawLine(color, Offset(cx, cy - a), Offset(cx, cy + a), stroke)
                    }
                }
            }
        }
    }
}
