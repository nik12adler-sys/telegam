package com.mahan.mahantgram

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.LruCache
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

object BitmapCache {
    private val cache = LruCache<String, ImageBitmap>(150)
    fun get(path: String, maxPx: Int): ImageBitmap? = cache.get("$path@$maxPx")
    fun load(path: String, maxPx: Int): ImageBitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var s = 1
        while (bounds.outWidth / (s * 2) >= maxPx && bounds.outHeight / (s * 2) >= maxPx) s *= 2
        val b = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
        val img = b.asImageBitmap()
        cache.put("$path@$maxPx", img)
        return img
    }
}

@Composable
fun rememberBitmap(path: String?, maxPx: Int = 512): ImageBitmap? {
    if (path == null) return null
    val state = produceState<ImageBitmap?>(BitmapCache.get(path, maxPx), path, maxPx) {
        if (value == null) value = withContext(Dispatchers.IO) { BitmapCache.load(path, maxPx) }
    }
    return state.value
}

private val avColors = listOf(
    Color(0xFF2E9E6B), Color(0xFF3B82C4), Color(0xFFB5572F),
    Color(0xFF8A5BC4), Color(0xFFC4455F), Color(0xFF3D8E9E),
)

@Composable
fun Avatar(fileId: Int, title: String, size: Dp) {
    val path = if (fileId != 0) Td.files[fileId] else null
    val bmp = rememberBitmap(path, 200)
    Box(
        Modifier.size(size).clip(CircleShape).background(avColors[abs(title.hashCode()) % avColors.size]),
        contentAlignment = Alignment.Center,
    ) {
        if (bmp != null) {
            Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text(title.take(1), color = Color.White, fontSize = (size.value * 0.4f).sp, fontWeight = FontWeight.Bold)
        }
    }
}

object AudioPlayer {
    var current by mutableStateOf<String?>(null)
    private var mp: MediaPlayer? = null

    fun toggle(path: String) {
        if (current == path) { stop(); return }
        stop()
        runCatching {
            mp = MediaPlayer().apply {
                setDataSource(path)
                setOnCompletionListener { stop() }
                prepare()
                start()
            }
            current = path
        }
    }

    fun stop() {
        runCatching { mp?.stop(); mp?.release() }
        mp = null
        current = null
    }
}

fun toast(ctx: Context, text: String) = Toast.makeText(ctx, text, Toast.LENGTH_SHORT).show()

fun copyUriToCache(ctx: Context, uri: Uri): String? = runCatching {
    var name = "file"
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) name = c.getString(i)
    }
    val dir = File(ctx.cacheDir, "up").apply { mkdirs() }
    val out = File(dir, "${System.currentTimeMillis()}_$name")
    ctx.contentResolver.openInputStream(uri)!!.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
    out.absolutePath
}.getOrNull()

fun openFile(ctx: Context, path: String) {
    runCatching {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(path))
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(File(path).extension.lowercase()) ?: "*/*"
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
        )
    }.onFailure { toast(ctx, tr("برنامه‌ای برای باز کردن این فایل نیست", "No app can open this file")) }
}

/** Single-line text input styled for the glass theme. */
@Composable
fun InputField(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    keyboard: KeyboardType = KeyboardType.Text,
    password: Boolean = false,
    ltr: Boolean = false,
) {
    val c = LocalMahan.current
    Box(
        modifier
            .height(52.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(c.glassTint.copy(alpha = 0.5f))
            .border(1.dp, c.glassBorder, RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = c.text, fontSize = 16.sp),
            cursorBrush = SolidColor(Green),
            keyboardOptions = KeyboardOptions(keyboardType = keyboard),
            visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
            modifier = Modifier.padding(0.dp),
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) Text(hint, color = c.subtext, fontSize = 16.sp)
                    inner()
                }
            },
        )
    }
}
