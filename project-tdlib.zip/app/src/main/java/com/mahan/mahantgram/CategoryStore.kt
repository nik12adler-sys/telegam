package com.mahan.mahantgram

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * One chat category. Built-in categories are rule based (computed from real TDLib chat data);
 * custom categories hold an explicit set of chat ids, so one chat can live in several of them.
 * name = "" on a built-in category means "use the default localized label".
 */
data class ChatCategory(
    val id: String,
    val name: String,
    val builtin: Boolean,
    val chatIds: Set<Long> = emptySet(),
)

object CategoryStore {
    const val ALL = "all"
    private val BUILTIN = listOf("all", "personal", "groups", "channels", "bots", "unread", "private")
    private const val MAX_NAME = 24

    private var prefs: SharedPreferences? = null

    var categories by mutableStateOf(defaults())
        private set
    var selectedId by mutableStateOf(ALL)
        private set

    private fun defaults(): List<ChatCategory> = BUILTIN.map { ChatCategory(it, "", true) }

    fun init(context: Context) {
        prefs = context.getSharedPreferences("chat_categories", Context.MODE_PRIVATE)
        load()
    }

    // ------------------------------------------------------------ labels and matching

    fun label(c: ChatCategory): String {
        if (c.name.isNotBlank()) return c.name
        return when (c.id) {
            "all" -> tr("همه", "All")
            "personal" -> tr("شخصی", "Personal")
            "groups" -> tr("گروه‌ها", "Groups")
            "channels" -> tr("کانال‌ها", "Channels")
            "bots" -> tr("ربات‌ها", "Bots")
            "unread" -> tr("خوانده‌نشده", "Unread")
            "private" -> tr("خصوصی", "Private")
            else -> c.id
        }
    }

    /** Every built-in rule uses real TDLib data: chat type, bot user type, unread counter, secret chat type. */
    fun matches(cat: ChatCategory, chat: UiChat): Boolean {
        if (!cat.builtin) return chat.id in cat.chatIds
        return when (cat.id) {
            "all" -> true
            "personal" -> chat.kind == ChatKind.PRIVATE && !chat.bot
            "groups" -> chat.kind == ChatKind.GROUP
            "channels" -> chat.kind == ChatKind.CHANNEL
            "bots" -> chat.bot
            "unread" -> chat.unread > 0
            "private" -> chat.secret
            else -> false
        }
    }

    fun missingDefaults(): Boolean = BUILTIN.any { id -> categories.none { it.id == id } }

    // ------------------------------------------------------------ editing

    fun select(id: String) {
        if (categories.any { it.id == id }) {
            selectedId = id
            prefs?.edit()?.putString("selected", id)?.apply()
        }
    }

    private fun clean(name: String): String = name.trim().take(MAX_NAME)

    /** Creates a custom category and returns its id, or null when the name is blank. */
    fun create(name: String): String? {
        val n = clean(name)
        if (n.isEmpty()) return null
        val id = "c_" + UUID.randomUUID().toString().take(8)
        categories = categories + ChatCategory(id, n, false)
        save()
        return id
    }

    fun rename(id: String, name: String): Boolean {
        val n = clean(name)
        if (n.isEmpty()) return false
        categories = categories.map { c ->
            if (c.id != id) c else {
                // Renaming a built-in back to its default label clears the override.
                val reset = c.builtin && n == label(c.copy(name = ""))
                c.copy(name = if (reset) "" else n)
            }
        }
        save()
        return true
    }

    /** "All" can never be deleted, so there is always a category to fall back to. */
    fun delete(id: String): Boolean {
        if (id == ALL) return false
        categories = categories.filter { it.id != id }
        if (selectedId == id) select(ALL)
        save()
        return true
    }

    fun restoreDefaults() {
        val missing = BUILTIN.filter { id -> categories.none { it.id == id } }
        if (missing.isEmpty()) return
        categories = categories + missing.map { ChatCategory(it, "", true) }
        save()
    }

    fun toggleChat(categoryId: String, chatId: Long) {
        categories = categories.map { c ->
            if (c.id != categoryId || c.builtin) c
            else c.copy(chatIds = if (chatId in c.chatIds) c.chatIds - chatId else c.chatIds + chatId)
        }
        save()
    }

    // ------------------------------------------------------------ AjiMaji support

    /** Custom categories a chat belongs to (built-in categories are rule based, nothing is stored for them). */
    fun membership(chatId: Long): List<String> =
        categories.filter { !it.builtin && chatId in it.chatIds }.map { it.id }

    /** Removes a chat from every stored category, so a hidden chat leaves no trace in the public store. */
    fun detachChat(chatId: Long) {
        if (categories.none { chatId in it.chatIds }) return
        categories = categories.map { if (chatId in it.chatIds) it.copy(chatIds = it.chatIds - chatId) else it }
        save()
    }

    /** Puts a chat back into the categories it was in; categories deleted meanwhile are skipped. */
    fun attachChat(chatId: Long, ids: Collection<String>) {
        if (ids.isEmpty()) return
        val set = ids.toSet()
        categories = categories.map { c ->
            if (!c.builtin && c.id in set) c.copy(chatIds = c.chatIds + chatId) else c
        }
        save()
    }

    // ------------------------------------------------------------ persistence

    private fun save() {
        val p = prefs ?: return
        val arr = JSONArray()
        for (c in categories) {
            arr.put(
                JSONObject()
                    .put("id", c.id)
                    .put("name", c.name)
                    .put("builtin", c.builtin)
                    .put("chats", JSONArray().also { a -> c.chatIds.forEach { a.put(it) } }),
            )
        }
        p.edit().putString("categories", arr.toString()).apply()
    }

    private fun load() {
        val p = prefs ?: return
        val raw = p.getString("categories", null)
        if (raw != null) {
            runCatching {
                val arr = JSONArray(raw)
                val out = ArrayList<ChatCategory>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val ids = HashSet<Long>()
                    o.optJSONArray("chats")?.let { a -> for (j in 0 until a.length()) ids.add(a.getLong(j)) }
                    val builtin = o.optBoolean("builtin")
                    val id = o.getString("id")
                    if (builtin && id !in BUILTIN) continue
                    out.add(ChatCategory(id, o.optString("name", ""), builtin, ids))
                }
                if (out.none { it.id == ALL }) out.add(0, ChatCategory(ALL, "", true))
                categories = out
            }
        }
        val sel = p.getString("selected", ALL) ?: ALL
        selectedId = if (categories.any { it.id == sel }) sel else ALL
    }
}
