package com.mahan.mahantgram

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Avatar with a story ring: state 0 = no ring, 1 = all seen (grey), 2 = unseen (accent gradient). */
@Composable
fun StoryAvatar(fileId: Int, title: String, size: Dp, state: Int) {
    val c = LocalMahan.current
    if (state == 0) {
        Avatar(fileId, title, size)
        return
    }
    val ring = if (state == 2) Brush.sweepGradient(listOf(Green, VerifiedBlue, Green))
    else Brush.linearGradient(listOf(c.subtext.copy(alpha = 0.6f), c.subtext.copy(alpha = 0.6f)))
    Box(
        Modifier.size(size + 8.dp).border(if (state == 2) 2.5.dp else 1.5.dp, ring, CircleShape),
        contentAlignment = Alignment.Center,
    ) { Avatar(fileId, title, size) }
}

/** The stories bar on top of the chat list: own story slot first, then everyone else's. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun StoriesBar(onOpen: (Long) -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var preparing by remember { mutableStateOf(false) }
    // The picked file, waiting in the composer for a caption and a preview: path to isVideo.
    var draft by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    var manage by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        val video = ctx.contentResolver.getType(uri)?.startsWith("video") == true
        preparing = true
        scope.launch {
            // Copying a video can take a while, so it never runs on the main thread.
            val path = withContext(Dispatchers.IO) { copyUriToCache(ctx, uri) }
            preparing = false
            if (path == null) toast(ctx, tr("فایل خوانده نشد", "Could not read the file"))
            else draft = path to video
        }
    }
    fun launchPicker() {
        if (!preparing) pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
    }
    val me = Td.me
    val mine = Td.stories.firstOrNull { it.mine }
    val others = Td.stories.filter { !it.mine }

    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Own story: tap = watch (or add the first one), long press = manage, + = add another
        Column(
            Modifier.width(68.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier.size(64.dp).clip(CircleShape).combinedClickable(
                    onClick = { if (mine != null) onOpen(mine.chatId) else launchPicker() },
                    onLongClick = { if (mine != null) manage = true },
                ),
                contentAlignment = Alignment.Center,
            ) {
                StoryAvatar(me?.photoFileId ?: 0, me?.name?.ifEmpty { null } ?: "؟", 56.dp, if (mine == null) 0 else if (mine.unseen) 2 else 1)
                Box(
                    Modifier.align(Alignment.BottomEnd).size(22.dp).background(Green, CircleShape)
                        .border(2.dp, c.bg, CircleShape)
                        .clickable { launchPicker() },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Add, null, tint = Color.Black, modifier = Modifier.size(16.dp)) }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                if (preparing) tr("در حال آماده‌سازی…", "Preparing…") else tr("استوری من", "My story"),
                color = c.subtext, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            )
        }
        others.forEach { st ->
            Column(
                Modifier.width(68.dp).clickable { onOpen(st.chatId) },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
                    StoryAvatar(st.photoFileId, st.title, 56.dp, if (st.unseen) 2 else 1)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    st.title, color = if (st.unseen) c.text else c.subtext, fontSize = 12.sp,
                    fontWeight = if (st.unseen) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                )
            }
        }
    }
    draft?.let { (path, video) -> StoryComposerDialog(path, video) { draft = null } }
    if (manage) MyStoriesDialog(onDismiss = { manage = false }, onView = { manage = false; onOpen(Td.meId) }, onAdd = { launchPicker() })
}

private const val PHOTO_STORY_MS = 5000f

/**
 * Full-screen story viewer for one chat.
 * Tap right/left half = next/previous, hold = pause, the first tap-left on the first story replays it.
 * Own stories also show the view count, the viewers list, delete and the manage list.
 */
@Composable
fun StoryViewer(chatId: Long, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val own = chatId == Td.meId
    var ids by remember { mutableStateOf<List<Int>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var index by remember { mutableIntStateOf(0) }
    var story by remember { mutableStateOf<Td.UiStory?>(null) }
    var extra by remember { mutableStateOf<StoryExtra?>(null) }
    var holding by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var failed by remember { mutableStateOf(false) }
    var restart by remember { mutableIntStateOf(0) }
    var confirmDelete by remember { mutableStateOf(false) }
    var showViewers by remember { mutableStateOf(false) }
    var manage by remember { mutableStateOf(false) }
    var bmpOk by remember { mutableStateOf(false) }
    val title = Td.chatById(chatId)?.let { if (it.saved) tr("استوری من", "My story") else it.title } ?: ""

    // The story stands still while the user holds the screen or a dialog is open.
    fun halted() = holding || confirmDelete || showViewers || manage

    LaunchedEffect(chatId) {
        val (list, start) = runCatching { StoryOps.idsWithStart(chatId) }.getOrDefault(emptyList<Int>() to 0)
        ids = list
        index = start
        loaded = true
        if (list.isEmpty()) {
            toast(ctx, tr("استوری‌ای وجود ندارد", "No stories"))
            onClose()
        }
    }
    LaunchedEffect(ids, index, restart) {
        story = null
        extra = null
        failed = false
        bmpOk = false
        progress = 0f
        val id = ids.getOrNull(index) ?: return@LaunchedEffect
        val loadedStory = runCatching { Td.story(chatId, id) }.getOrNull()
        story = loadedStory
        if (loadedStory == null) failed = true
        extra = StoryOps.extra(chatId, id)
        Td.openStory(chatId, id)
    }
    DisposableEffect(ids, index) {
        val id = ids.getOrNull(index)
        onDispose { if (id != null) Td.closeStory(chatId, id) }
    }

    fun next() { if (index + 1 < ids.size) index++ else onClose() }
    fun prev() { if (index > 0) index-- else restart++ } // first story: start it over

    val st = story
    val path = st?.let { Td.files[it.fileId] }

    // A file that never arrives is reported instead of showing a black screen forever.
    LaunchedEffect(st?.id, restart) {
        if (st == null) return@LaunchedEffect
        delay(20000)
        if (Td.files[st.fileId] == null) failed = true
    }
    // Photos fill the progress bar over five seconds, but only once the picture is really on screen.
    LaunchedEffect(st?.id, path, restart) {
        if (st == null || st.isVideo || path == null) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (progress < 1f) {
            val now = withFrameNanos { it }
            if (!halted() && !failed && bmpOk) progress += (now - last) / (PHOTO_STORY_MS * 1_000_000f)
            last = now
        }
        progress = 1f
        next()
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().background(Color.Black)
                .pointerInput(ids.size) {
                    detectTapGestures(
                        onPress = { holding = true; tryAwaitRelease(); holding = false },
                        onTap = { pos -> if (pos.x > size.width / 2f) next() else prev() },
                    )
                },
        ) {
            if (st != null && path != null && !failed) {
                if (st.isVideo) {
                    StoryVideo(
                        path = path, paused = halted(), restartKey = restart,
                        onProgress = { progress = it },
                        onEnded = { next() },
                        onError = { failed = true },
                    )
                } else {
                    val bmp = rememberBitmap(path, 2048)
                    LaunchedEffect(bmp) { if (bmp != null) bmpOk = true }
                    // A picture that cannot be decoded is an error, not an endless spinner.
                    LaunchedEffect(path) { delay(6000); if (!bmpOk) failed = true }
                    if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                }
            } else if (!failed) {
                val thumb = rememberBitmap(st?.let { Td.files[it.thumbFileId] }, 600)
                if (thumb != null) Image(thumb, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            }
            Column(Modifier.fillMaxWidth().statusBarsPadding().padding(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (i in ids.indices) {
                        val fill = if (i < index) 1f else if (i == index) progress.coerceIn(0f, 1f) else 0f
                        Box(Modifier.weight(1f).height(3.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.3f))) {
                            Box(Modifier.fillMaxWidth(fill).height(3.dp).background(Color.White))
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(Td.chatById(chatId)?.photoFileId ?: 0, title, 36.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (st != null && st.date > 0) {
                            val left = StoryOps.remaining(extra)
                            Text(
                                Td.fmtTime(st.date) + (if (left != null) " · $left" else ""),
                                color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp,
                            )
                        }
                    }
                    Icon(
                        Icons.Rounded.Close, null, tint = Color.White,
                        modifier = Modifier.clip(CircleShape).clickable(onClick = onClose).padding(6.dp),
                    )
                }
            }
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding()) {
                if (st != null && st.caption.isNotEmpty()) {
                    Text(
                        st.caption, color = Color.White, fontSize = 15.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().background(Color.Black.copy(alpha = 0.45f)).padding(16.dp),
                    )
                }
                if (own && st != null) {
                    Row(
                        Modifier.fillMaxWidth().background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        Row(
                            Modifier.weight(1f).clip(CircleShape).clickable(enabled = extra?.canSeeViewers == true) { showViewers = true }.padding(6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Rounded.Visibility, null, tint = Color.White, modifier = Modifier.size(20.dp))
                            Text(" ${extra?.viewCount ?: 0}", color = Color.White, fontSize = 14.sp)
                        }
                        Text(
                            tr("مدیریت", "Manage"), color = Color.White, fontSize = 14.sp,
                            modifier = Modifier.clip(CircleShape).clickable { manage = true }.padding(8.dp),
                        )
                        if (extra?.canDelete != false) Icon(
                            Icons.Rounded.Delete, null, tint = Color(0xFFFF6B6B),
                            modifier = Modifier.clip(CircleShape).clickable { confirmDelete = true }.padding(6.dp),
                        )
                    }
                }
            }
            if (failed) {
                Column(
                    Modifier.align(Alignment.Center).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        tr("بارگذاری این استوری ممکن نشد", "This story could not be loaded"),
                        color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Center,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { restart++ }) { Text(tr("تلاش دوباره", "Try again")) }
                        TextButton(onClick = { next() }) { Text(tr("بعدی", "Next")) }
                    }
                }
            } else if (loaded && st == null && ids.isNotEmpty()) {
                Text("…", color = Color.White, fontSize = 28.sp, modifier = Modifier.align(Alignment.Center))
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(tr("حذف استوری", "Delete story")) },
            text = { Text(tr("این استوری برای همه حذف می‌شود.", "This story will be removed for everyone.")) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    val id = ids.getOrNull(index) ?: return@TextButton
                    scope.launch {
                        val err = StoryOps.delete(chatId, id)
                        if (err != null) {
                            toast(ctx, friendlyError(err))
                        } else {
                            val rest = ids.filter { it != id }
                            if (rest.isEmpty()) onClose()
                            else {
                                index = index.coerceAtMost(rest.size - 1)
                                ids = rest
                            }
                        }
                    }
                }) { Text(tr("حذف", "Delete"), color = Color(0xFFFF6B6B)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(tr("لغو", "Cancel")) } },
        )
    }
    if (showViewers) ids.getOrNull(index)?.let { id -> StoryViewersDialog(id) { showViewers = false } }
    if (manage) MyStoriesDialog(onDismiss = { manage = false }, onView = { manage = false }, onAdd = null)
}

/** Plays a story video; reports progress (0..1), the end, and playback errors. */
@Composable
private fun StoryVideo(path: String, paused: Boolean, restartKey: Int, onProgress: (Float) -> Unit, onEnded: () -> Unit, onError: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember(path, restartKey) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(File(path))))
            repeatMode = Player.REPEAT_MODE_OFF
            prepare()
            playWhenReady = true
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_ENDED) onEnded() }
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) { onError() }
            })
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    LaunchedEffect(paused, player) { player.playWhenReady = !paused }
    LaunchedEffect(player) {
        while (true) {
            val d = player.duration
            if (d > 0) onProgress((player.currentPosition.toFloat() / d).coerceIn(0f, 1f))
            delay(100)
        }
    }
    AndroidView(
        factory = { PlayerView(it).apply { this.player = player; useController = false } },
        modifier = Modifier.fillMaxSize(),
    )
}
