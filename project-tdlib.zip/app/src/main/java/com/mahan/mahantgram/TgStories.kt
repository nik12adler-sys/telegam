package com.mahan.mahantgram

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

/** Avatar with a story ring: state 0 = no ring, 1 = all seen (grey), 2 = unseen (accent gradient). */
@Composable
fun StoryAvatar(fileId: Int, title: String, size: Dp, state: Int) {
    val c = LocalMahan.current
    if (state == 0) {
        Avatar(fileId, title, size)
        return
    }
    val ring = if (state == 2) Brush.sweepGradient(listOf(Green, VerifiedBlue, Green))
    else Brush.linearGradient(listOf(c.subtext.copy(alpha = 0.6f), c.subtext.copy(alpha = 0.6f)))
    Box(
        Modifier.size(size + 8.dp).border(if (state == 2) 2.5.dp else 1.5.dp, ring, CircleShape),
        contentAlignment = Alignment.Center,
    ) { Avatar(fileId, title, size) }
}

/** The stories bar on top of the chat list: own story slot first, then everyone else's. */
@Composable
fun StoriesBar(onOpen: (Long) -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var posting by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        val path = copyUriToCache(ctx, uri)
        if (path == null) {
            toast(ctx, tr("فایل خوانده نشد", "Could not read the file"))
            return@rememberLauncherForActivityResult
        }
        posting = true
        scope.launch {
            val err = Td.postPhotoStory(path)
            posting = false
            toast(ctx, err ?: tr("استوری منتشر شد", "Story posted"))
        }
    }
    val me = Td.me
    val mine = Td.stories.firstOrNull { it.mine }
    val others = Td.stories.filter { !it.mine }

    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Own story
        Column(
            Modifier.width(68.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier.size(64.dp).clip(CircleShape).clickable {
                    if (mine != null) onOpen(mine.chatId) else if (!posting) pick.launch("image/*")
                },
                contentAlignment = Alignment.Center,
            ) {
                StoryAvatar(me?.photoFileId ?: 0, me?.name?.ifEmpty { null } ?: "؟", 56.dp, if (mine == null) 0 else if (mine.unseen) 2 else 1)
                Box(
                    Modifier.align(Alignment.BottomEnd).size(22.dp).background(Green, CircleShape)
                        .border(2.dp, c.bg, CircleShape)
                        .clickable { if (!posting) pick.launch("image/*") },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.Add, null, tint = Color.Black, modifier = Modifier.size(16.dp)) }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                if (posting) tr("در حال ارسال…", "Posting…") else tr("استوری من", "My story"),
                color = c.subtext, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            )
        }
        others.forEach { st ->
            Column(
                Modifier.width(68.dp).clickable { onOpen(st.chatId) },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(Modifier.size(64.dp), contentAlignment = Alignment.Center) {
                    StoryAvatar(st.photoFileId, st.title, 56.dp, if (st.unseen) 2 else 1)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    st.title, color = if (st.unseen) c.text else c.subtext, fontSize = 12.sp,
                    fontWeight = if (st.unseen) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                )
            }
        }
    }
}

/** Full-screen story viewer for one chat. Tap right/left half = next/previous, close button top. */
@Composable
fun StoryViewer(chatId: Long, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var ids by remember { mutableStateOf<List<Int>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var index by remember { mutableIntStateOf(0) }
    var story by remember { mutableStateOf<Td.UiStory?>(null) }
    val title = Td.chatById(chatId)?.let { if (it.saved) tr("استوری من", "My story") else it.title } ?: ""

    LaunchedEffect(chatId) {
        ids = runCatching { Td.storyIds(chatId) }.getOrDefault(emptyList())
        loaded = true
        if (ids.isEmpty()) {
            toast(ctx, tr("استوری‌ای وجود ندارد", "No stories"))
            onClose()
        }
    }
    LaunchedEffect(ids, index) {
        story = null
        val id = ids.getOrNull(index) ?: return@LaunchedEffect
        story = runCatching { Td.story(chatId, id) }.getOrNull()
        Td.openStory(chatId, id)
    }
    DisposableEffect(ids, index) {
        val id = ids.getOrNull(index)
        onDispose { if (id != null) Td.closeStory(chatId, id) }
    }

    fun next() { if (index + 1 < ids.size) index++ else onClose() }
    fun prev() { if (index > 0) index-- }

    val st = story
    val path = st?.let { Td.files[it.fileId] }
    // Photos advance on a timer; videos advance when they end.
    LaunchedEffect(st?.id, path) {
        if (st != null && !st.isVideo && path != null) {
            delay(5000)
            next()
        }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().background(Color.Black)
                .pointerInput(ids.size) {
                    detectTapGestures { pos -> if (pos.x > size.width / 2f) next() else prev() }
                },
        ) {
            if (st != null && path != null) {
                if (st.isVideo) {
                    StoryVideo(path) { next() }
                } else {
                    val bmp = rememberBitmap(path, 2048)
                    if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                }
            } else {
                val thumb = rememberBitmap(st?.let { Td.files[it.thumbFileId] }, 600)
                if (thumb != null) Image(thumb, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            }
            Column(Modifier.fillMaxWidth().statusBarsPadding().padding(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (i in ids.indices) {
                        Box(
                            Modifier.weight(1f).height(3.dp).clip(CircleShape)
                                .background(if (i <= index) Color.White else Color.White.copy(alpha = 0.3f)),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(Td.chatById(chatId)?.photoFileId ?: 0, title, 36.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (st != null && st.date > 0) Text(Td.fmtTime(st.date), color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                    }
                    Icon(
                        Icons.Rounded.Close, null, tint = Color.White,
                        modifier = Modifier.clip(CircleShape).clickable(onClick = onClose).padding(6.dp),
                    )
                }
            }
            if (st != null && st.caption.isNotEmpty()) {
                Text(
                    st.caption, color = Color.White, fontSize = 15.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.45f)).padding(16.dp),
                )
            }
            if (loaded && st == null && ids.isNotEmpty()) {
                Text("…", color = Color.White, fontSize = 28.sp, modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
private fun StoryVideo(path: String, onEnded: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember(path) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(File(path))))
            repeatMode = Player.REPEAT_MODE_OFF
            prepare()
            playWhenReady = true
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) { if (state == Player.STATE_ENDED) onEnded() }
            })
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { PlayerView(it).apply { this.player = player; useController = false } },
        modifier = Modifier.fillMaxSize(),
    )
}
