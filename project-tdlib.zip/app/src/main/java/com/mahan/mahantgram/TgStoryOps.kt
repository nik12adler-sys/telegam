package com.mahan.mahantgram

import android.media.MediaMetadataRetriever
import org.drinkless.tdlib.TdApi

// ====================================================================== step 6: story operations
// Posting, deleting, viewers and expiry all go through real TDLib calls. Fields are read by name,
// so a field that one TDLib version lacks cannot break the build.

/** Extra facts about one story that Td.story() does not carry. */
class StoryExtra(
    val canDelete: Boolean,
    val canSeeViewers: Boolean,
    val viewCount: Int,
    val expiresAt: Long, // unix seconds, 0 = unknown
    val expiresExact: Boolean, // false when TDLib did not report it and 24 h after posting is assumed
    val privacy: Int, // 0 everyone, 1 contacts, 2 close friends, 3 selected people, -1 unknown
)

class StoryViewerRow(val name: String, val time: Int, val reaction: String)

class OwnStory(val id: Int, val ui: Td.UiStory?, val extra: StoryExtra?)

object StoryOps {
    const val MAX_VIDEO_SECONDS = 60.0

    /** Telegram allows 200 caption characters, Premium users 2048. */
    fun captionLimit(): Int = if (Td.me?.premium == true) 2048 else 200

    /** Duration of a local video in seconds (0 when it cannot be read). Run off the main thread. */
    fun videoDuration(path: String): Double = runCatching {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(path)
            (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000.0
        } finally {
            r.release()
        }
    }.getOrDefault(0.0)

    /**
     * Publishes a photo or video story on the user's own page.
     * privacy: 0 everyone, 1 contacts, 2 close friends. period: seconds the story stays up.
     * Returns an error text or null.
     */
    suspend fun post(path: String, video: Boolean, caption: String, period: Int, privacy: Int, duration: Double): String? = try {
        val file = mk<TdApi.Object>("InputFileLocal", "path" to path)
        val content = if (video) mk<TdApi.Object>(
            "InputStoryContentVideo", "video" to file, "duration" to duration,
            "coverFrameTimestamp" to 0.0, "isAnimation" to false,
        ) else mk<TdApi.Object>("InputStoryContentPhoto", "photo" to file)
        val settings = mk<TdApi.Object>(
            when (privacy) {
                1 -> "StoryPrivacySettingsContacts"
                2 -> "StoryPrivacySettingsCloseFriends"
                else -> "StoryPrivacySettingsEveryone"
            },
        )
        Td.tryReq(
            mk(
                "PostStory",
                "chatId" to Td.meId,
                "content" to content,
                "areas" to mk<TdApi.Object>("InputStoryAreas"),
                "caption" to ft(caption),
                "privacySettings" to settings,
                "activePeriod" to period,
                "isPostedToChatPage" to false,
                "protectContent" to false,
            ),
        )
    } catch (e: Throwable) {
        e.message ?: "error"
    }

    /** Deletes one of the user's own stories. Returns an error text or null. */
    suspend fun delete(chatId: Long, storyId: Int): String? = try {
        Td.tryReq(mk("DeleteStory", "storyPosterChatId" to chatId, "storyId" to storyId))
    } catch (e: Throwable) {
        e.message ?: "error"
    }

    /** Story ids (oldest first) and the index to start at: the first story the user has not seen yet. */
    suspend fun idsWithStart(chatId: Long): Pair<List<Int>, Int> {
        val a = Td.req(mk<TdApi.Object>("GetChatActiveStories", "chatId" to chatId))
        val infos = a.fieldOrNull("stories") as? Array<*> ?: return emptyList<Int>() to 0
        val ids = infos.mapNotNull { (it?.fieldOrNull("storyId") as? Number)?.toInt() }
        val maxRead = (a.fieldOrNull("maxReadStoryId") as? Number)?.toInt() ?: 0
        val start = if (chatId == Td.meId) 0 else ids.indexOfFirst { it > maxRead }.let { if (it < 0) 0 else it }
        return ids to start
    }

    /** Rights, view count, expiry and privacy of one story, from the real Story object. */
    suspend fun extra(chatId: Long, storyId: Int): StoryExtra? = try {
        val st = Td.req(mk<TdApi.Object>("GetStory", "storyPosterChatId" to chatId, "storyId" to storyId, "onlyLocal" to false))
        val date = (st.fieldOrNull("date") as? Number)?.toLong() ?: 0L
        val exp = (st.fieldOrNull("expirationDate") as? Number)?.toLong() ?: 0L
        val info = st.fieldOrNull("interactionInfo")
        val views = (info?.fieldOrNull("viewCount") as? Number)?.toInt() ?: 0
        val privacy = when (st.fieldOrNull("privacySettings")?.javaClass?.simpleName) {
            "StoryPrivacySettingsEveryone" -> 0
            "StoryPrivacySettingsContacts" -> 1
            "StoryPrivacySettingsCloseFriends" -> 2
            "StoryPrivacySettingsSelectedUsers" -> 3
            else -> -1
        }
        StoryExtra(
            canDelete = (st.fieldOrNull("canBeDeleted") as? Boolean) ?: (chatId == Td.meId),
            canSeeViewers = (st.fieldOrNull("canGetInteractions") as? Boolean) ?: false,
            viewCount = views,
            expiresAt = if (exp > 0) exp else if (date > 0) date + 86400 else 0L,
            expiresExact = exp > 0,
            privacy = privacy,
        )
    } catch (e: Throwable) {
        null
    }

    /** Every active story of the user, with its details, for the management list. */
    suspend fun own(): List<OwnStory> {
        val me = Td.meId
        val ids = runCatching { idsWithStart(me).first }.getOrDefault(emptyList())
        return ids.map { id ->
            OwnStory(id, runCatching { Td.story(me, id) }.getOrNull(), extra(me, id))
        }
    }

    /** People who saw the story (total, list). null = Telegram does not allow reading them. */
    suspend fun viewers(storyId: Int): Pair<Int, List<StoryViewerRow>>? = try {
        val r = Td.req(
            mk<TdApi.Object>(
                "GetStoryInteractions", "storyId" to storyId, "query" to "", "onlyContacts" to false,
                "preferForwards" to false, "preferWithReaction" to false, "offset" to "", "limit" to 100,
            ),
        )
        val total = (r.fieldOrNull("totalCount") as? Number)?.toInt() ?: 0
        val rows = (r.fieldOrNull("interactions") as? Array<*>)?.mapNotNull { a ->
            if (a == null) return@mapNotNull null
            val name = when (val s = a.fieldOrNull("actorId")) {
                is TdApi.MessageSenderUser -> runCatching { Td.loadUser(s.userId) }.getOrNull()
                    ?.let { "${it.firstName} ${it.lastName}".trim() } ?: s.userId.toString()
                is TdApi.MessageSenderChat -> Td.rawChat(s.chatId)?.title ?: s.chatId.toString()
                else -> ""
            }
            val time = ((a.fieldOrNull("interactionDate") ?: a.fieldOrNull("interactionTime")) as? Number)?.toInt() ?: 0
            val reaction = (a.fieldOrNull("type")?.fieldOrNull("chosenReactionType") as? TdApi.ReactionTypeEmoji)?.emoji ?: ""
            StoryViewerRow(name, time, reaction)
        } ?: emptyList()
        total to rows
    } catch (e: Throwable) {
        null
    }

    /** "5h 12m left"; null when the expiry is unknown. A leading ≈ means it is estimated. */
    fun remaining(e: StoryExtra?): String? {
        if (e == null || e.expiresAt <= 0L) return null
        val left = e.expiresAt - System.currentTimeMillis() / 1000
        if (left <= 0) return tr("منقضی شده", "Expired")
        val h = left / 3600
        val m = (left % 3600) / 60
        val t = if (h > 0) trf("{0} ساعت و {1} دقیقه", "{0}h {1}m", h, m) else trf("{0} دقیقه", "{0}m", maxOf(1L, m))
        return (if (e.expiresExact) "" else "≈ ") + trf("{0} مانده", "{0} left", t)
    }

    fun privacyLabel(p: Int): String = when (p) {
        0 -> tr("همه", "Everyone")
        1 -> tr("مخاطبین", "Contacts")
        2 -> tr("دوستان نزدیک", "Close friends")
        3 -> tr("افراد انتخابی", "Selected people")
        else -> ""
    }
}
