package com.mahan.mahantgram

import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** A vehicle that drives in once, then floats, over a glowing neon floor. */
@Composable
fun HeroStage(img: Int, aspect: Float, accent: Color, modifier: Modifier = Modifier, height: Dp = 230.dp) {
    val drive = remember { Animatable(0f) }
    LaunchedEffect(Unit) { drive.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
    BoxWithConstraints(modifier.fillMaxWidth().height(height)) {
        val imgH = minOf(height - 10.dp, maxWidth * 0.8f / aspect)
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(0.9f)
                .height(34.dp)
                .drawBehind {
                    drawOval(
                        brush = Brush.horizontalGradient(
                            listOf(Color.Transparent, accent.copy(alpha = 0.6f), Color.Transparent),
                        ),
                        topLeft = Offset.Zero,
                        size = Size(size.width, size.height),
                    )
                },
        )
        Image(
            painter = painterResource(img),
            contentDescription = null,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 8.dp)
                .height(imgH)
                .graphicsLayer {
                    translationX = -(1f - drive.value) * 700f
                    alpha = drive.value
                },
        )
    }
}

@Composable
fun EmptyTab(title: String, sub: String, tag: String, img: Int, aspect: Float, accent: Color, topPad: Dp) {
    val c = LocalMahan.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(top = topPad + 12.dp, bottom = 120.dp, start = 28.dp, end = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        HeroStage(img, aspect, accent, height = 270.dp)
        Text(title, color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(sub, color = c.subtext, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 24.sp)
        Text(
            tag,
            color = c.subtext,
            fontSize = 11.sp,
            modifier = Modifier
                .clip(CircleShape)
                .background(c.glassTint.copy(alpha = 0.5f))
                .padding(horizontal = 12.dp, vertical = 4.dp),
        )
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val c = LocalMahan.current
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.glassTint.copy(alpha = 0.35f))
            .border(1.dp, c.glassBorder, shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) { content() }
}

@Composable
fun BackButton(onBack: () -> Unit) {
    val c = LocalMahan.current
    Box(
        Modifier
            .size(42.dp)
            .clip(CircleShape)
            .background(c.glassTint.copy(alpha = 0.5f))
            .border(1.dp, c.glassBorder, CircleShape)
            .clickable(onClick = onBack),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = null, tint = c.text)
    }
}

// ---------------------------------------------------------------- Splash

@Composable
fun SplashScreen(s: Str, onDone: () -> Unit) {
    val runs = remember { List(3) { Animatable(0f) } }
    LaunchedEffect(Unit) {
        launch { runs[0].animateTo(1f, tween(1300, easing = FastOutSlowInEasing)) }
        launch { delay(200); runs[1].animateTo(1f, tween(1300, easing = FastOutSlowInEasing)) }
        launch { delay(400); runs[2].animateTo(1f, tween(1300, easing = FastOutSlowInEasing)) }
        delay(1800)
        onDone()
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0F3A27), Color(0xFF07090B)))),
    ) {
        Column(
            Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 110.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.size(104.dp).clip(CircleShape).background(Green), contentAlignment = Alignment.Center) {
                Image(
                    painterResource(R.drawable.ic_launcher_foreground),
                    contentDescription = null,
                    modifier = Modifier.size(150.dp),
                )
            }
            Spacer(Modifier.height(24.dp))
            Text(s.appName, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(s.tagline, color = Color(0xFF9FD9BD), fontSize = 14.sp)
        }
        // Vehicles always drive left to right, regardless of the language direction.
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            BoxWithConstraints(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 80.dp)
                    .fillMaxWidth()
                    .height(130.dp),
            ) {
                val widthPx = with(LocalDensity.current) { maxWidth.toPx() }
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(2.dp)
                        .background(Brush.horizontalGradient(listOf(Color.Transparent, Green, Color.Transparent))),
                )
                val items = listOf(
                    Triple(R.drawable.car_gtr_small, CAR_ASPECT, 66.dp),
                    Triple(R.drawable.bike_bmw, BMW_ASPECT, 112.dp),
                    Triple(R.drawable.bike_pink, PINK_ASPECT, 104.dp),
                )
                items.forEachIndexed { i, (res, aspect, h) ->
                    Image(
                        painter = painterResource(res),
                        contentDescription = null,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(bottom = 3.dp)
                            .height(h)
                            .graphicsLayer { translationX = -400f + runs[i].value * (widthPx + 800f) },
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Login

@Composable
fun LoginScreen(s: Str, onContinue: () -> Unit) {
    val c = LocalMahan.current
    var phone by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("98") }
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        HeroStage(R.drawable.bike_bmw, BMW_ASPECT, VerifiedBlue, height = 250.dp)
        Text(s.loginTitle, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(s.loginSub, color = c.subtext, fontSize = 14.sp, textAlign = TextAlign.Center)
        GlassCard {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(c.glassTint.copy(alpha = 0.5f))
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("+", color = Green, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        BasicTextField(
                            value = code,
                            onValueChange = { code = it.filter { ch -> ch.isDigit() }.take(4) },
                            singleLine = true,
                            textStyle = TextStyle(color = Green, fontSize = 17.sp, fontWeight = FontWeight.Bold),
                            cursorBrush = SolidColor(Green),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.width(44.dp),
                        )
                    }
                    Box(Modifier.width(1.dp).height(24.dp).background(c.glassBorder))
                    BasicTextField(
                        value = phone,
                        onValueChange = { phone = it.filter { ch -> ch.isDigit() || ch == ' ' }.take(14) },
                        singleLine = true,
                        textStyle = TextStyle(color = c.text, fontSize = 17.sp),
                        cursorBrush = SolidColor(Green),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner ->
                            Box {
                                if (phone.isEmpty()) Text("9xx xxx xxxx", color = c.subtext, fontSize = 17.sp)
                                inner()
                            }
                        },
                    )
                }
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Green)
                    .clickable(onClick = onContinue),
                contentAlignment = Alignment.Center,
            ) {
                Text(s.loginContinue, color = Color.Black, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text(s.loginDemo, color = c.subtext, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

// ---------------------------------------------------------------- Profile

@Composable
private fun ActionTile(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    val c = LocalMahan.current
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .clip(shape)
            .background(c.glassTint.copy(alpha = 0.45f))
            .border(1.dp, c.glassBorder, shape)
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, contentDescription = null, tint = c.text)
        Text(label, color = c.text, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
fun ProfileScreen(s: Str, onBack: () -> Unit, onOpenSettings: () -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    var pillSel by remember { mutableIntStateOf(0) }
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .navigationBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth()) { BackButton(onBack) }
        Box(
            Modifier
                .size(112.dp)
                .border(4.dp, Green.copy(alpha = 0.3f), CircleShape)
                .padding(4.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Green, VerifiedBlue))),
            contentAlignment = Alignment.Center,
        ) { Text("M", color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Bold) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("MahanTgram", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(5.dp))
            Icon(Icons.Rounded.Verified, contentDescription = null, tint = VerifiedBlue, modifier = Modifier.size(20.dp))
        }
        Text(s.online, color = Green, fontSize = 14.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionTile(Icons.Rounded.AddAPhoto, s.setPhoto, Modifier.weight(1f)) { Toast.makeText(ctx, s.afterConnect, Toast.LENGTH_SHORT).show() }
            ActionTile(Icons.Rounded.Edit, s.editInfo, Modifier.weight(1f)) { Toast.makeText(ctx, s.afterConnect, Toast.LENGTH_SHORT).show() }
            ActionTile(Icons.Rounded.Settings, s.settings, Modifier.weight(1f), onOpenSettings)
        }
        GlassCard {
            InfoRow("+98 9•• ••• ••••", s.mobile)
            InfoRow(s.bioValue, s.bio)
            InfoRow("@username", s.username)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(s.posts, pillSel == 0) { pillSel = 0 }
            Pill(s.archived, pillSel == 1) { pillSel = 1 }
            Pill(s.gifts, pillSel == 2) { pillSel = 2 }
        }
        // Garage: the whole fleet on one glowing floor.
        Box(Modifier.fillMaxWidth().height(130.dp)) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth(0.9f)
                    .height(30.dp)
                    .drawBehind {
                        drawOval(
                            brush = Brush.horizontalGradient(listOf(Color.Transparent, Green.copy(alpha = 0.8f), Color.Transparent)),
                            size = Size(size.width, size.height),
                        )
                    },
            )
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp),
                    verticalAlignment = Alignment.Bottom,
                ) {
                    Image(painterResource(R.drawable.bike_pink), null, Modifier.height(104.dp))
                    Image(painterResource(R.drawable.bike_bmw), null, Modifier.height(112.dp))
                    Image(painterResource(R.drawable.car_gtr_small), null, Modifier.height(62.dp))
                }
            }
        }
        Text(s.profileDemo, color = c.subtext, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun InfoRow(value: String, label: String) {
    val c = LocalMahan.current
    Column(Modifier.fillMaxWidth()) {
        Text(value, color = c.text, fontSize = 16.sp)
        Text(label, color = c.subtext, fontSize = 12.sp)
    }
}

// ---------------------------------------------------------------- Proxy

private data class DemoProxy(val type: String, val host: String, val ping: String)

private val demoProxies = listOf(
    DemoProxy("MTProto", "203.0.113.10:443", "82 ms"),
    DemoProxy("SOCKS5", "203.0.113.25:1080", "140 ms"),
    DemoProxy("MTProto", "203.0.113.40:8443", "—"),
)

@Composable
fun ProxyScreen(s: Str, onBack: () -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    var use by remember { mutableStateOf(true) }
    var sel by remember { mutableIntStateOf(0) }
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BackButton(onBack)
            Text(s.proxy, color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    s.proxySub, color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                Image(painterResource(R.drawable.bike_bmw), null, Modifier.height(104.dp))
            }
        }
        GlassCard {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(s.proxyUse, color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Switch(
                    checked = use,
                    onCheckedChange = { use = it },
                    colors = SwitchDefaults.colors(checkedTrackColor = Green, checkedThumbColor = Color.White),
                )
            }
        }
        demoProxies.forEachIndexed { i, p ->
            val shape = RoundedCornerShape(20.dp)
            val selected = i == sel
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(c.glassTint.copy(alpha = 0.4f))
                    .border(if (selected) 1.5.dp else 1.dp, if (selected) Green else c.glassBorder, shape)
                    .clickable { sel = i }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    Modifier
                        .size(10.dp)
                        .background(if (selected && use) Green else Color(0xFF777777), CircleShape),
                )
                Column(Modifier.weight(1f)) {
                    Text(
                        if (selected && use) "${p.type} · ${s.proxyConnected}" else p.type,
                        color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                    )
                    Text(p.host, color = c.subtext, fontSize = 12.sp)
                }
                Text(p.ping, color = c.subtext, fontSize = 12.sp)
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(c.glassTint.copy(alpha = 0.35f))
                .clickable { Toast.makeText(ctx, s.afterConnect, Toast.LENGTH_SHORT).show() }
                .padding(16.dp),
            contentAlignment = Alignment.Center,
        ) { Text(s.proxyAdd, color = Green, fontSize = 16.sp) }
        Text(s.proxyDemo, color = c.subtext, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

// ---------------------------------------------------------------- Chat

data class DemoMsg(val text: String, val mine: Boolean, val time: String)

fun demoMessages(fa: Boolean, index: Int): List<DemoMsg> = when {
    index == 0 && fa -> listOf(
        DemoMsg("سلام، امروز وقت داری؟", false, "۲۱:۳۸"),
        DemoMsg("سلام! آره، چه خبر؟", true, "۲۱:۳۹"),
        DemoMsg("می‌خوام موتورت رو ببینم 😄", false, "۲۱:۴۰"),
    )
    index == 0 -> listOf(
        DemoMsg("Hi, are you free today?", false, "9:38 PM"),
        DemoMsg("Hi! Yes, what's up?", true, "9:39 PM"),
        DemoMsg("I want to see your bike 😄", false, "9:40 PM"),
    )
    index == 1 && fa -> listOf(
        DemoMsg("مهدی: فردا ساعت ۸ همدیگه رو ببینیم", false, "۲۰:۱۲"),
        DemoMsg("باشه، من هستم", true, "۲۰:۱۵"),
    )
    index == 1 -> listOf(
        DemoMsg("Mehdi: Let's meet tomorrow at 8", false, "8:12 PM"),
        DemoMsg("Okay, I'll be there", true, "8:15 PM"),
    )
    else -> emptyList()
}

@Composable
fun ChatScreen(s: Str, fa: Boolean, chat: DemoChat, index: Int, onBack: () -> Unit) {
    val c = LocalMahan.current
    val msgs = remember(fa, index) { androidx.compose.runtime.mutableStateListOf<DemoMsg>().apply { addAll(demoMessages(fa, index)) } }
    var draft by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    val scroll = rememberScrollState()
    LaunchedEffect(msgs.size) { scroll.animateScrollTo(scroll.maxValue) }
    Box(Modifier.fillMaxSize()) {
        // Faint vehicle watermark behind the conversation.
        Image(
            painter = painterResource(R.drawable.bike_bmw),
            contentDescription = null,
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(0.92f)
                .alpha(0.08f),
            colorFilter = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) }),
        )
        if (msgs.isEmpty()) {
            Column(
                Modifier.align(Alignment.Center).padding(horizontal = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                HeroStage(R.drawable.car_gtr_small, CAR_ASPECT, Green, height = 200.dp)
                Text(s.noMessages, color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(s.noMessagesSub, color = c.subtext, fontSize = 14.sp)
            }
        } else {
            // Outgoing messages sit on the right and incoming on the left in every language.
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(scroll)
                        .statusBarsPadding()
                        .padding(top = 74.dp, bottom = 96.dp, start = 12.dp, end = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    msgs.forEach { m ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
                            Column(
                                Modifier
                                    .widthIn(max = 290.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(if (m.mine) Green.copy(alpha = 0.42f) else c.glassTint.copy(alpha = 0.7f))
                                    .padding(start = 12.dp, end = 12.dp, top = 9.dp, bottom = 6.dp),
                            ) {
                                Text(m.text, color = c.text, fontSize = 15.sp)
                                Text(
                                    if (m.mine) m.time + " ✓✓" else m.time,
                                    color = c.subtext, fontSize = 11.sp,
                                    modifier = Modifier.align(Alignment.End),
                                )
                            }
                        }
                    }
                }
            }
        }
        // Header
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .background(c.glassTint.copy(alpha = 0.85f))
                .statusBarsPadding()
                .height(64.dp)
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            BackButton(onBack)
            Box(Modifier.size(42.dp).background(Green.copy(alpha = 0.8f), CircleShape), contentAlignment = Alignment.Center) {
                Text(chat.name.take(1), color = Color.White, fontWeight = FontWeight.Bold)
            }
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(chat.name, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    if (chat.verified) {
                        Spacer(Modifier.width(4.dp))
                        Icon(Icons.Rounded.Verified, null, tint = VerifiedBlue, modifier = Modifier.size(16.dp))
                    }
                }
                Text(s.online, color = Green, fontSize = 12.sp)
            }
        }
        // Input bar
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(12.dp)
                .height(52.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(c.glassTint.copy(alpha = 0.85f))
                .border(1.dp, c.glassBorder, RoundedCornerShape(26.dp))
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(
                Icons.Rounded.AttachFile, null, tint = c.subtext,
                modifier = Modifier.clip(CircleShape).clickable { Toast.makeText(ctx, s.afterConnect, Toast.LENGTH_SHORT).show() },
            )
            BasicTextField(
                value = draft,
                onValueChange = { draft = it },
                textStyle = TextStyle(color = c.text, fontSize = 15.sp),
                cursorBrush = SolidColor(Green),
                modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    Box {
                        if (draft.isEmpty()) Text(s.typeMessage, color = c.subtext, fontSize = 15.sp)
                        inner()
                    }
                },
            )
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Green)
                    .clickable {
                        if (draft.isNotBlank()) {
                            msgs.add(DemoMsg(draft.trim(), true, s.now))
                            draft = ""
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.AutoMirrored.Rounded.Send, null, tint = Color.Black, modifier = Modifier.size(20.dp))
            }
        }
    }
}
