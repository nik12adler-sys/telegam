@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mahan.mahantgram

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material.icons.rounded.EmojiEmotions
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.rememberLottieComposition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.drinkless.tdlib.TdApi
import java.io.File
import java.util.zip.GZIPInputStream

private val reactionSet = listOf("👍", "❤️", "😂", "🔥", "😮", "😢")

@Composable
fun LiveChatScreen(chatId: Long, onBack: () -> Unit, onInfo: () -> Unit, onUser: (Long) -> Unit = {}, onOpenChat: (Long) -> Unit = {}) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val chat = Td.chatById(chatId)
    if (chat == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    val msgs = remember(chatId) { mutableStateListOf<UiMessage>() }
    val paidStars by produceState(initialValue = 0, chatId) { value = Td.paidMessageStars(chatId) }
    // Real posting right from the member status: false in channels for non-admins, in restricted groups, etc.
    val canWrite by produceState(initialValue = chat.kind == ChatKind.PRIVATE, chatId, Td.postTick) {
        value = Td.canPost(chatId)
    }
    var end by remember(chatId) { mutableStateOf(false) }
    var loading by remember(chatId) { mutableStateOf(false) }
    var readOut by remember(chatId) { mutableLongStateOf(Td.readOutbox(chatId)) }
    var pinned by remember(chatId) { mutableStateOf<UiMessage?>(null) }
    var replyTo by remember(chatId) { mutableStateOf<UiMessage?>(null) }
    var editing by remember(chatId) { mutableStateOf<UiMessage?>(null) }
    var draft by remember(chatId) { mutableStateOf("") }
    var searching by remember(chatId) { mutableStateOf(false) }
    var query by remember(chatId) { mutableStateOf("") }
    var results by remember(chatId) { mutableStateOf<List<UiMessage>>(emptyList()) }
    var forwardOf by remember(chatId) { mutableStateOf<UiMessage?>(null) }
    var viewer by remember(chatId) { mutableStateOf<String?>(null) }
    var video by remember(chatId) { mutableStateOf<String?>(null) }
    var attachOpen by remember { mutableStateOf(false) }
    var panel by remember { mutableIntStateOf(0) } // 0 closed, otherwise MediaPanel is open
    var contactDlg by remember { mutableStateOf(false) }
    // Step 5: translations shown under messages, and the dialogs of the message actions.
    val translations = remember(chatId) { mutableStateMapOf<Long, String>() }
    val translating = remember(chatId) { mutableStateListOf<Long>() }
    var deleteFor by remember(chatId) { mutableStateOf<Pair<UiMessage, MsgCaps>?>(null) }
    var pinFor by remember(chatId) { mutableStateOf<UiMessage?>(null) }
    var reportFor by remember(chatId) { mutableStateOf<UiMessage?>(null) }
    var reactorsFor by remember(chatId) { mutableStateOf<Pair<UiMessage, String?>?>(null) }
    var forwardCaps by remember(chatId) { mutableStateOf<MsgCaps?>(null) }
    val focus = LocalFocusManager.current
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recFile by remember { mutableStateOf<File?>(null) }
    var recStart by remember { mutableLongStateOf(0L) }
    val listState = rememberLazyListState()

    fun loadMore() {
        if (loading || end) return
        loading = true
        scope.launch {
            val from = msgs.lastOrNull()?.id ?: 0L
            // TDLib often returns only the newest message at first; ask again until the page is full.
            val batch = Td.historyFull(chatId, from, 40) { part ->
                // Show what we already have immediately, the rest is added as soon as it arrives.
                val fresh = part.filter { b -> msgs.none { it.id == b.id } }
                msgs.addAll(fresh)
            }
            if (batch.isEmpty()) {
                end = true
            } else {
                val fresh = batch.filter { b -> msgs.none { it.id == b.id } }
                msgs.addAll(fresh)
                if (from == 0L) Td.markRead(chatId, batch.take(5).map { it.id })
            }
            loading = false
        }
    }

    fun refresh(id: Long) {
        scope.launch {
            runCatching { Td.message(chatId, id) }.getOrNull()?.let { u ->
                val i = msgs.indexOfFirst { it.id == id }
                if (i >= 0) msgs[i] = u
            }
        }
    }

    DisposableEffect(chatId) {
        Td.openChat(chatId)
        val listener: (TdApi.Object) -> Unit = { o ->
            when (o) {
                is TdApi.UpdateNewMessage -> if (o.message.chatId == chatId) {
                    val u = Td.toUi(o.message)
                    Td.main.post {
                        if (msgs.none { it.id == u.id }) msgs.add(0, u)
                        if (!u.outgoing) Td.markRead(chatId, listOf(u.id))
                    }
                }
                is TdApi.UpdateMessageSendSucceeded -> if (o.message.chatId == chatId) {
                    val u = Td.toUi(o.message)
                    val old = o.oldMessageId
                    Td.main.post {
                        val i = msgs.indexOfFirst { it.id == old }
                        if (i >= 0) msgs[i] = u else if (msgs.none { it.id == u.id }) msgs.add(0, u)
                    }
                }
                is TdApi.UpdateMessageSendFailed -> if (o.message.chatId == chatId) {
                    val u = Td.toUi(o.message)
                    val old = o.oldMessageId
                    Td.main.post {
                        val i = msgs.indexOfFirst { it.id == old || it.id == u.id }
                        if (i >= 0) msgs[i] = u else msgs.add(0, u)
                    }
                }
                is TdApi.UpdateMessageContent -> if (o.chatId == chatId) Td.main.post { refresh(o.messageId) }
                is TdApi.UpdateMessageInteractionInfo -> if (o.chatId == chatId) Td.main.post { refresh(o.messageId) }
                is TdApi.UpdateDeleteMessages -> if (o.chatId == chatId && o.isPermanent) {
                    val ids = o.messageIds.toSet()
                    Td.main.post { msgs.removeAll { it.id in ids } }
                }
                is TdApi.UpdateChatReadOutbox -> if (o.chatId == chatId) Td.main.post { readOut = o.lastReadOutboxMessageId }
                is TdApi.UpdateMessageIsPinned -> if (o.chatId == chatId) Td.main.post {
                    refresh(o.messageId)
                    scope.launch { pinned = Td.pinned(chatId) }
                }
                else -> {
                    // Reaction updates have a different name between TDLib versions, so they are matched by name.
                    if (o.javaClass.simpleName == "UpdateMessageReactions" && (o.fieldOrNull("chatId") as? Long) == chatId) {
                        val id = (o.fieldOrNull("messageId") as? Long) ?: 0L
                        if (id != 0L) Td.main.post { refresh(id) }
                    }
                }
            }
        }
        Td.listeners.add(listener)
        onDispose {
            Td.listeners.remove(listener)
            Td.closeChat(chatId)
            AudioPlayer.stop()
        }
    }
    LaunchedEffect(chatId) {
        loadMore()
        pinned = Td.pinned(chatId)
    }
    LaunchedEffect(listState) {
        snapshotFlow { (listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0) to msgs.size }
            .collect { (last, size) -> if (last >= size - 6) loadMore() }
    }

    fun translate(m: UiMessage) {
        if (translations.containsKey(m.id)) { translations.remove(m.id); return }
        if (m.id in translating || m.text.isBlank()) return
        translating.add(m.id)
        scope.launch {
            MsgOps.translate(m.text)
                .onSuccess { translations[m.id] = it }
                .onFailure { toast(ctx, tr("ترجمه‌ی این پیام ممکن نیست", "This message can't be translated")) }
            translating.remove(m.id)
        }
    }

    fun doPin(m: UiMessage, onlyForSelf: Boolean) {
        scope.launch {
            MsgOps.pin(chatId, m.id, onlyForSelf)?.let { toast(ctx, friendlyError(it)) }
            pinned = Td.pinned(chatId)
            refresh(m.id)
        }
    }

    fun sendNow() {
        val t = draft.trim()
        if (t.isEmpty() || !canWrite) return
        val e = editing
        val r = replyTo
        draft = ""; editing = null; replyTo = null
        scope.launch {
            val err = if (e != null) MsgOps.edit(e, t) else Td.sendLongText(chatId, t, r?.id ?: 0)
            if (err != null) toast(ctx, friendlyError(err))
        }
    }

    /** Sends every picked file in order; kind: 0 photo, 1 video, 2 file, 3 music. */
    fun sendFiles(uris: List<Uri>, kind: Int) {
        if (uris.isEmpty()) return
        var r = replyTo?.id ?: 0
        replyTo = null
        scope.launch {
            for (uri in uris) {
                val p = withContext(Dispatchers.IO) { copyUriToCache(ctx, uri) }
                if (p == null) { toast(ctx, tr("فایل خوانده نشد", "Could not read the file")); continue }
                if (File(p).length() > MAX_UPLOAD_BYTES) {
                    toast(ctx, friendlyError("file is too big"))
                    continue
                }
                val err = when (kind) {
                    0 -> Td.sendPhoto(chatId, p, r)
                    1 -> Td.sendVideo(chatId, p, r)
                    3 -> Td.sendAudio(chatId, p, r)
                    else -> Td.sendDocument(chatId, p, r)
                }
                r = 0
                if (err != null) toast(ctx, friendlyError(err))
            }
        }
    }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { sendFiles(it, 0) }
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { sendFiles(it, 1) }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { sendFiles(it, 2) }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { sendFiles(it, 3) }

    fun afterSend(err: String?) {
        if (err != null) toast(ctx, friendlyError(err))
    }
    val requestLocation = rememberLocationRequester { lat, lon, acc ->
        val r = replyTo?.id ?: 0
        replyTo = null
        scope.launch { afterSend(Td.sendLocation(chatId, lat, lon, acc, r)) }
    }
    val pickPhoneContact = rememberPhoneContactPicker { phone, first, last ->
        val r = replyTo?.id ?: 0
        replyTo = null
        scope.launch { afterSend(Td.sendContact(chatId, phone, first.ifEmpty { phone }, last, 0, r)) }
    }

    fun stopRecording(send: Boolean) {
        val r = recorder ?: return
        val f = recFile
        val secs = ((System.currentTimeMillis() - recStart) / 1000).toInt().coerceAtLeast(1)
        runCatching { r.stop() }
        runCatching { r.release() }
        recorder = null
        if (send && f != null && secs >= 1) {
            scope.launch {
                val err = Td.sendVoice(chatId, f.absolutePath, secs, replyTo?.id ?: 0)
                replyTo = null
                if (err != null) toast(ctx, friendlyError(err))
            }
        }
    }

    fun startRecording() {
        if (Build.VERSION.SDK_INT < 29) {
            toast(ctx, tr("ضبط صدا در این نسخه‌ی اندروید پشتیبانی نمی‌شود", "Voice recording needs Android 10+"))
            return
        }
        runCatching {
            val f = File(ctx.cacheDir, "v_${System.currentTimeMillis()}.ogg")
            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.OGG)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.OPUS)
            r.setAudioSamplingRate(48000)
            r.setAudioEncodingBitRate(32000)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recorder = r; recFile = f; recStart = System.currentTimeMillis()
        }.onFailure { toast(ctx, tr("ضبط صدا شروع نشد", "Could not start recording")) }
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecording() else toast(ctx, tr("اجازه‌ی میکروفون داده نشد", "Microphone permission denied"))
    }

    val shown = if (searching && query.isNotBlank()) results else msgs.toList()
    val bottomPad = (if (canWrite) 96.dp else 72.dp) + (if (canWrite && (replyTo != null || editing != null)) 52.dp else 0.dp) + (if (canWrite && panel != 0) 308.dp else 0.dp)
    val topPad = 76.dp + if (pinned != null) 40.dp else 0.dp

    Box(Modifier.fillMaxSize()) {
        Image(
            painter = androidx.compose.ui.res.painterResource(R.drawable.car_gtr_small),
            contentDescription = null,
            modifier = Modifier.align(Alignment.Center).fillMaxWidth(0.92f).alpha(0.08f),
            colorFilter = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) }),
        )
        if (msgs.isEmpty() && !loading && end) {
            Column(
                Modifier.align(Alignment.Center).padding(horizontal = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                HeroStage(R.drawable.car_gtr_small, CAR_ASPECT, Green, height = 200.dp)
                Text(tr("هنوز پیامی نیست", "No messages yet"), color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(tr("اولین پیام را بفرست.", "Send the first message."), color = c.subtext, fontSize = 14.sp)
            }
        }
        LazyColumn(
            state = listState,
            reverseLayout = true,
            modifier = Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(top = topPad, bottom = bottomPad, start = 10.dp, end = 10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(shown, key = { it.id }) { m ->
                Bubble(
                    m = m,
                    group = chat.kind != ChatKind.PRIVATE,
                    read = m.outgoing && m.id <= readOut,
                    translated = translations[m.id],
                    translating = m.id in translating,
                    onReply = { replyTo = m; editing = null },
                    onEdit = { editing = m; replyTo = null; draft = m.text },
                    onDelete = { caps -> deleteFor = m to caps },
                    onForward = { caps -> forwardCaps = caps; forwardOf = m },
                    onPin = {
                        if (m.pinned) {
                            scope.launch {
                                MsgOps.unpin(chatId, m.id)?.let { toast(ctx, friendlyError(it)) }
                                pinned = Td.pinned(chatId)
                                refresh(m.id)
                            }
                        } else if (MsgOps.isPrivate(chatId) && chat.userId != Td.meId) {
                            // Private chats: Telegram lets the user choose between pinning for both or only for themselves.
                            pinFor = m
                        } else {
                            doPin(m, false)
                        }
                    },
                    onTranslate = { translate(m) },
                    onReport = { reportFor = m },
                    onReactors = { e -> reactorsFor = m to e },
                    onReact = { e, chosen ->
                        scope.launch {
                            Td.react(chatId, m.id, e, chosen)?.let { toast(ctx, friendlyError(it)) }
                            refresh(m.id)
                        }
                    },
                    onPhoto = { viewer = it },
                    onVideo = { video = it },
                    onSender = { if (it != 0L) onUser(it) },
                    onLink = { t -> TgLinks.open(ctx, scope, t, onOpenChat, onUser) },
                    onRetry = { scope.launch { Td.resend(chatId, m.id)?.let { e -> toast(ctx, friendlyError(e)) } } },
                    onCancel = {
                        if (m.failed || m.sending) scope.launch { Td.delete(chatId, m.id, true)?.let { e -> toast(ctx, friendlyError(e)) } }
                        else Td.cancelDownload(m.fileId)
                    },
                )
            }
        }

        // Header
        Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().background(c.glassTint.copy(alpha = 0.88f)).statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BackButton(onBack)
                if (searching) {
                    BasicTextField(
                        value = query,
                        onValueChange = {
                            query = it
                            if (it.isNotBlank()) scope.launch { results = runCatching { Td.search(chatId, it) }.getOrDefault(emptyList()) }
                        },
                        singleLine = true,
                        textStyle = TextStyle(color = c.text, fontSize = 17.sp),
                        cursorBrush = SolidColor(Green),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner ->
                            Box {
                                if (query.isEmpty()) Text(tr("جستجو در پیام‌ها", "Search messages"), color = c.subtext, fontSize = 17.sp)
                                inner()
                            }
                        },
                    )
                    Icon(Icons.Rounded.Close, null, tint = c.text, modifier = Modifier.clip(CircleShape).clickable { searching = false; query = ""; results = emptyList() }.padding(6.dp))
                } else {
                    Row(Modifier.weight(1f).clickable(onClick = onInfo), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Avatar(chat.photoFileId, chat.title, 42.dp)
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(if (chat.saved) tr("پیام‌های ذخیره‌شده", "Saved Messages") else chat.title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                                if (chat.verified) {
                                    Spacer(Modifier.width(4.dp))
                                    Icon(Icons.Rounded.Verified, null, tint = VerifiedBlue, modifier = Modifier.size(16.dp))
                                }
                            }
                            val sub = when (chat.kind) {
                                ChatKind.PRIVATE -> Td.userInfo(chat.userId)?.status ?: ""
                                ChatKind.GROUP -> tr("گروه", "Group")
                                ChatKind.CHANNEL -> tr("کانال", "Channel")
                                else -> ""
                            }
                            Text(sub.ifEmpty { connectionText() } + if (paidStars > 0) " · $paidStars Tony" else "", color = Green, fontSize = 12.sp, maxLines = 1)
                        }
                    }
                    Icon(Icons.Rounded.Search, null, tint = c.text, modifier = Modifier.clip(CircleShape).clickable { searching = true }.padding(6.dp))
                    Icon(Icons.Rounded.Info, null, tint = c.text, modifier = Modifier.clip(CircleShape).clickable(onClick = onInfo).padding(6.dp))
                }
            }
            pinned?.let { p ->
                Row(Modifier.fillMaxWidth().height(40.dp).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("📌 ", fontSize = 14.sp)
                    Text(Td.previewTextOf(p), color = c.subtext, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }

        // Read-only footer: no message box for people who may not post here.
        if (!canWrite) {
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(12.dp)
                    .height(52.dp).clip(RoundedCornerShape(26.dp)).background(c.glassTint.copy(alpha = 0.88f))
                    .border(1.dp, c.glassBorder, RoundedCornerShape(26.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (chat.kind == ChatKind.CHANNEL) tr("فقط مدیران کانال می‌توانند پست بگذارند", "Only channel admins can post")
                    else tr("شما اجازه‌ی ارسال پیام در این گفتگو را ندارید", "You can't send messages in this chat"),
                    color = c.subtext, fontSize = 14.sp, textAlign = TextAlign.Center,
                )
            }
        }

        // Input bar
        if (canWrite) Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().imePadding().padding(12.dp)) {
            if (paidStars > 0) {
                Text(
                    trf("هر پیام {0} Tony هزینه دارد", "Each message costs {0} Tony", paidStars),
                    color = c.subtext, fontSize = 12.sp,
                    modifier = Modifier.padding(start = 14.dp, bottom = 4.dp),
                )
            }
            (replyTo ?: editing)?.let { m ->
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 6.dp).clip(RoundedCornerShape(14.dp)).background(c.glassTint.copy(alpha = 0.88f)).padding(horizontal = 12.dp).height(46.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(if (editing != null) "✏️ " else "↩ ", fontSize = 14.sp)
                    Text(Td.previewTextOf(m), color = c.subtext, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Icon(Icons.Rounded.Close, null, tint = c.subtext, modifier = Modifier.clip(CircleShape).clickable { replyTo = null; editing = null; draft = "" }.padding(4.dp))
                }
            }
            Row(
                Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp)).background(c.glassTint.copy(alpha = 0.88f)).border(1.dp, c.glassBorder, RoundedCornerShape(26.dp)).padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (recorder != null) {
                    Text("🔴 " + tr("در حال ضبط…", "Recording…"), color = c.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    Icon(Icons.Rounded.Close, null, tint = c.subtext, modifier = Modifier.clip(CircleShape).clickable { stopRecording(false) }.padding(4.dp))
                } else {
                    Box {
                        Icon(Icons.Rounded.AttachFile, null, tint = c.subtext, modifier = Modifier.clip(CircleShape).clickable { attachOpen = true }.padding(2.dp))
                        DropdownMenu(expanded = attachOpen, onDismissRequest = { attachOpen = false }) {
                            DropdownMenuItem(text = { Text(tr("عکس", "Photo")) }, onClick = { attachOpen = false; pickPhoto.launch("image/*") })
                            DropdownMenuItem(text = { Text(tr("ویدیو", "Video")) }, onClick = { attachOpen = false; pickVideo.launch("video/*") })
                            DropdownMenuItem(text = { Text(tr("فایل و سند", "File / document")) }, onClick = { attachOpen = false; pickFile.launch("*/*") })
                            DropdownMenuItem(text = { Text(tr("موسیقی", "Music")) }, onClick = { attachOpen = false; pickAudio.launch("audio/*") })
                            DropdownMenuItem(text = { Text(tr("موقعیت مکانی", "Location")) }, onClick = { attachOpen = false; requestLocation() })
                            DropdownMenuItem(text = { Text(tr("مخاطب", "Contact")) }, onClick = { attachOpen = false; contactDlg = true })
                        }
                    }
                    Icon(
                        Icons.Rounded.EmojiEmotions, null, tint = if (panel != 0) Green else c.subtext,
                        modifier = Modifier.clip(CircleShape).clickable { focus.clearFocus(); panel = if (panel == 0) 1 else 0 }.padding(2.dp),
                    )
                    BasicTextField(
                        value = draft,
                        onValueChange = { draft = it },
                        textStyle = TextStyle(color = c.text, fontSize = 15.sp),
                        cursorBrush = SolidColor(Green),
                        maxLines = 4,
                        modifier = Modifier.weight(1f).onFocusChanged { if (it.isFocused) panel = 0 },
                        decorationBox = { inner ->
                            Box {
                                if (draft.isEmpty()) Text(tr("پیام", "Message"), color = c.subtext, fontSize = 15.sp)
                                inner()
                            }
                        },
                    )
                }
                Box(
                    Modifier.size(36.dp).clip(CircleShape).background(Green).clickable {
                        when {
                            recorder != null -> stopRecording(true)
                            draft.isNotBlank() -> sendNow()
                            else -> {
                                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecording()
                                else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (draft.isBlank() && recorder == null) Icons.Rounded.Mic else Icons.AutoMirrored.Rounded.Send,
                        null, tint = Color.Black, modifier = Modifier.size(20.dp),
                    )
                }
            }
            if (panel != 0) {
                Spacer(Modifier.height(8.dp))
                MediaPanel(
                    chatId,
                    onEmoji = { draft += it },
                    onSticker = { s ->
                        val r = replyTo?.id ?: 0
                        replyTo = null
                        scope.launch { afterSend(Td.sendSticker(chatId, s, r)) }
                    },
                    onGif = { g ->
                        val r = replyTo?.id ?: 0
                        replyTo = null
                        scope.launch { afterSend(Td.sendGif(chatId, g, r)) }
                    },
                )
            }
        }
        // Offline: TDLib keeps queued messages and sends them when the connection returns.
        if (connectionText().isNotEmpty()) {
            Text(
                connectionText() + " · " + tr("پیام‌ها پس از اتصال ارسال می‌شوند", "messages are sent once you're back online"),
                color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(top = topPad - 6.dp)
                    .background(Color(0xCC000000)).padding(vertical = 4.dp, horizontal = 8.dp),
            )
        }
    }

    if (contactDlg) {
        ContactSendDialog(
            onDismiss = { contactDlg = false },
            onPhone = { pickPhoneContact() },
            onTelegram = { u ->
                val r = replyTo?.id ?: 0
                replyTo = null
                scope.launch { afterSend(Td.sendContact(chatId, u.phone, u.name.substringBefore(' '), u.name.substringAfter(' ', ""), u.id, r)) }
            },
        )
    }

    forwardOf?.let { m ->
        ForwardDialog(m, canCopy = forwardCaps?.canCopy ?: true) { forwardOf = null }
    }
    deleteFor?.let { (m, caps) ->
        DeleteDialog(m, caps, chat.title, onDismiss = { deleteFor = null }) { revoke ->
            deleteFor = null
            scope.launch { Td.delete(chatId, m.id, revoke)?.let { toast(ctx, friendlyError(it)) } }
        }
    }
    pinFor?.let { m ->
        PinDialog(chat.title, onDismiss = { pinFor = null }) { onlyMe -> pinFor = null; doPin(m, onlyMe) }
    }
    reportFor?.let { m -> ReportDialog(m) { reportFor = null } }
    reactorsFor?.let { (m, e) -> ReactorsDialog(m, e) { reactorsFor = null } }
    viewer?.let { PhotoDialog(it) { viewer = null } }
    video?.let { VideoDialog(it) { video = null } }
}

@Composable
private fun Bubble(
    m: UiMessage,
    group: Boolean,
    read: Boolean,
    onReply: () -> Unit,
    onEdit: () -> Unit,
    onDelete: (MsgCaps) -> Unit,
    onForward: (MsgCaps) -> Unit,
    onPin: () -> Unit,
    onReact: (String, Boolean) -> Unit,
    translated: String? = null,
    translating: Boolean = false,
    onTranslate: () -> Unit = {},
    onReport: () -> Unit = {},
    onReactors: (String?) -> Unit = {},
    onPhoto: (String) -> Unit,
    onVideo: (String) -> Unit,
    onSender: (Long) -> Unit = {},
    onRetry: () -> Unit = {},
    onCancel: () -> Unit = {},
    onLink: (String) -> Unit = {},
) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    var linkMenu by remember { mutableStateOf<LinkSpan?>(null) }
    // What this user may really do with the message; loaded from TDLib each time the menu opens.
    var caps by remember(m.id) { mutableStateOf<MsgCaps?>(null) }
    var avail by remember(m.id) { mutableStateOf<List<String>?>(null) }
    var moreReactions by remember(m.id) { mutableStateOf(false) }
    var replyPreview by remember(m.id, m.replyText) { mutableStateOf(m.replyText) }
    LaunchedEffect(menu) {
        if (menu) {
            caps = MsgOps.caps(m)
            avail = MsgOps.availableReactions(m)
        } else {
            moreReactions = false
        }
    }
    LaunchedEffect(m.replyToId) {
        if (m.replyToId != 0L && replyPreview.isEmpty()) {
            runCatching { Td.message(m.chatId, m.replyToId) }.getOrNull()?.let { replyPreview = Td.previewTextOf(it) }
        }
    }
    val sticker = m.kind == MsgKind.STICKER
    val shape = RoundedCornerShape(18.dp)
    val rtl = androidx.compose.ui.platform.LocalLayoutDirection.current == androidx.compose.ui.unit.LayoutDirection.Rtl
    // Outgoing messages stay on the right and incoming on the left in both languages.
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.outgoing != rtl) Arrangement.End else Arrangement.Start) {
        Box {
            Column(
                Modifier
                    .widthIn(max = 290.dp)
                    .clip(shape)
                    .then(if (sticker) Modifier else Modifier.background(if (m.outgoing) Green.copy(alpha = 0.42f) else c.glassTint.copy(alpha = 0.72f)))
                    .combinedClickable(onClick = {}, onLongClick = { menu = true })
                    .padding(if (sticker) 0.dp else 8.dp),
            ) {
                if (group && !m.outgoing && m.sender.isNotEmpty() && !sticker) {
                    Text(
                        m.sender, color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable(enabled = m.senderUserId != 0L) { onSender(m.senderUserId) },
                    )
                }
                if (m.replyToId != 0L) {
                    Text(
                        "↩ " + replyPreview.ifEmpty { tr("پاسخ", "Reply") },
                        color = c.subtext, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(bottom = 4.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x22000000)).padding(horizontal = 6.dp, vertical = 2.dp),
                    )
                }
                when (m.kind) {
                    MsgKind.PHOTO -> PhotoTile(m, onPhoto)
                    MsgKind.VIDEO, MsgKind.ANIMATION, MsgKind.VIDEO_NOTE -> VideoTile(m, onVideo)
                    MsgKind.STICKER -> StickerView(m)
                    MsgKind.VOICE, MsgKind.AUDIO -> AudioRow(m)
                    MsgKind.DOC -> DocRow(m)
                    else -> {}
                }
                if (m.text.isNotEmpty()) LinkedText(
                    m.text, m.entities, c.text, 15.sp,
                    modifier = Modifier.padding(top = if (m.kind == MsgKind.TEXT) 0.dp else 4.dp),
                    onLink = onLink, onLongPress = { sp -> if (sp != null) linkMenu = sp else menu = true },
                )
                if (translating) Text(tr("در حال ترجمه…", "Translating…"), color = c.subtext, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                if (translated != null) {
                    Text(
                        "🌐 " + translated, color = c.text, fontSize = 15.sp,
                        modifier = Modifier.padding(top = 4.dp).fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0x22000000)).padding(6.dp),
                    )
                }
                val transfer = if (m.fileId != 0) Transfers.progress[m.fileId] else null
                if (m.failed || transfer != null) TransferBar(m, transfer, onCancel, onRetry)
                if (m.reactions.isNotEmpty()) {
                    Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        m.reactions.forEach { r ->
                            Text(
                                "${r.emoji} ${r.count}", fontSize = 12.sp, color = c.text,
                                modifier = Modifier.clip(CircleShape)
                                    .background(if (r.chosen) Green.copy(alpha = 0.5f) else Color(0x22000000))
                                    .combinedClickable(onClick = { onReact(r.emoji, r.chosen) }, onLongClick = { onReactors(r.emoji) })
                                    .padding(horizontal = 8.dp, vertical = 2.dp),
                            )
                        }
                    }
                }
                if (!sticker) {
                    val meta = Td.fmtTime(m.date) + (if (m.edited) " ✎" else "") +
                        (if (m.outgoing) (if (m.failed) " ⚠" else if (m.sending) " ⏳" else if (read) " ✓✓" else " ✓") else "")
                    Text(meta, color = c.subtext, fontSize = 11.sp, modifier = Modifier.align(Alignment.End))
                }
            }
            DropdownMenu(expanded = linkMenu != null, onDismissRequest = { linkMenu = null }) {
                val sp = linkMenu
                if (sp != null) {
                    DropdownMenuItem(text = { Text(tr("باز کردن لینک", "Open link")) }, onClick = { linkMenu = null; onLink(sp.target) })
                    DropdownMenuItem(text = { Text(tr("کپی لینک", "Copy link")) }, onClick = {
                        linkMenu = null
                        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("link", sp.copyText))
                        toast(ctx, tr("کپی شد", "Copied"))
                    })
                    DropdownMenuItem(text = { Text(tr("گزینه‌های پیام", "Message options")) }, onClick = { linkMenu = null; menu = true })
                }
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                val cp = caps ?: MsgOps.guess(m)
                // Only the reactions this chat allows; while TDLib has not answered the default set is shown.
                val choices = avail ?: reactionSet
                if (choices.isNotEmpty() && m.id > 0 && !m.sending && !m.failed) {
                    val shownFirst = choices.take(6)
                    Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        shownFirst.forEach { e ->
                            val chosen = m.reactions.any { it.emoji == e && it.chosen }
                            Text(
                                e, fontSize = 22.sp,
                                modifier = Modifier.clip(CircleShape).background(if (chosen) Green.copy(alpha = 0.35f) else Color.Transparent)
                                    .clickable { menu = false; onReact(e, chosen) }.padding(4.dp),
                            )
                        }
                        if (choices.size > 6) Text(
                            if (moreReactions) "⌃" else "⌄", fontSize = 20.sp, color = c.subtext,
                            modifier = Modifier.clip(CircleShape).clickable { moreReactions = !moreReactions }.padding(6.dp),
                        )
                    }
                    if (moreReactions) {
                        choices.drop(6).chunked(6).forEach { row ->
                            Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                row.forEach { e ->
                                    val chosen = m.reactions.any { it.emoji == e && it.chosen }
                                    Text(
                                        e, fontSize = 22.sp,
                                        modifier = Modifier.clip(CircleShape).background(if (chosen) Green.copy(alpha = 0.35f) else Color.Transparent)
                                            .clickable { menu = false; onReact(e, chosen) }.padding(4.dp),
                                    )
                                }
                            }
                        }
                    }
                }
                if (cp.canReply) DropdownMenuItem(text = { Text(tr("پاسخ", "Reply")) }, onClick = { menu = false; onReply() })
                if (cp.canCopy) DropdownMenuItem(text = { Text(tr("کپی", "Copy")) }, onClick = {
                    menu = false
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("msg", m.text))
                    toast(ctx, tr("کپی شد", "Copied"))
                })
                if (m.text.isNotEmpty() && m.kind != MsgKind.STICKER) DropdownMenuItem(
                    text = { Text(if (translated != null) tr("نمایش متن اصلی", "Show original") else tr("ترجمه", "Translate")) },
                    onClick = { menu = false; onTranslate() },
                )
                if (cp.canEdit) DropdownMenuItem(text = { Text(tr("ویرایش", "Edit")) }, onClick = { menu = false; onEdit() })
                if (cp.canForward) DropdownMenuItem(text = { Text(tr("ارسال به…", "Forward")) }, onClick = { menu = false; onForward(cp) })
                if (cp.canPin) DropdownMenuItem(
                    text = { Text(if (m.pinned) tr("برداشتن سنجاق", "Unpin") else tr("سنجاق", "Pin")) },
                    onClick = { menu = false; onPin() },
                )
                if (m.reactions.isNotEmpty() && cp.canSeeReactors) DropdownMenuItem(
                    text = { Text(tr("فهرست واکنش‌ها", "Who reacted")) }, onClick = { menu = false; onReactors(null) },
                )
                if (cp.canReport) DropdownMenuItem(text = { Text(tr("گزارش", "Report")) }, onClick = { menu = false; onReport() })
                if (cp.canDeleteSelf || cp.canDeleteAll) DropdownMenuItem(
                    text = { Text(tr("حذف", "Delete"), color = Color(0xFFFF6B6B)) }, onClick = { menu = false; onDelete(cp) },
                )
            }
        }
    }
}

@Composable
private fun PhotoTile(m: UiMessage, onOpen: (String) -> Unit) {
    val path = Td.files[m.fileId]
    val bmp = rememberBitmap(path, 900)
    val ratio = if (m.width > 0 && m.height > 0) (m.width.toFloat() / m.height).coerceIn(0.5f, 2f) else 1f
    Box(
        Modifier.width(240.dp).aspectRatio(ratio).clip(RoundedCornerShape(12.dp)).background(Color(0x22000000))
            .clickable { path?.let(onOpen) },
        contentAlignment = Alignment.Center,
    ) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else CircularProgressIndicator(Modifier.size(28.dp), color = Green, strokeWidth = 2.dp)
    }
}

@Composable
private fun VideoTile(m: UiMessage, onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val thumb = rememberBitmap(Td.files[m.thumbFileId], 600)
    val path = Td.files[m.fileId]
    var waiting by remember { mutableStateOf(false) }
    LaunchedEffect(path) { if (waiting && path != null) { waiting = false; onOpen(path) } }
    val ratio = if (m.kind == MsgKind.VIDEO_NOTE) 1f else if (m.width > 0 && m.height > 0) (m.width.toFloat() / m.height).coerceIn(0.5f, 2f) else 1.6f
    Box(
        Modifier.width(if (m.kind == MsgKind.VIDEO_NOTE) 180.dp else 240.dp).aspectRatio(ratio)
            .clip(if (m.kind == MsgKind.VIDEO_NOTE) CircleShape else RoundedCornerShape(12.dp))
            .background(Color(0x44000000))
            .clickable {
                if (path != null) onOpen(path) else { waiting = true; Td.download(m.fileId); toast(ctx, tr("در حال دانلود…", "Downloading…")) }
            },
        contentAlignment = Alignment.Center,
    ) {
        // GIFs (Telegram stores them as muted looping videos) play by themselves once they are downloaded.
        val autoplay = m.kind == MsgKind.ANIMATION && path != null
        if (autoplay) LoopingVideo(path!!, Modifier.fillMaxSize())
        else if (thumb != null) Image(thumb, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        if (waiting) CircularProgressIndicator(Modifier.size(36.dp), color = Green, strokeWidth = 3.dp)
        else if (!autoplay) Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(44.dp).background(Color(0x66000000), CircleShape))
        if (m.duration > 0) Text("%d:%02d".format(m.duration / 60, m.duration % 60), color = Color.White, fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomStart).padding(6.dp))
    }
}

/** Muted, looping, borderless video for GIFs. The player is released as soon as the bubble leaves the screen. */
@Composable
private fun LoopingVideo(path: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val player = remember(path) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(File(path))))
            repeatMode = Player.REPEAT_MODE_ONE
            volume = 0f
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { c ->
            (android.view.LayoutInflater.from(c).inflate(R.layout.looping_player_zoom, null) as PlayerView).also { it.player = player }
        },
        update = { it.player = player },
        modifier = modifier,
    )
}

@Composable
private fun StickerView(m: UiMessage) {
    val path = Td.files[m.fileId]
    when {
        path == null -> Box(Modifier.size(140.dp), contentAlignment = Alignment.Center) { Text(m.emoji, fontSize = 48.sp) }
        m.stickerFormat == 1 -> TgsSticker(path)
        m.stickerFormat == 0 -> {
            val bmp = rememberBitmap(path, 512)
            if (bmp != null) Image(bmp, null, Modifier.size(150.dp), contentScale = ContentScale.Fit)
            else Box(Modifier.size(150.dp))
        }
        else -> {
            val bmp = rememberBitmap(Td.files[m.thumbFileId], 300)
            if (bmp != null) Image(bmp, null, Modifier.size(150.dp), contentScale = ContentScale.Fit)
            else Box(Modifier.size(140.dp), contentAlignment = Alignment.Center) { Text(m.emoji, fontSize = 48.sp) }
        }
    }
}

@Composable
private fun TgsSticker(path: String) {
    val json by produceState<String?>(null, path) {
        value = withContext(Dispatchers.IO) {
            runCatching { GZIPInputStream(File(path).inputStream()).bufferedReader().use { it.readText() } }.getOrNull()
        }
    }
    val j = json
    if (j == null) {
        Box(Modifier.size(150.dp))
        return
    }
    val comp by rememberLottieComposition(LottieCompositionSpec.JsonString(j))
    LottieAnimation(composition = comp, iterations = LottieConstants.IterateForever, modifier = Modifier.size(150.dp))
}

@Composable
private fun AudioRow(m: UiMessage) {
    val c = LocalMahan.current
    val path = Td.files[m.fileId]
    val playing = path != null && AudioPlayer.current == path
    Row(
        Modifier.width(220.dp).clickable { if (path != null) AudioPlayer.toggle(path) else Td.download(m.fileId) },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(Modifier.size(40.dp).background(Green, CircleShape), contentAlignment = Alignment.Center) {
            Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.Black)
        }
        Column {
            Text(if (m.kind == MsgKind.AUDIO && m.fileName.isNotEmpty()) m.fileName else tr("پیام صوتی", "Voice message"), color = c.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("%d:%02d".format(m.duration / 60, m.duration % 60), color = c.subtext, fontSize = 12.sp)
        }
    }
}

@Composable
private fun DocRow(m: UiMessage) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val path = Td.files[m.fileId]
    var waiting by remember { mutableStateOf(false) }
    LaunchedEffect(path) { if (waiting && path != null) { waiting = false; openFile(ctx, path) } }
    Row(
        Modifier.width(230.dp).clickable {
            if (path != null) openFile(ctx, path) else { waiting = true; Td.download(m.fileId); toast(ctx, tr("در حال دانلود…", "Downloading…")) }
        },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(Modifier.size(40.dp).background(Green, CircleShape), contentAlignment = Alignment.Center) {
            if (waiting) CircularProgressIndicator(Modifier.size(22.dp), color = Color.Black, strokeWidth = 2.dp)
            else Icon(Icons.Rounded.Description, null, tint = Color.Black)
        }
        Column {
            Text(m.fileName, color = c.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("%.1f MB".format(m.fileSize / 1048576.0), color = c.subtext, fontSize = 12.sp)
        }
    }
}

@Composable
fun PhotoDialog(path: String, onClose: () -> Unit) {
    val bmp = rememberBitmap(path, 2048)
    var scale by remember { mutableStateOf(1f) }
    var ox by remember { mutableStateOf(0f) }
    var oy by remember { mutableStateOf(0f) }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
            if (bmp != null) {
                Image(
                    bmp, null,
                    Modifier.fillMaxSize()
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 5f)
                                ox += pan.x; oy += pan.y
                            }
                        }
                        .graphicsLayer { scaleX = scale; scaleY = scale; translationX = ox; translationY = oy },
                    contentScale = ContentScale.Fit,
                )
            }
        }
    }
}

@Composable
fun VideoDialog(path: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(File(path))))
            repeatMode = Player.REPEAT_MODE_OFF
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(factory = { PlayerView(it).apply { this.player = player } }, modifier = Modifier.fillMaxSize())
        }
    }
}
