package com.mahan.mahantgram

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class TdException(val code: Int, message: String) : Exception(message)

enum class ChatKind { PRIVATE, GROUP, CHANNEL, OTHER }
enum class MsgKind { TEXT, PHOTO, VIDEO, ANIMATION, VIDEO_NOTE, DOC, VOICE, AUDIO, STICKER, OTHER }

data class UiChat(
    val id: Long, val title: String, val last: String, val time: String, val unread: Int,
    val muted: Boolean, val pinned: Boolean, val photoFileId: Int, val kind: ChatKind,
    val verified: Boolean, val saved: Boolean, val userId: Long, val order: Long,
    val lastOutgoing: Boolean = false, val lastRead: Boolean = false, val bot: Boolean = false,
    val storyState: Int = 0, // 0 = none, 1 = all seen, 2 = has unseen stories
    val secret: Boolean = false, // end-to-end secret chat (real TDLib chat type)
)

/** One entry of the stories bar. mine = the user's own story slot. */
data class UiStoryChat(
    val chatId: Long, val title: String, val photoFileId: Int, val unseen: Boolean,
    val order: Long, val mine: Boolean,
)

data class UiUser(
    val id: Long, val name: String, val username: String, val phone: String,
    val status: String, val photoFileId: Int, val verified: Boolean,
)

data class UiReaction(val emoji: String, val count: Int, val chosen: Boolean)

/** A link-like piece of a message text. type: 1 = url, 2 = @username, 3 = hidden link (url set), 4 = mention of a user (userId set). */
data class UiEntity(val offset: Int, val length: Int, val type: Int, val url: String = "", val userId: Long = 0L)

data class UiMessage(
    val id: Long, val chatId: Long, val outgoing: Boolean, val date: Int, val sender: String,
    val kind: MsgKind, val text: String, val fileId: Int, val thumbFileId: Int,
    val width: Int, val height: Int, val duration: Int, val fileName: String, val fileSize: Long,
    val stickerFormat: Int, val replyToId: Long, val replyText: String, val edited: Boolean,
    val pinned: Boolean, val sending: Boolean, val failed: Boolean,
    val reactions: List<UiReaction>, val emoji: String,
    val senderUserId: Long = 0L,
    val sendError: String = "",
    val canRetry: Boolean = false,
    val entities: List<UiEntity> = emptyList(),
)

/** Language switch for live screens. */
/** Languages of the app: fa (right-to-left), en, ru, de, fr. */
val APP_LANGS = listOf("fa" to "فارسی", "en" to "English", "ru" to "Русский", "de" to "Deutsch", "fr" to "Français")

/**
 * Text for the current language. fa and en are written at the call site; ru, de and fr are looked up
 * by the English text in Translations (and fall back to English when a text has no translation yet).
 */
fun tr(fa: String, en: String): String = when (Td.lang) {
    "fa" -> fa
    "en" -> en
    else -> Translations.get(Td.lang, en) ?: en
}

/** Like tr, for texts with values: write {0}, {1}… in the texts and pass the values. */
fun trf(fa: String, en: String, vararg values: Any?): String {
    var t = tr(fa, en)
    values.forEachIndexed { i, v -> t = t.replace("{$i}", v.toString()) }
    return t
}

/** Reads a public field by name (null when it does not exist in this TDLib version). */
fun Any.fieldOrNull(name: String): Any? = runCatching { javaClass.getField(name).get(this) }.getOrNull()

/**
 * Builds a TDLib object by class name and field names. Missing arrays and strings get empty
 * defaults. Doing it this way keeps the build safe if a field is renamed between TDLib versions.
 */
@Suppress("UNCHECKED_CAST")
fun <T : TdApi.Object> mk(name: String, vararg fields: Pair<String, Any?>): T {
    val c = Class.forName("org.drinkless.tdlib.TdApi\$$name")
    val o = c.getDeclaredConstructor().newInstance()
    for (f in c.fields) {
        if (java.lang.reflect.Modifier.isStatic(f.modifiers) || f.get(o) != null) continue
        when {
            f.type.isArray -> f.set(o, java.lang.reflect.Array.newInstance(f.type.componentType, 0))
            f.type == String::class.java -> f.set(o, "")
        }
    }
    for ((k, v) in fields) c.getField(k).set(o, v)
    return o as T
}

fun ft(text: String): TdApi.FormattedText =
    TdApi.FormattedText(text, emptyArray<TdApi.TextEntity>())

object Td {
    val enabled: Boolean = BuildConfig.TG_API_ID != 0
    var fa by mutableStateOf(true)
    var lang by mutableStateOf("fa")

    private var client: Client? = null
    private lateinit var appCtx: Context
    val main = Handler(Looper.getMainLooper())
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    var authState by mutableStateOf<TdApi.AuthorizationState?>(null)
    var connection by mutableStateOf("")
    var me by mutableStateOf<UiUser?>(null)
    var meId = 0L
    /** Every chat TDLib knows (main list). Only AjiMaji reads this directly. */
    var allChats by mutableStateOf<List<UiChat>>(emptyList())
        private set
    /** The public chat list: chats hidden in AjiMaji are never part of it, locked or not. */
    val chats: List<UiChat>
        get() {
            val h = Vault.hiddenIds
            return if (h.isEmpty()) allChats else allChats.filter { it.id !in h }
        }
    /** User ids of private chats that are hidden (so the contacts tab cannot open them). */
    val hiddenUserIds: Set<Long>
        get() {
            val h = Vault.hiddenIds
            if (h.isEmpty()) return emptySet()
            return allChats.filter { it.id in h && it.userId != 0L }.map { it.userId }.toSet()
        }
    var contacts by mutableStateOf<List<UiUser>>(emptyList())
    var stories by mutableStateOf<List<UiStoryChat>>(emptyList())
    val files = mutableStateMapOf<Int, String>()

    private val chatMap = ConcurrentHashMap<Long, TdApi.Chat>()
    private val userMap = ConcurrentHashMap<Long, TdApi.User>()
    /** chatId -> (order, hasUnseen) for chats that currently have active stories. */
    private val storyMap = ConcurrentHashMap<Long, Pair<Long, Boolean>>()
    private val requested = ConcurrentHashMap.newKeySet<Int>()
    val listeners = CopyOnWriteArrayList<(TdApi.Object) -> Unit>()
    private var dirty = false

    fun start(context: Context) {
        if (!enabled || client != null) return
        appCtx = context.applicationContext
        TdBridge.execute(mk<TdApi.Object>("SetLogVerbosityLevel", "newVerbosityLevel" to 1))
        client = TdBridge.create { onUpdate(it) }
    }

    // ------------------------------------------------------------ requests

    suspend fun req(f: TdApi.Object): TdApi.Object = suspendCancellableCoroutine { c ->
        val cl = client
        if (cl == null) {
            c.resumeWithException(TdException(500, "no client"))
        } else {
            TdBridge.send(cl, f) { r ->
                if (r is TdApi.Error) c.resumeWithException(TdException(r.code, r.message))
                else c.resume(r)
            }
        }
    }

    fun fire(f: TdApi.Object) {
        client?.let { TdBridge.send(it, f, null) }
    }

    /** Runs a request and reports the error text (or null on success). */
    suspend fun tryReq(f: TdApi.Object): String? = try {
        req(f); null
    } catch (e: TdException) {
        e.message ?: "error"
    } catch (e: Exception) {
        e.message ?: "error"
    }

    // ------------------------------------------------------------ updates

    private fun onUpdate(o: TdApi.Object) {
        when (o) {
            is TdApi.UpdateAuthorizationState -> handleAuth(o.authorizationState)
            is TdApi.UpdateConnectionState -> connection = when (o.state) {
                is TdApi.ConnectionStateReady -> ""
                is TdApi.ConnectionStateWaitingForNetwork -> "waiting"
                is TdApi.ConnectionStateConnectingToProxy -> "proxy"
                is TdApi.ConnectionStateConnecting -> "connecting"
                is TdApi.ConnectionStateUpdating -> "updating"
                else -> ""
            }
            is TdApi.UpdateOption -> if (o.name == "my_id") {
                (o.value as? TdApi.OptionValueInteger)?.let { meId = it.value }
            }
            is TdApi.UpdateNewChat -> { chatMap[o.chat.id] = o.chat; markDirty() }
            is TdApi.UpdateChatTitle -> chatMap[o.chatId]?.let { it.title = o.title; markDirty() }
            is TdApi.UpdateChatPhoto -> chatMap[o.chatId]?.let { it.photo = o.photo; markDirty() }
            is TdApi.UpdateChatLastMessage -> chatMap[o.chatId]?.let {
                it.lastMessage = o.lastMessage
                it.positions = o.positions
                markDirty()
            }
            is TdApi.UpdateChatPosition -> chatMap[o.chatId]?.let { chat ->
                if (o.position.list is TdApi.ChatListMain) {
                    val keep = chat.positions.filter { it.list !is TdApi.ChatListMain }.toMutableList()
                    if (o.position.order != 0L) keep.add(o.position)
                    chat.positions = keep.toTypedArray()
                    markDirty()
                }
            }
            is TdApi.UpdateChatReadInbox -> chatMap[o.chatId]?.let {
                it.lastReadInboxMessageId = o.lastReadInboxMessageId
                it.unreadCount = o.unreadCount
                markDirty()
            }
            is TdApi.UpdateChatReadOutbox -> chatMap[o.chatId]?.let {
                it.lastReadOutboxMessageId = o.lastReadOutboxMessageId
                markDirty()
            }
            is TdApi.UpdateChatActiveStories -> applyActiveStories(o.fieldOrNull("activeStories"))
            is TdApi.UpdateChatNotificationSettings -> chatMap[o.chatId]?.let { it.notificationSettings = o.notificationSettings; markDirty() }
            is TdApi.UpdateUser -> {
                userMap[o.user.id] = o.user
                if (o.user.id == meId) me = toUiUser(o.user)
                markDirty()
            }
            is TdApi.UpdateUserStatus -> userMap[o.userId]?.let { it.status = o.status }
            is TdApi.UpdateFile -> {
                val f = o.file
                if (f.local.isDownloadingCompleted && f.local.path.isNotEmpty()) main.post { files[f.id] = f.local.path }
            }
        }
        for (l in listeners) l(o)
    }

    private fun handleAuth(s: TdApi.AuthorizationState) {
        main.post { authState = s }
        when (s) {
            is TdApi.AuthorizationStateWaitTdlibParameters -> {
                val p = TdApi.SetTdlibParameters()
                p.databaseDirectory = File(appCtx.filesDir, "tdlib").absolutePath
                p.filesDirectory = (appCtx.getExternalFilesDir(null) ?: appCtx.filesDir).absolutePath
                p.databaseEncryptionKey = ByteArray(0)
                p.useFileDatabase = true
                p.useChatInfoDatabase = true
                p.useMessageDatabase = true
                p.useSecretChats = false
                p.apiId = BuildConfig.TG_API_ID
                p.apiHash = BuildConfig.TG_API_HASH
                p.systemLanguageCode = Locale.getDefault().language
                p.deviceModel = Build.MODEL
                p.systemVersion = Build.VERSION.RELEASE
                p.applicationVersion = "0.2.0"
                fire(p)
            }
            is TdApi.AuthorizationStateReady -> scope.launch {
                runCatching { loadMe() }
                scope.launch { runCatching { req(mk("LoadActiveStories", "storyList" to TdApi.StoryListMain())) } }
                while (true) {
                    val err = tryReq(mk("LoadChats", "chatList" to TdApi.ChatListMain(), "limit" to 100))
                    if (err != null) break
                }
            }
            is TdApi.AuthorizationStateClosed -> {
                client = null
                main.post {
                    chatMap.clear(); storyMap.clear(); stories = emptyList(); allChats = emptyList(); me = null; contacts = emptyList()
                    start(appCtx)
                }
            }
        }
    }

    suspend fun loadMe() {
        val u = req(TdApi.GetMe()) as TdApi.User
        meId = u.id
        userMap[u.id] = u
        me = toUiUser(u)
    }

    // ------------------------------------------------------------ chats

    private fun markDirty() {
        if (dirty) return
        dirty = true
        main.postDelayed({ dirty = false; buildChats() }, 200)
    }

    private fun buildChats() {
        val list = ArrayList<UiChat>()
        for (c in chatMap.values) {
            val pos = c.positions.firstOrNull { it.list is TdApi.ChatListMain } ?: continue
            if (pos.order == 0L) continue
            list.add(toUiChat(c, pos.order, pos.isPinned))
        }
        list.sortByDescending { it.order }
        allChats = list
        buildStories()
    }

    // ------------------------------------------------------------ stories

    /** Reads a ChatActiveStories object by reflection (field names differ a little between TDLib versions). */
    private fun applyActiveStories(a: Any?) {
        if (a == null) return
        val chatId = a.fieldOrNull("chatId") as? Long ?: return
        val order = a.fieldOrNull("order") as? Long ?: 0L
        val infos = a.fieldOrNull("stories") as? Array<*> ?: emptyArray<Any>()
        val maxRead = (a.fieldOrNull("maxReadStoryId") as? Int) ?: 0
        if (infos.isEmpty() || order == 0L) {
            storyMap.remove(chatId)
        } else {
            val unseen = infos.any { ((it?.fieldOrNull("storyId") as? Int) ?: 0) > maxRead }
            storyMap[chatId] = order to unseen
        }
        main.post { buildStories(); markDirty() }
    }

    private fun buildStories() {
        val out = ArrayList<UiStoryChat>()
        for ((id, v) in storyMap) {
            if (id != meId && id in Vault.hiddenIds) continue // hidden chats show no story ring either
            val c = chatMap[id] ?: continue
            val photo = c.photo?.small
            if (photo != null) registerFile(photo, true)
            out.add(UiStoryChat(id, c.title, photo?.id ?: 0, v.second, v.first, id == meId))
        }
        // Unseen first, then by Telegram's own story order.
        out.sortWith(compareByDescending<UiStoryChat> { it.unseen }.thenByDescending { it.order })
        stories = out
    }

    fun storyInfoFor(chatId: Long): Pair<Long, Boolean>? = storyMap[chatId]

    /** Story ids of a chat, oldest first. */
    suspend fun storyIds(chatId: Long): List<Int> {
        val a = req(mk("GetChatActiveStories", "chatId" to chatId))
        val infos = a.fieldOrNull("stories") as? Array<*> ?: return emptyList()
        return infos.mapNotNull { it?.fieldOrNull("storyId") as? Int }
    }

    data class UiStory(
        val id: Int, val chatId: Long, val isVideo: Boolean, val fileId: Int, val thumbFileId: Int,
        val caption: String, val date: Int,
    )

    suspend fun story(chatId: Long, storyId: Int): UiStory {
        val st = req(mk("GetStory", "storyPosterChatId" to chatId, "storyId" to storyId, "onlyLocal" to false))
        var video = false
        var fileId = 0
        var thumb = 0
        when (val content = st.fieldOrNull("content")) {
            is TdApi.StoryContentPhoto -> {
                val sizes = content.photo.sizes
                val best = sizes.maxByOrNull { it.width * it.height }
                best?.photo?.let { registerFile(it, true); fileId = it.id }
            }
            is TdApi.StoryContentVideo -> {
                video = true
                val v = content.video
                v.fieldOrNull("video")?.let { (it as? TdApi.File)?.let { f -> registerFile(f, true); fileId = f.id } }
                (v.fieldOrNull("thumbnail") as? TdApi.Thumbnail)?.file?.let { registerFile(it, true); thumb = it.id }
            }
        }
        val caption = (st.fieldOrNull("caption") as? TdApi.FormattedText)?.text ?: ""
        val date = (st.fieldOrNull("date") as? Int) ?: 0
        return UiStory(storyId, chatId, video, fileId, thumb, caption, date)
    }

    fun openStory(chatId: Long, id: Int) = fire(mk("OpenStory", "storyPosterChatId" to chatId, "storyId" to id))
    fun closeStory(chatId: Long, id: Int) = fire(mk("CloseStory", "storyPosterChatId" to chatId, "storyId" to id))

    /** Posts a photo as the user's own story (visible to everyone for 24 hours). Returns an error text or null. */
    suspend fun postPhotoStory(path: String): String? = try {
        val content = mk<TdApi.Object>("InputStoryContentPhoto", "photo" to local(path))
        req(
            mk(
                "PostStory",
                "chatId" to meId,
                "content" to content,
                "areas" to mk<TdApi.Object>("InputStoryAreas"),
                "caption" to ft(""),
                "privacySettings" to mk<TdApi.Object>("StoryPrivacySettingsEveryone"),
                "activePeriod" to 86400,
                "isPostedToChatPage" to false,
                "protectContent" to false,
            ),
        )
        null
    } catch (e: Exception) {
        e.message ?: "error"
    }

    /** A hidden chat can only be looked up while AjiMaji is unlocked. */
    fun chatById(id: Long): UiChat? {
        if (id in Vault.hiddenIds && !Vault.unlocked) return null
        return allChats.firstOrNull { it.id == id } ?: chatMap[id]?.let { toUiChat(it, 0, false) }
    }

    /** Raw TDLib chat; hidden chats are not available while AjiMaji is locked. */
    fun rawChat(id: Long): TdApi.Chat? {
        if (id in Vault.hiddenIds && !Vault.unlocked) return null
        return chatMap[id]
    }

    /** Full-size profile photo id once it is downloaded (0 = not yet, caller falls back to the small one). */
    fun bigUserPhotoId(userId: Long): Int {
        val big = userMap[userId]?.profilePhoto?.big ?: return 0
        registerFile(big, true)
        return if (files.containsKey(big.id)) big.id else 0
    }

    fun bigChatPhotoId(chatId: Long): Int {
        val big = rawChat(chatId)?.photo?.big ?: return 0
        registerFile(big, true)
        return if (files.containsKey(big.id)) big.id else 0
    }

    fun chatKindLabel(isChannel: Boolean, isSupergroup: Boolean): String = when {
        isChannel -> tr("کانال", "Channel")
        isSupergroup -> tr("سوپرگروه", "Supergroup")
        else -> tr("گروه", "Group")
    }

    /** Looks up a public @username on Telegram. Chats hidden in AjiMaji are never revealed by this. */
    suspend fun findPublic(username: String): Long? {
        val u = username.trim().removePrefix("https://").removePrefix("http://").removePrefix("t.me/").removePrefix("@")
        if (u.isEmpty()) return null
        val chat = req(mk("SearchPublicChat", "username" to u)) as TdApi.Chat
        if (chat.id in Vault.hiddenIds) return null
        chatMap[chat.id] = chat
        return chat.id
    }

    /** Id of a public chat by @username, or null when it does not exist. Never returns hidden chats. */
    suspend fun chatByUsername(username: String): Long? = try { findPublic(username) } catch (e: Exception) { null }

    /** A chat found through search as a list row (works for chats that are not in the main list yet). */
    fun searchResultChat(id: Long): UiChat? {
        if (id in Vault.hiddenIds) return null
        val c = chatMap[id] ?: return null
        val pos = c.positions.firstOrNull { it.list is TdApi.ChatListMain }
        val ui = toUiChat(c, pos?.order ?: 0L, pos?.isPinned ?: false)
        if (ui.last.isNotEmpty()) return ui
        val label = when {
            ui.bot -> tr("ربات", "Bot")
            ui.kind == ChatKind.CHANNEL -> tr("کانال", "Channel")
            ui.kind == ChatKind.GROUP -> tr("گروه", "Group")
            else -> tr("کاربر", "User")
        }
        return ui.copy(last = label)
    }

    /**
     * Global search like Telegram's own: your chats, chats on the server (also channels/groups you
     * have not joined), public channels, groups, bots and users, and an exact @username lookup.
     */
    suspend fun searchGlobal(q: String): List<UiChat> {
        val query = q.trim()
        if (query.length < 2) return emptyList()
        val ids = LinkedHashSet<Long>()
        suspend fun add(fn: String, vararg f: Pair<String, Any?>) {
            val r = runCatching { req(mk<TdApi.Object>(fn, *f)) }.getOrNull()
            when (r) {
                is TdApi.Chats -> for (id in r.chatIds) ids.add(id)
                is TdApi.Chat -> { chatMap[r.id] = r; ids.add(r.id) }
            }
        }
        val plain = query.removePrefix("@")
        add("SearchChats", "query" to plain, "limit" to 30)
        add("SearchChatsOnServer", "query" to plain, "limit" to 30)
        add("SearchPublicChats", "query" to plain)
        val exact = query.removePrefix("https://").removePrefix("http://").removePrefix("t.me/").removePrefix("@")
        if ((query.startsWith("@") || query.contains("t.me/")) && Regex("[A-Za-z][A-Za-z0-9_]{3,31}").matches(exact)) {
            add("SearchPublicChat", "username" to exact)
        }
        return ids.mapNotNull { searchResultChat(it) }
    }

    /** Called by Vault after the hidden set changed. */
    fun onHiddenChanged() {
        main.post { buildStories() }
    }

    private fun toUiChat(c: TdApi.Chat, order: Long, pinned: Boolean): UiChat {
        val t = c.type
        val kind = when (t) {
            is TdApi.ChatTypePrivate -> ChatKind.PRIVATE
            is TdApi.ChatTypeBasicGroup -> ChatKind.GROUP
            is TdApi.ChatTypeSupergroup -> if (t.isChannel) ChatKind.CHANNEL else ChatKind.GROUP
            else -> ChatKind.OTHER
        }
        val uid = (t as? TdApi.ChatTypePrivate)?.userId ?: 0L
        val photo = c.photo?.small
        if (photo != null) registerFile(photo, true)
        return UiChat(
            id = c.id,
            title = c.title,
            last = c.lastMessage?.let { previewOf(it.content) } ?: "",
            time = c.lastMessage?.let { fmtTime(it.date) } ?: "",
            unread = c.unreadCount,
            muted = c.notificationSettings?.muteFor?.let { it > 0 } ?: false,
            pinned = pinned,
            photoFileId = photo?.id ?: 0,
            kind = kind,
            verified = uid != 0L && userMap[uid]?.let { isVerified(it) } == true,
            saved = uid != 0L && uid == meId,
            userId = uid,
            order = order,
            lastOutgoing = c.lastMessage?.isOutgoing == true,
            lastRead = c.lastMessage?.let { it.isOutgoing && it.id <= c.lastReadOutboxMessageId } == true,
            bot = uid != 0L && userMap[uid]?.type is TdApi.UserTypeBot,
            storyState = storyMap[c.id]?.let { if (it.second) 2 else 1 } ?: 0,
            secret = t is TdApi.ChatTypeSecret,
        )
    }

    private fun isVerified(u: TdApi.User): Boolean {
        (u.fieldOrNull("isVerified") as? Boolean)?.let { if (it) return true }
        val vs = u.fieldOrNull("verificationStatus") ?: return false
        return vs.fieldOrNull("isVerified") as? Boolean ?: false
    }

    // ------------------------------------------------------------ users

    fun userName(id: Long): String {
        val u = userMap[id]
        if (u == null) {
            scope.launch { runCatching { loadUser(id) } }
            return ""
        }
        return "${u.firstName} ${u.lastName}".trim()
    }

    suspend fun loadUser(id: Long): TdApi.User {
        userMap[id]?.let { return it }
        val u = req(mk("GetUser", "userId" to id)) as TdApi.User
        userMap[id] = u
        return u
    }

    private fun usernameOf(u: TdApi.User): String {
        val names = u.fieldOrNull("usernames")?.fieldOrNull("activeUsernames") as? Array<*>
        return (names?.firstOrNull() as? String) ?: (u.fieldOrNull("username") as? String) ?: ""
    }

    fun statusText(s: TdApi.UserStatus?): String = when (s) {
        is TdApi.UserStatusOnline -> tr("آنلاین", "online")
        is TdApi.UserStatusOffline -> tr("آخرین بازدید ", "last seen ") + fmtTime(s.wasOnline)
        is TdApi.UserStatusRecently -> tr("اخیراً آنلاین", "last seen recently")
        is TdApi.UserStatusLastWeek -> tr("هفته‌ی گذشته آنلاین", "last seen within a week")
        is TdApi.UserStatusLastMonth -> tr("ماه گذشته آنلاین", "last seen within a month")
        else -> ""
    }

    fun toUiUser(u: TdApi.User): UiUser {
        val p = u.profilePhoto?.small
        if (p != null) registerFile(p, true)
        return UiUser(
            id = u.id,
            name = "${u.firstName} ${u.lastName}".trim(),
            username = usernameOf(u),
            phone = u.phoneNumber,
            status = statusText(u.status),
            photoFileId = p?.id ?: 0,
            verified = isVerified(u),
        )
    }

    fun userInfo(id: Long): UiUser? = userMap[id]?.let { toUiUser(it) }

    suspend fun loadContacts() {
        val ids = (req(TdApi.GetContacts()) as TdApi.Users).userIds
        contacts = ids.mapNotNull { runCatching { toUiUser(loadUser(it)) }.getOrNull() }
            .sortedBy { it.name.lowercase() }
    }

    suspend fun openPrivateChat(userId: Long): Long {
        val chat = req(mk("CreatePrivateChat", "userId" to userId, "force" to false)) as TdApi.Chat
        chatMap[chat.id] = chat
        return chat.id
    }

    suspend fun createChat(title: String, channel: Boolean): Long {
        val chat = req(
            mk(
                "CreateNewSupergroupChat",
                "title" to title, "isChannel" to channel, "description" to "",
            ),
        ) as TdApi.Chat
        chatMap[chat.id] = chat
        return chat.id
    }

    // ------------------------------------------------------------ files

    fun registerFile(f: TdApi.File, auto: Boolean) {
        if (f.local.isDownloadingCompleted && f.local.path.isNotEmpty()) {
            if (files[f.id] != f.local.path) main.post { files[f.id] = f.local.path }
        } else if (auto) {
            download(f.id)
        }
    }

    /** Stops a running download; it can be started again later. */
    fun cancelDownload(fileId: Int) {
        requested.remove(fileId)
        fire(mk("CancelDownloadFile", "fileId" to fileId, "onlyIfPending" to false))
    }

    fun download(fileId: Int) {
        if (fileId == 0 || files.containsKey(fileId)) return
        if (requested.add(fileId)) {
            fire(mk("DownloadFile", "fileId" to fileId, "priority" to 1, "offset" to 0L, "limit" to 0L, "synchronous" to false))
        }
    }

    // ------------------------------------------------------------ messages

    suspend fun history(chatId: Long, from: Long, limit: Int = 40): List<UiMessage> {
        val r = req(
            mk(
                "GetChatHistory",
                "chatId" to chatId, "fromMessageId" to from, "offset" to 0, "limit" to limit, "onlyLocal" to false,
            ),
        ) as TdApi.Messages
        return r.messages.filterNotNull().map { toUi(it) }
    }

    /**
     * TDLib may answer GetChatHistory with only a few cached messages (often just the last one)
     * while it is still loading the rest. This asks again until the page is reasonably full or
     * TDLib really has nothing more, so the chat opens with the whole history right away.
     */
    suspend fun historyFull(chatId: Long, from: Long, limit: Int = 40, onPartial: (List<UiMessage>) -> Unit = {}): List<UiMessage> {
        var best = runCatching { history(chatId, from, limit) }.getOrDefault(emptyList())
        if (best.isNotEmpty() && best.size < limit / 2) onPartial(best)
        var tries = 0
        var stable = 0
        while (best.size < limit / 2 && tries < 6 && stable < 2) {
            delay(if (tries == 0) 300L else 450L)
            val again = runCatching { history(chatId, from, limit) }.getOrDefault(emptyList())
            if (again.size > best.size) { best = again; stable = 0 } else stable++
            tries++
        }
        return best
    }

    suspend fun message(chatId: Long, id: Long): UiMessage =
        toUi(req(mk("GetMessage", "chatId" to chatId, "messageId" to id)) as TdApi.Message)

    suspend fun search(chatId: Long, q: String): List<UiMessage> {
        val r = req(
            mk(
                "SearchChatMessages",
                "chatId" to chatId, "query" to q, "fromMessageId" to 0L, "offset" to 0, "limit" to 50,
                "filter" to TdApi.SearchMessagesFilterEmpty(),
            ),
        ) as TdApi.FoundChatMessages
        return r.messages.map { toUi(it) }
    }

    suspend fun pinned(chatId: Long): UiMessage? = runCatching {
        toUi(req(mk("GetChatPinnedMessage", "chatId" to chatId)) as TdApi.Message)
    }.getOrNull()

    fun markRead(chatId: Long, ids: List<Long>) {
        if (ids.isEmpty()) return
        fire(mk("ViewMessages", "chatId" to chatId, "messageIds" to ids.toLongArray(), "forceRead" to true))
    }

    private fun replyObj(replyTo: Long, chatId: Long): TdApi.Object? =
        if (replyTo == 0L) null else mk("InputMessageReplyToMessage", "messageId" to replyTo)

    suspend fun send(chatId: Long, content: TdApi.Object, replyTo: Long = 0): String? {
        val fields = mutableListOf<Pair<String, Any?>>("chatId" to chatId, "inputMessageContent" to content)
        replyObj(replyTo, chatId)?.let { fields.add("replyTo" to it) }
        return tryReq(mk("SendMessage", *fields.toTypedArray()))
    }

    suspend fun sendText(chatId: Long, text: String, replyTo: Long = 0) =
        send(chatId, mk("InputMessageText", "text" to ft(text)), replyTo)

    private fun local(path: String): TdApi.Object = mk("InputFileLocal", "path" to path)

    suspend fun sendPhoto(chatId: Long, path: String, replyTo: Long = 0) =
        send(chatId, mk("InputMessagePhoto", "photo" to local(path), "caption" to ft("")), replyTo)

    suspend fun sendVideo(chatId: Long, path: String, replyTo: Long = 0) =
        send(chatId, mk("InputMessageVideo", "video" to local(path), "supportsStreaming" to true, "caption" to ft("")), replyTo)

    suspend fun sendDocument(chatId: Long, path: String, replyTo: Long = 0) =
        send(chatId, mk("InputMessageDocument", "document" to local(path), "caption" to ft("")), replyTo)

    suspend fun sendVoice(chatId: Long, path: String, seconds: Int, replyTo: Long = 0) =
        send(chatId, mk("InputMessageVoiceNote", "voiceNote" to local(path), "duration" to seconds, "caption" to ft("")), replyTo)

    suspend fun editText(chatId: Long, id: Long, text: String) =
        tryReq(mk("EditMessageText", "chatId" to chatId, "messageId" to id, "inputMessageContent" to mk<TdApi.Object>("InputMessageText", "text" to ft(text))))

    suspend fun delete(chatId: Long, id: Long, everyone: Boolean) =
        tryReq(mk("DeleteMessages", "chatId" to chatId, "messageIds" to longArrayOf(id), "revoke" to everyone))

    suspend fun forward(toChat: Long, fromChat: Long, id: Long) =
        tryReq(mk("ForwardMessages", "chatId" to toChat, "fromChatId" to fromChat, "messageIds" to longArrayOf(id), "sendCopy" to false, "removeCaption" to false))

    suspend fun pin(chatId: Long, id: Long, pin: Boolean) =
        if (pin) tryReq(mk("PinChatMessage", "chatId" to chatId, "messageId" to id, "disableNotification" to true, "onlyForSelf" to false))
        else tryReq(mk("UnpinChatMessage", "chatId" to chatId, "messageId" to id))

    suspend fun react(chatId: Long, id: Long, emoji: String, chosen: Boolean): String? {
        val type = mk<TdApi.Object>("ReactionTypeEmoji", "emoji" to emoji)
        return if (chosen) tryReq(mk("RemoveMessageReaction", "chatId" to chatId, "messageId" to id, "reactionType" to type))
        else tryReq(mk("AddMessageReaction", "chatId" to chatId, "messageId" to id, "reactionType" to type, "isBig" to false, "updateRecentReactions" to true))
    }

    fun openChat(id: Long) = fire(mk("OpenChat", "chatId" to id))
    fun closeChat(id: Long) = fire(mk("CloseChat", "chatId" to id))

    fun readOutbox(chatId: Long): Long = chatMap[chatId]?.lastReadOutboxMessageId ?: 0L

    // ------------------------------------------------------------ mapping

    fun previewOf(c: TdApi.MessageContent): String = when (c) {
        is TdApi.MessageText -> c.text.text
        is TdApi.MessagePhoto -> c.caption.text.ifEmpty { tr("🖼 عکس", "🖼 Photo") }
        is TdApi.MessageVideo -> c.caption.text.ifEmpty { tr("🎬 ویدیو", "🎬 Video") }
        is TdApi.MessageAnimation -> "GIF"
        is TdApi.MessageVoiceNote -> tr("🎤 پیام صوتی", "🎤 Voice message")
        is TdApi.MessageVideoNote -> tr("⏺ پیام ویدیویی", "⏺ Video message")
        is TdApi.MessageAudio -> "🎵 " + c.audio.title
        is TdApi.MessageDocument -> "📄 " + c.document.fileName
        is TdApi.MessageSticker -> c.sticker.emoji + " " + tr("استیکر", "Sticker")
        is TdApi.MessageLocation -> tr("📍 موقعیت مکانی", "📍 Location")
        is TdApi.MessageContact -> tr("👤 مخاطب", "👤 Contact")
        is TdApi.MessagePoll -> tr("📊 نظرسنجی", "📊 Poll")
        else -> tr("پیام", "Message")
    }

    fun previewTextOf(m: UiMessage): String = when {
        m.text.isNotEmpty() -> m.text
        m.kind == MsgKind.PHOTO -> tr("🖼 عکس", "🖼 Photo")
        m.kind == MsgKind.VIDEO -> tr("🎬 ویدیو", "🎬 Video")
        m.kind == MsgKind.VOICE -> tr("🎤 پیام صوتی", "🎤 Voice message")
        m.kind == MsgKind.STICKER -> m.emoji + " " + tr("استیکر", "Sticker")
        m.kind == MsgKind.DOC -> "📄 " + m.fileName
        else -> tr("پیام", "Message")
    }

    fun fmtTime(date: Int): String {
        val d = Date(date * 1000L)
        val today = SimpleDateFormat("yyyyMMdd", Locale.US)
        val sameDay = today.format(d) == today.format(Date())
        return SimpleDateFormat(if (sameDay) "HH:mm" else "MM/dd", Locale.US).format(d)
    }

    private fun entitiesOf(t: TdApi.FormattedText?): List<UiEntity> {
        if (t == null) return emptyList()
        val out = ArrayList<UiEntity>()
        for (e in t.entities) {
            when (val ty = e.type) {
                is TdApi.TextEntityTypeUrl -> out.add(UiEntity(e.offset, e.length, 1))
                is TdApi.TextEntityTypeMention -> out.add(UiEntity(e.offset, e.length, 2))
                is TdApi.TextEntityTypeTextUrl -> out.add(UiEntity(e.offset, e.length, 3, url = ty.url))
                is TdApi.TextEntityTypeMentionName -> out.add(UiEntity(e.offset, e.length, 4, userId = ty.userId))
            }
        }
        return out
    }

    fun toUi(m: TdApi.Message): UiMessage {
        val c = m.content
        var kind = MsgKind.OTHER
        var text = ""
        var fileId = 0
        var thumb = 0
        var w = 0
        var h = 0
        var dur = 0
        var name = ""
        var size = 0L
        var sf = 0
        var emoji = ""
        var ftext: TdApi.FormattedText? = null
        fun thumbOf(t: TdApi.Thumbnail?): Int = t?.file?.also { registerFile(it, true) }?.id ?: 0
        when (c) {
            is TdApi.MessageText -> { kind = MsgKind.TEXT; text = c.text.text; ftext = c.text }
            is TdApi.MessagePhoto -> {
                kind = MsgKind.PHOTO
                text = c.caption.text; ftext = c.caption
                val sizes = c.photo.sizes
                val best = sizes.filter { it.width <= 1280 }.maxByOrNull { it.width } ?: sizes.minByOrNull { it.width }
                if (best != null) {
                    fileId = best.photo.id; w = best.width; h = best.height
                    registerFile(best.photo, true)
                }
            }
            is TdApi.MessageVideo -> {
                kind = MsgKind.VIDEO; text = c.caption.text; ftext = c.caption
                fileId = c.video.video.id; size = c.video.video.size.toLong()
                w = c.video.width; h = c.video.height; dur = c.video.duration
                registerFile(c.video.video, false); thumb = thumbOf(c.video.thumbnail)
            }
            is TdApi.MessageAnimation -> {
                kind = MsgKind.ANIMATION; text = c.caption.text; ftext = c.caption
                fileId = c.animation.animation.id
                w = c.animation.width; h = c.animation.height; dur = c.animation.duration
                registerFile(c.animation.animation, false); thumb = thumbOf(c.animation.thumbnail)
            }
            is TdApi.MessageVideoNote -> {
                kind = MsgKind.VIDEO_NOTE
                fileId = c.videoNote.video.id; dur = c.videoNote.duration
                registerFile(c.videoNote.video, false); thumb = thumbOf(c.videoNote.thumbnail)
            }
            is TdApi.MessageDocument -> {
                kind = MsgKind.DOC; text = c.caption.text; ftext = c.caption
                fileId = c.document.document.id; name = c.document.fileName; size = c.document.document.size.toLong()
                registerFile(c.document.document, false)
            }
            is TdApi.MessageVoiceNote -> {
                kind = MsgKind.VOICE; text = c.caption.text; ftext = c.caption
                fileId = c.voiceNote.voice.id; dur = c.voiceNote.duration
                registerFile(c.voiceNote.voice, true)
            }
            is TdApi.MessageAudio -> {
                kind = MsgKind.AUDIO; text = c.caption.text; ftext = c.caption
                fileId = c.audio.audio.id; dur = c.audio.duration
                name = (c.audio.performer + " - " + c.audio.title).trim(' ', '-')
                registerFile(c.audio.audio, false)
            }
            is TdApi.MessageSticker -> {
                kind = MsgKind.STICKER
                fileId = c.sticker.sticker.id; emoji = c.sticker.emoji
                w = c.sticker.width; h = c.sticker.height
                sf = when (c.sticker.format) {
                    is TdApi.StickerFormatTgs -> 1
                    is TdApi.StickerFormatWebm -> 2
                    else -> 0
                }
                registerFile(c.sticker.sticker, true); thumb = thumbOf(c.sticker.thumbnail)
            }
            else -> { kind = MsgKind.OTHER; text = previewOf(c) }
        }
        var replyId = 0L
        var replyText = ""
        val rt = m.replyTo
        if (rt is TdApi.MessageReplyToMessage) {
            replyId = rt.messageId
            (rt.fieldOrNull("content") as? TdApi.MessageContent)?.let { replyText = previewOf(it) }
        }
        val rr = m.interactionInfo?.fieldOrNull("reactions")
        val arr = (rr as? Array<*>) ?: (rr?.fieldOrNull("reactions") as? Array<*>)
        val reactions = arr?.mapNotNull { x ->
            val r = x as? TdApi.MessageReaction ?: return@mapNotNull null
            val e = (r.type as? TdApi.ReactionTypeEmoji)?.emoji ?: return@mapNotNull null
            UiReaction(e, r.totalCount, r.isChosen)
        } ?: emptyList()
        val sender = when (val s = m.senderId) {
            is TdApi.MessageSenderUser -> userName(s.userId)
            is TdApi.MessageSenderChat -> chatMap[s.chatId]?.title ?: ""
            else -> ""
        }
        return UiMessage(
            id = m.id, chatId = m.chatId, outgoing = m.isOutgoing, date = m.date, sender = sender,
            kind = kind, text = text, fileId = fileId, thumbFileId = thumb, width = w, height = h,
            duration = dur, fileName = name, fileSize = size, stickerFormat = sf, replyToId = replyId,
            replyText = replyText, edited = m.editDate != 0, pinned = m.isPinned,
            sending = m.sendingState is TdApi.MessageSendingStatePending,
            failed = m.sendingState is TdApi.MessageSendingStateFailed,
            reactions = reactions, emoji = emoji,
            senderUserId = (m.senderId as? TdApi.MessageSenderUser)?.userId ?: 0L,
            sendError = (m.sendingState as? TdApi.MessageSendingStateFailed)?.error?.message ?: "",
            canRetry = (m.sendingState as? TdApi.MessageSendingStateFailed)?.canRetry ?: false,
            entities = entitiesOf(ftext),
        )
    }

    // ------------------------------------------------------------ auth + account

    fun setPhone(number: String) = scope.launch {
        val err = tryReq(mk("SetAuthenticationPhoneNumber", "phoneNumber" to number))
        if (err != null) authError = err
    }

    var authError by mutableStateOf<String?>(null)

    fun submit(f: TdApi.Object) = scope.launch {
        val err = tryReq(f)
        main.post { authError = err }
    }

    fun logOut() {
        Vault.wipe() // hidden ids belong to this account; they must not survive a logout
        fire(TdApi.LogOut())
    }

    // ------------------------------------------------------------ proxies

    suspend fun proxies(): List<Map<String, Any?>> {
        val r = req(TdApi.GetProxies())
        val arr = r.fieldOrNull("proxies") as? Array<*> ?: return emptyList()
        return arr.filterNotNull().map { p ->
            val t = p.fieldOrNull("type")
            mapOf(
                "id" to p.fieldOrNull("id"), "server" to p.fieldOrNull("server"),
                "port" to p.fieldOrNull("port"), "enabled" to p.fieldOrNull("isEnabled"),
                "type" to (t?.javaClass?.simpleName ?: ""),
            )
        }
    }

    suspend fun addProxy(server: String, port: Int, secret: String, user: String, pass: String): String? {
        val type: TdApi.Object = if (secret.isNotEmpty()) mk("ProxyTypeMtproto", "secret" to secret)
        else mk("ProxyTypeSocks5", "username" to user, "password" to pass)
        return tryReq(mk("AddProxy", "server" to server, "port" to port, "enable" to true, "type" to type))
    }

    suspend fun enableProxy(id: Int) = tryReq(mk("EnableProxy", "proxyId" to id))
    suspend fun disableProxy() = tryReq(TdApi.DisableProxy())
    suspend fun removeProxy(id: Int) = tryReq(mk("RemoveProxy", "proxyId" to id))

    suspend fun pingProxy(id: Int): String {
        return try {
            val r = req(mk("PingProxy", "proxyId" to id))
            val s = r.fieldOrNull("seconds") as? Double ?: return "?"
            "${(s * 1000).toInt()} ms"
        } catch (e: Exception) {
            "✕"
        }
    }

    // ------------------------------------------------------------ profile

    suspend fun bio(userId: Long): String {
        val info = req(mk("GetUserFullInfo", "userId" to userId))
        return when (val b = info.fieldOrNull("bio")) {
            is String -> b
            is TdApi.FormattedText -> b.text
            else -> ""
        }
    }

    suspend fun setName(first: String, last: String) = tryReq(mk("SetName", "firstName" to first, "lastName" to last))
    suspend fun setBio(bio: String) = tryReq(mk("SetBio", "bio" to bio))
    suspend fun setUsername(u: String) = tryReq(mk("SetUsername", "username" to u))
    suspend fun setProfilePhoto(path: String) = tryReq(
        mk(
            "SetProfilePhoto",
            "photo" to mk<TdApi.Object>("InputChatPhotoStatic", "photo" to local(path)),
            "isPublic" to false,
        ),
    )

    suspend fun sessions(): List<TdApi.Session> =
        (req(TdApi.GetActiveSessions()) as TdApi.Sessions).sessions.toList()

    suspend fun terminateSession(id: Long) = tryReq(mk("TerminateSession", "sessionId" to id))

    // ------------------------------------------------------------ groups

    class Member(val userId: Long, val name: String, val role: String)

    suspend fun members(chatId: Long): List<Member> {
        val chat = chatMap[chatId] ?: return emptyList()
        val raw: List<TdApi.ChatMember> = when (val t = chat.type) {
            is TdApi.ChatTypeSupergroup -> {
                val r = req(
                    mk(
                        "GetSupergroupMembers",
                        "supergroupId" to t.supergroupId, "filter" to TdApi.SupergroupMembersFilterRecent(),
                        "offset" to 0, "limit" to 100,
                    ),
                ) as TdApi.ChatMembers
                r.members.toList()
            }
            is TdApi.ChatTypeBasicGroup -> {
                val r = req(mk("GetBasicGroupFullInfo", "basicGroupId" to t.basicGroupId))
                (r.fieldOrNull("members") as? Array<*>)?.filterIsInstance<TdApi.ChatMember>() ?: emptyList()
            }
            else -> emptyList()
        }
        return raw.mapNotNull { m ->
            val uid = (m.memberId as? TdApi.MessageSenderUser)?.userId ?: return@mapNotNull null
            val role = when (m.status) {
                is TdApi.ChatMemberStatusCreator -> "owner"
                is TdApi.ChatMemberStatusAdministrator -> "admin"
                else -> "member"
            }
            val u = runCatching { loadUser(uid) }.getOrNull()
            Member(uid, u?.let { "${it.firstName} ${it.lastName}".trim() } ?: uid.toString(), role)
        }
    }

    suspend fun inviteLink(chatId: Long): String {
        val r = req(
            mk(
                "CreateChatInviteLink",
                "chatId" to chatId, "name" to "", "expirationDate" to 0, "memberLimit" to 0, "createsJoinRequest" to false,
            ),
        )
        return r.fieldOrNull("inviteLink") as? String ?: ""
    }

    suspend fun addMember(chatId: Long, userId: Long) =
        tryReq(mk("AddChatMember", "chatId" to chatId, "userId" to userId, "forwardLimit" to 0))

    suspend fun banMember(chatId: Long, userId: Long) = tryReq(
        mk(
            "SetChatMemberStatus",
            "chatId" to chatId,
            "memberId" to mk<TdApi.Object>("MessageSenderUser", "userId" to userId),
            "status" to mk<TdApi.Object>("ChatMemberStatusBanned", "bannedUntilDate" to 0),
        ),
    )

    suspend fun leave(chatId: Long) = tryReq(mk("LeaveChat", "chatId" to chatId))

    fun isChannel(chatId: Long): Boolean = (chatMap[chatId]?.type as? TdApi.ChatTypeSupergroup)?.isChannel == true
    fun isPrivate(chatId: Long): Boolean = chatMap[chatId]?.type is TdApi.ChatTypePrivate
}
