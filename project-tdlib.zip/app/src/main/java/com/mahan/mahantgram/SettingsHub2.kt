package com.mahan.mahantgram

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

/** App-level settings that TDLib has no concept of. Saved in SharedPreferences, read live by the chat and theme code. */
object AppPrefs {
    private var sp: SharedPreferences? = null
    var textSize by mutableIntStateOf(15)
    var corner by mutableIntStateOf(18)
    var sendByEnter by mutableStateOf(false)
    var amoled by mutableStateOf(false)
    var largeEmoji by mutableStateOf(true)
    var autoplayGif by mutableStateOf(true)
    var rowPad by mutableIntStateOf(10)

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("mahan_app_prefs", Context.MODE_PRIVATE)
        sp = p
        textSize = p.getInt("textSize", 15)
        corner = p.getInt("corner", 18)
        sendByEnter = p.getBoolean("sendByEnter", false)
        amoled = p.getBoolean("amoled", false)
        largeEmoji = p.getBoolean("largeEmoji", true)
        autoplayGif = p.getBoolean("autoplayGif", true)
        rowPad = p.getInt("rowPad", 10)
    }

    fun save() { sp?.edit()?.putInt("textSize", textSize)?.putInt("corner", corner)?.putBoolean("sendByEnter", sendByEnter)?.putBoolean("amoled", amoled)?.putBoolean("largeEmoji", largeEmoji)?.putBoolean("autoplayGif", autoplayGif)?.putInt("rowPad", rowPad)?.apply() }

    fun reset() { textSize = 15; corner = 18; sendByEnter = false; amoled = false; largeEmoji = true; autoplayGif = true; rowPad = 10; save() }
}

class HubCallbacks(
    val lang: String, val onLang: (String) -> Unit,
    val themeMode: String, val onTheme: (String) -> Unit,
    val onAccent: (Int) -> Unit,
    val pattern: Int, val onPattern: (Int) -> Unit,
    val blurOn: Boolean, val onBlur: (Boolean) -> Unit,
    val glassAlpha: Float, val onAlpha: (Float) -> Unit,
)

// ============================================================ Chat settings

@Composable
internal fun ChatSettingsPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var archiveMute by remember { mutableStateOf(false) }
    var keepUnmuted by remember { mutableStateOf(false) }
    var keepFolders by remember { mutableStateOf(false) }
    var archiveOk by remember { mutableStateOf(false) }
    var reaction by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        runCatching {
            val a = Td.req(mk<TdApi.Object>("GetArchiveChatListSettings"))
            archiveMute = a.fieldOrNull("archiveAndMuteNewChatsFromUnknownUsers") == true
            keepUnmuted = a.fieldOrNull("keepUnmutedChatsArchived") == true
            keepFolders = a.fieldOrNull("keepChatsFromFoldersArchived") == true
            archiveOk = true
        }
        runCatching {
            val r = Td.req(mk<TdApi.Object>("GetDefaultReactionType")) // not in every TDLib build
            reaction = (r.fieldOrNull("emoji") as? String) ?: ""
        }
    }
    fun saveArchive(m: Boolean, u: Boolean, f: Boolean) {
        archiveMute = m; keepUnmuted = u; keepFolders = f
        scope.launch {
            val st = mk<TdApi.Object>("ArchiveChatListSettings", "archiveAndMuteNewChatsFromUnknownUsers" to m, "keepUnmutedChatsArchived" to u, "keepChatsFromFoldersArchived" to f)
            Td.tryReq(mk("SetArchiveChatListSettings", "settings" to st))?.let { toast(ctx, it) }
        }
    }
    SPage(tr("تنظیمات گفتگو", "Chat settings"), onBack) {
        SHeader(tr("نمایش پیام‌ها", "Messages"))
        SValueRow(tr("اندازه‌ی متن پیام", "Message text size"), "${AppPrefs.textSize} sp", null)
        Slider(value = AppPrefs.textSize.toFloat(), onValueChange = { AppPrefs.textSize = it.toInt() }, onValueChangeFinished = { AppPrefs.save() }, valueRange = 12f..24f)
        SValueRow(tr("گردی گوشه‌ی پیام‌ها", "Message corners"), "${AppPrefs.corner} dp", null)
        Slider(value = AppPrefs.corner.toFloat(), onValueChange = { AppPrefs.corner = it.toInt() }, onValueChangeFinished = { AppPrefs.save() }, valueRange = 4f..28f)
        SSwitchRow(tr("ارسال با Enter", "Send by Enter"), tr("دکمه‌ی کیبورد پیام را می‌فرستد", "The keyboard action sends the message"), AppPrefs.sendByEnter) { AppPrefs.sendByEnter = it; AppPrefs.save() }
        SSwitchRow(tr("ایموجی بزرگ", "Large emoji"), tr("پیام فقط ایموجی بزرگ نمایش داده می‌شود", "Emoji-only messages are shown big"), AppPrefs.largeEmoji) { AppPrefs.largeEmoji = it; AppPrefs.save() }
        SSwitchRow(tr("پخش خودکار GIF", "Autoplay GIFs"), tr("اگر خاموش باشد با لمس پخش می‌شود", "When off, tap to play"), AppPrefs.autoplayGif) { AppPrefs.autoplayGif = it; AppPrefs.save() }
        SHeader(tr("فهرست گفتگوها", "Chat list"))
        SValueRow(tr("تراکم فهرست", "Chat list density"), when (AppPrefs.rowPad) { 5 -> tr("فشرده", "Compact"); 14 -> tr("راحت", "Comfortable"); else -> tr("معمولی", "Normal") }) {
            AppPrefs.rowPad = when (AppPrefs.rowPad) { 10 -> 5; 5 -> 14; else -> 10 }; AppPrefs.save()
        }
        SHeader(tr("واکنش پیش‌فرض", "Default reaction"))
        SValueRow(tr("واکنش پیش‌فرض (دوبار لمس)", "Default reaction"), reaction.ifEmpty { "—" }) { dlg = true }
        SHeader(tr("آرشیو", "Archive"))
        if (!archiveOk) SNote(tr("در حال بارگذاری…", "Loading…")) else {
            SSwitchRow(tr("آرشیو و بی‌صدا کردن چت‌های ناشناس", "Archive and mute unknown senders"), "", archiveMute) { saveArchive(it, keepUnmuted, keepFolders) }
            SSwitchRow(tr("نگه داشتن چت‌های بی‌صدا نشده در آرشیو", "Keep unmuted chats archived"), "", keepUnmuted) { saveArchive(archiveMute, it, keepFolders) }
            SSwitchRow(tr("نگه داشتن چت‌های پوشه در آرشیو", "Keep folder chats archived"), "", keepFolders) { saveArchive(archiveMute, keepUnmuted, it) }
        }
    }
    if (dlg) {
        val opts = listOf("👍", "❤️", "🔥", "😂", "😮", "😢")
        RadioDialog(tr("واکنش پیش‌فرض", "Default reaction"), opts, opts.indexOf(reaction), { dlg = false }) { i ->
            dlg = false
            scope.launch {
                val e = Td.tryReq(mk("SetDefaultReactionType", "reactionType" to mk<TdApi.Object>("ReactionTypeEmoji", "emoji" to opts[i])))
                if (e != null) toast(ctx, e) else reaction = opts[i]
            }
        }
    }
}

// ============================================================ Devices

@Composable
internal fun DevicesPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<TdApi.Session>>(emptyList()) }
    var tick by remember { mutableIntStateOf(0) }
    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(tick) { list = runCatching { Td.sessions() }.getOrDefault(emptyList()) }
    val cur = list.firstOrNull { it.isCurrent }
    SPage(tr("دستگاه‌ها", "Devices"), onBack) {
        if (cur != null) {
            SHeader(tr("نشست فعلی", "Current session"))
            SessionBox(cur, null)
        }
        val others = list.filter { !it.isCurrent }
        if (others.isNotEmpty()) {
            SDanger(tr("پایان همه‌ی نشست‌های دیگر", "Terminate all other sessions")) { confirm = true }
            SHeader(tr("دستگاه‌های متصل", "Connected devices"))
            others.forEach { s ->
                SessionBox(s) { scope.launch { Td.terminateSession(s.id)?.let { toast(ctx, it) }; tick++ } }
            }
        }
    }
    if (confirm) ConfirmDialog(tr("همه‌ی دستگاه‌های دیگر از حساب خارج می‌شوند.", "All other devices will be logged out."), tr("پایان", "Terminate"), { confirm = false }) {
        confirm = false
        scope.launch { Td.tryReq(mk("TerminateAllOtherSessions"))?.let { toast(ctx, it) }; tick++ }
    }
}

@Composable
private fun SessionBox(s: TdApi.Session, onTerminate: (() -> Unit)?) {
    val ip = s.fieldOrNull("ipAddress") as? String ?: ""
    val loc = listOfNotNull(s.fieldOrNull("location") as? String, s.fieldOrNull("country") as? String).filter { it.isNotBlank() }.joinToString(" · ")
    SValueRow(s.applicationName, s.deviceModel + " · " + s.platform, null)
    if (ip.isNotEmpty() || loc.isNotEmpty()) SValueRow(tr("آی‌پی و مکان", "IP and location"), listOf(ip, loc).filter { it.isNotEmpty() }.joinToString(" · "), null)
    SValueRow(tr("تاریخ ورود", "Login date"), Td.fmtTime(s.logInDate), null)
    SValueRow(tr("آخرین فعالیت", "Last active"), Td.fmtTime(s.lastActiveDate), null)
    if (onTerminate != null) SDanger(tr("پایان این نشست", "Terminate session"), onTerminate)
}

// ============================================================ Language

@Composable
internal fun LanguagePage(cb: HubCallbacks, onBack: () -> Unit) {
    SPage(tr("زبان", "Language"), onBack) {
        SNote(tr("زبان فارسی چیدمان راست‌به‌چپ (RTL) را خودکار فعال می‌کند.", "Persian switches the whole app to right-to-left layout."))
        APP_LANGS.forEach { (code, name) ->
            SValueRow(name, if (cb.lang == code) "✓" else "") { cb.onLang(code) }
        }
    }
}

// ============================================================ Appearance

@Composable
internal fun AppearancePage(cb: HubCallbacks, onBack: () -> Unit) {
    var hue by remember { mutableStateOf(140f) }
    SPage(tr("ظاهر", "Appearance"), onBack) {
        SHeader(tr("تم", "Theme"))
        SValueRow(tr("پیش‌فرض سیستم", "System default"), if (cb.themeMode == "system") "✓" else "") { cb.onTheme("system") }
        SValueRow(tr("روشن", "Light"), if (cb.themeMode == "light") "✓" else "") { cb.onTheme("light") }
        SValueRow(tr("تیره", "Dark"), if (cb.themeMode == "dark") "✓" else "") { cb.onTheme("dark") }
        SSwitchRow("AMOLED", tr("پس‌زمینه‌ی مشکی کامل در تم تیره", "Pure black background in dark theme"), AppPrefs.amoled) { AppPrefs.amoled = it; AppPrefs.save() }
        SHeader(tr("رنگ برنامه", "Accent color"))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(0xFF22D17B, 0xFF2D9CFF, 0xFFFF7AB8, 0xFFA66BFF, 0xFFFF9F43, 0xFFFF5C5C, 0xFFFFD23F, 0xFF22D3EE).forEach { argb ->
                Row(Modifier.size(36.dp).clip(CircleShape).background(Color(argb.toInt())).clickable { cb.onAccent(argb.toInt()) }) {}
            }
        }
        Slider(value = hue, onValueChange = { hue = it; cb.onAccent(Color.hsv(it, 0.72f, 0.92f).toArgb()) }, valueRange = 0f..360f)
        SHeader(tr("پس‌زمینه‌ی چت", "Chat background"))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(tr("ساده", "None"), cb.pattern == 0) { cb.onPattern(0) }
            Pill(tr("نقطه", "Dots"), cb.pattern == 1) { cb.onPattern(1) }
            Pill(tr("حلقه", "Rings"), cb.pattern == 2) { cb.onPattern(2) }
            Pill(tr("بعلاوه", "Plus"), cb.pattern == 3) { cb.onPattern(3) }
        }
        SHeader(tr("شیشه‌ای", "Glass"))
        SSwitchRow(tr("محو کردن پس‌زمینه", "Background blur"), "", cb.blurOn) { cb.onBlur(it) }
        Slider(value = cb.glassAlpha, onValueChange = cb.onAlpha, valueRange = 0.1f..0.9f)
    }
}

// ============================================================ Advanced

@Composable
internal fun AdvancedPage(onBack: () -> Unit, onProxy: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var version by remember { mutableStateOf("—") }
    var diag by remember { mutableStateOf("") }
    var proxyOn by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        version = runCatching { (Td.req(mk<TdApi.Object>("GetOption", "name" to "version")).fieldOrNull("value") as? String) ?: "—" }.getOrDefault("—")
        proxyOn = runCatching { Td.proxies().any { it["enabled"] == true } }.getOrDefault(false)
    }
    SPage(tr("تنظیمات پیشرفته", "Advanced"), onBack) {
        SHeader(tr("اتصال", "Connection"))
        SValueRow(tr("وضعیت اتصال", "Connection state"), Td.connection.ifEmpty { tr("متصل", "Connected") }, null)
        SValueRow(tr("پروکسی (SOCKS5 / MTProto)", "Proxy (SOCKS5 / MTProto)"), if (proxyOn) tr("روشن", "On") else tr("خاموش", "Off")) { onProxy() }
        if (proxyOn) SDanger(tr("خاموش کردن پروکسی", "Disable proxy")) {
            scope.launch { Td.disableProxy()?.let { toast(ctx, it) }; tick++ }
        }
        SValueRow(tr("تشخیص شبکه", "Network diagnostics"), diag.ifEmpty { tr("اجرا", "Run") }) {
            diag = tr("در حال بررسی…", "Testing…")
            scope.launch {
                val t0 = System.currentTimeMillis()
                val e = Td.tryReq(mk("TestNetwork"))
                diag = if (e == null) "OK · ${System.currentTimeMillis() - t0} ms" else e
            }
        }
        SHeader(tr("اطلاعات", "Debug information"))
        SValueRow("TDLib", version, null)
        SValueRow(tr("نسخه‌ی برنامه", "App version"), BuildConfig.VERSION_NAME, null)
        SDanger(tr("بازنشانی تنظیمات برنامه", "Reset app settings")) { confirm = true }
    }
    if (confirm) ConfirmDialog(tr("اندازه‌ی متن، گوشه‌ها، ارسال با Enter و AMOLED به حالت پیش‌فرض برمی‌گردد.", "Text size, corners, send by Enter and AMOLED return to defaults."), tr("بازنشانی", "Reset"), { confirm = false }) {
        confirm = false; AppPrefs.reset()
    }
}

// ============================================================ Stickers and emoji

@Composable
internal fun StickersPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    var installed by remember { mutableStateOf<List<Triple<Long, String, Boolean>>>(emptyList()) }
    var archived by remember { mutableStateOf<List<Triple<Long, String, Boolean>>>(emptyList()) }
    var trending by remember { mutableStateOf<List<Triple<Long, String, Boolean>>>(emptyList()) }
    var emoji by remember { mutableStateOf<List<Triple<Long, String, Boolean>>>(emptyList()) }
    var favorites by remember { mutableIntStateOf(0) }
    var gifs by remember { mutableIntStateOf(0) }
    fun parse(r: Any?) = (r?.fieldOrNull("sets") as? Array<*>).orEmpty().mapNotNull { s ->
        val id = s?.fieldOrNull("id") as? Long ?: return@mapNotNull null
        Triple(id, (s.fieldOrNull("title") as? String) ?: "", s.fieldOrNull("isInstalled") == true)
    }
    LaunchedEffect(tick) {
        val reg = { mk<TdApi.Object>("StickerTypeRegular") }
        installed = runCatching { parse(Td.req(mk<TdApi.Object>("GetInstalledStickerSets", "stickerType" to reg()))) }.getOrDefault(emptyList())
        archived = runCatching { parse(Td.req(mk<TdApi.Object>("GetArchivedStickerSets", "stickerType" to reg(), "offsetStickerSetId" to 0L, "limit" to 50))) }.getOrDefault(emptyList())
        trending = runCatching { parse(Td.req(mk<TdApi.Object>("GetTrendingStickerSets", "stickerType" to reg(), "offset" to 0, "limit" to 20))) }.getOrDefault(emptyList())
        emoji = runCatching { parse(Td.req(mk<TdApi.Object>("GetInstalledStickerSets", "stickerType" to mk<TdApi.Object>("StickerTypeCustomEmoji")))) }.getOrDefault(emptyList())
        favorites = runCatching { (Td.req(mk<TdApi.Object>("GetFavoriteStickers")).fieldOrNull("stickers") as? Array<*>)?.size ?: 0 }.getOrDefault(0)
        gifs = runCatching { (Td.req(mk<TdApi.Object>("GetSavedAnimations")).fieldOrNull("animations") as? Array<*>)?.size ?: 0 }.getOrDefault(0)
    }
    fun change(id: Long, inst: Boolean, arch: Boolean) = scope.launch {
        Td.tryReq(mk("ChangeStickerSet", "setId" to id, "isInstalled" to inst, "isArchived" to arch))?.let { toast(ctx, it) }
        tick++
    }
    SPage(tr("استیکر و ایموجی", "Stickers and emoji"), onBack) {
        SValueRow(tr("استیکرهای مورد علاقه", "Favorite stickers"), favorites.toString(), null)
        SValueRow("GIF", gifs.toString(), null)
        SHeader(tr("بسته‌های من (برای آرشیو بزنید)", "My packs (tap to archive)"))
        if (installed.isEmpty()) SNote(tr("بسته‌ای نیست.", "No packs."))
        installed.forEach { (id, t, _) -> SValueRow(t, tr("آرشیو", "Archive")) { change(id, true, true) } }
        SHeader(tr("بسته‌های ایموجی", "Emoji packs"))
        if (emoji.isEmpty()) SNote(tr("بسته‌ای نیست.", "No packs."))
        emoji.forEach { (_, t, _) -> SValueRow(t, "", null) }
        SHeader(tr("آرشیو (برای فعال‌سازی بزنید)", "Archived (tap to restore)"))
        if (archived.isEmpty()) SNote(tr("آرشیوی نیست.", "Nothing archived."))
        archived.forEach { (id, t, _) -> SValueRow(t, tr("بازگردانی", "Restore")) { change(id, true, false) } }
        SHeader(tr("پرطرفدار (برای افزودن بزنید)", "Trending (tap to add)"))
        trending.forEach { (id, t, inst) -> SValueRow(t, if (inst) "✓" else tr("افزودن", "Add")) { if (!inst) change(id, true, false) } }
    }
}

// ============================================================ Premium

@Composable
internal fun PremiumSettingsPage(onBack: () -> Unit, onPremium: () -> Unit) {
    val on = Td.me?.premium == true
    SPage("Premium", onBack) {
        SValueRow(tr("وضعیت", "Status"), if (on) tr("فعال", "Active") else tr("غیرفعال", "Not active"), null)
        SValueRow(tr("امکانات، استیکر، ایموجی و واکنش‌های ویژه", "Features, stickers, emoji and reactions"), "") { onPremium() }
    }
}
