package com.mahan.mahantgram

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) = Vault.onScreenOff()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = getSharedPreferences("mahan", MODE_PRIVATE)
        Accent.color = Color(prefs.getInt("accent", 0xFF22D17B.toInt()))
        CategoryStore.init(applicationContext)
        // Must run before TDLib starts, so hidden chats are never shown even for a moment.
        Vault.init(applicationContext)
        Transfers.init()
        ContextCompat.registerReceiver(
            this, screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        Td.start(applicationContext)
        setContent { MahanApp(prefs) }
    }

    override fun onStart() {
        super.onStart()
        Vault.onAppStart()
    }

    override fun onStop() {
        super.onStop()
        Vault.onAppStop(isChangingConfigurations)
    }

    override fun onDestroy() {
        if (isFinishing) Vault.onAppExit()
        runCatching { unregisterReceiver(screenOff) }
        super.onDestroy()
    }

    // Pickers and other apps launched from here are not "leaving the app" for auto-lock.
    @Suppress("DEPRECATION")
    override fun startActivityForResult(intent: Intent, requestCode: Int, options: Bundle?) {
        Vault.noteExternalLaunch()
        super.startActivityForResult(intent, requestCode, options)
    }
}
