package com.mahan.mahantgram

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefs = getSharedPreferences("mahan", MODE_PRIVATE)
        Accent.color = Color(prefs.getInt("accent", 0xFF22D17B.toInt()))
        Td.start(applicationContext)
        setContent { MahanApp(prefs) }
    }
}
