package com.mahan.mahantgram

import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val StoryDanger = Color(0xFFFF6B6B)

// ====================================================================== composer: pick -> caption -> preview -> post

@Composable
fun StoryComposerDialog(path: String, isVideo: Boolean, onDismiss: () -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val premium = Td.me?.premium == true
    val limit = StoryOps.captionLimit()
    var caption by remember { mutableStateOf("") }
    var privacy by remember { mutableIntStateOf(0) }
    var period by remember { mutableIntStateOf(86400) }
    var posting by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = { if (!posting) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            Modifier.fillMaxSize().background(c.bg).statusBarsPadding().navigationBarsPadding().imePadding()
                .verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    tr("استوری جدید", "New story"), color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                Icon(
                    Icons.Rounded.Close, null, tint = c.subtext,
                    modifier = Modifier.clip(CircleShape).clickable(enabled = !posting, onClick = onDismiss).padding(6.dp),
                )
            }
            Text(tr("پیش‌نمایش", "Preview"), color = c.subtext, fontSize = 13.sp)
            // The preview is drawn the way viewers will see it, caption included.
            Box(Modifier.fillMaxWidth().height(380.dp).clip(RoundedCornerShape(18.dp)).background(Color.Black)) {
                if (isVideo) {
                    StoryPreviewVideo(path)
                } else {
                    val bmp = rememberBitmap(path, 1600)
                    if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    else Text(tr("در حال بارگذاری…", "Loading…"), color = Color.White, modifier = Modifier.align(Alignment.Center))
                }
                if (caption.isNotBlank()) {
                    Text(
                        caption, color = Color.White, fontSize = 15.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.45f)).padding(12.dp),
                    )
                }
            }
            OutlinedTextField(
                value = caption,
                onValueChange = { if (it.length <= limit + 50) caption = it },
                label = { Text(tr("کپشن (اختیاری)", "Caption (optional)")) },
                maxLines = 4,
                enabled = !posting,
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "${caption.length}/$limit", fontSize = 12.sp,
                color = if (caption.length > limit) StoryDanger else c.subtext,
                modifier = Modifier.align(Alignment.End),
            )
            Text(tr("چه کسانی ببینند؟", "Who can view?"), color = c.subtext, fontSize = 13.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0, 1, 2).forEach { p -> Pill(StoryOps.privacyLabel(p), privacy == p) { if (!posting) privacy = p } }
            }
            Text(tr("مدت نمایش", "Stays up for"), color = c.subtext, fontSize = 13.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val options = if (premium) listOf(6, 12, 24, 48) else listOf(6, 12, 24)
                options.forEach { h ->
                    Pill(trf("{0} ساعت", "{0} h", h), period == h * 3600) { if (!posting) period = h * 3600 }
                }
            }
            if (!premium) Text(tr("۴۸ ساعت فقط برای پرمیوم است.", "48 hours needs Telegram Premium."), color = c.subtext, fontSize = 12.sp)
            error?.let { Text(it, color = StoryDanger, fontSize = 14.sp) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TextButton(onClick = onDismiss, enabled = !posting, modifier = Modifier.weight(1f)) { Text(tr("لغو", "Cancel")) }
                TextButton(
                    enabled = !posting,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        error = null
                        if (caption.length > limit) {
                            error = trf("کپشن حداکثر {0} نویسه است", "The caption can have at most {0} characters", limit)
                            return@TextButton
                        }
                        posting = true
                        scope.launch {
                            val duration = if (isVideo) withContext(Dispatchers.IO) { StoryOps.videoDuration(path) } else 0.0
                            if (isVideo && duration > StoryOps.MAX_VIDEO_SECONDS) {
                                error = tr("ویدیوی استوری حداکثر ۶۰ ثانیه می‌تواند باشد", "A story video can be at most 60 seconds")
                                posting = false
                                return@launch
                            }
                            val err = StoryOps.post(path, isVideo, caption.trim(), period, privacy, duration)
                            posting = false
                            if (err == null) {
                                toast(ctx, tr("استوری منتشر شد", "Story posted"))
                                onDismiss()
                            } else {
                                error = friendlyError(err)
                            }
                        }
                    },
                ) { Text(if (posting) tr("در حال ارسال…", "Posting…") else tr("انتشار", "Post"), fontWeight = FontWeight.Bold) }
            }
        }
    }
}

/** Looping, muted preview of the picked video. */
@Composable
private fun StoryPreviewVideo(path: String) {
    val ctx = LocalContext.current
    val player = remember(path) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(File(path))))
            repeatMode = Player.REPEAT_MODE_ALL
            volume = 0f
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { PlayerView(it).apply { this.player = player; useController = false } },
        modifier = Modifier.fillMaxSize(),
    )
}

// ====================================================================== manage own stories

@Composable
fun MyStoriesDialog(onDismiss: () -> Unit, onView: () -> Unit, onAdd: (() -> Unit)?) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<OwnStory>?>(null) }
    var deleting by remember { mutableStateOf<OwnStory?>(null) }
    var viewersFor by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(Unit) { items = StoryOps.own() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("استوری‌های من", "My stories")) },
        text = {
            val l = items
            when {
                l == null -> Text(tr("در حال بارگذاری…", "Loading…"), color = c.subtext)
                l.isEmpty() -> Text(tr("استوری فعالی نداری.", "You have no active stories."), color = c.subtext)
                else -> Column(Modifier.height(340.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    l.forEach { s ->
                        val ui = s.ui
                        val thumbPath = ui?.let { if (it.isVideo) Td.files[it.thumbFileId] else Td.files[it.fileId] }
                        val bmp = rememberBitmap(thumbPath, 300)
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)).background(Color(0x33000000)).clickable { onView() }) {
                                if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            }
                            Column(Modifier.weight(1f)) {
                                Text(
                                    (if (ui?.isVideo == true) "🎬 " else "🖼 ") + (ui?.caption?.ifEmpty { null } ?: tr("بدون کپشن", "No caption")),
                                    color = c.text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                )
                                val rem = StoryOps.remaining(s.extra)
                                val priv = StoryOps.privacyLabel(s.extra?.privacy ?: -1)
                                Text(
                                    listOfNotNull(rem, priv.ifEmpty { null }).joinToString(" · "),
                                    color = c.subtext, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                )
                                Row(
                                    Modifier.clip(RoundedCornerShape(8.dp)).clickable(enabled = s.extra?.canSeeViewers == true) { viewersFor = s.id },
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Icon(Icons.Rounded.Visibility, null, tint = c.subtext, modifier = Modifier.size(16.dp))
                                    Text(" ${s.extra?.viewCount ?: 0}", color = c.subtext, fontSize = 12.sp)
                                }
                            }
                            if (s.extra?.canDelete != false) Icon(
                                Icons.Rounded.Delete, null, tint = StoryDanger,
                                modifier = Modifier.clip(CircleShape).clickable { deleting = s }.padding(6.dp),
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { if (onAdd != null) TextButton(onClick = { onDismiss(); onAdd() }) { Text(tr("استوری جدید", "New story")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("بستن", "Close")) } },
    )

    deleting?.let { s ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text(tr("حذف استوری", "Delete story")) },
            text = { Text(tr("این استوری برای همه حذف می‌شود.", "This story will be removed for everyone.")) },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    scope.launch {
                        val err = StoryOps.delete(Td.meId, s.id)
                        if (err == null) items = items?.filter { it.id != s.id }
                        else toast(ctx, friendlyError(err))
                    }
                }) { Text(tr("حذف", "Delete"), color = StoryDanger) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text(tr("لغو", "Cancel")) } },
        )
    }
    viewersFor?.let { id -> StoryViewersDialog(id) { viewersFor = null } }
}

// ====================================================================== who saw the story

@Composable
fun StoryViewersDialog(storyId: Int, onDismiss: () -> Unit) {
    val c = LocalMahan.current
    var loaded by remember { mutableStateOf(false) }
    var data by remember { mutableStateOf<Pair<Int, List<StoryViewerRow>>?>(null) }
    LaunchedEffect(storyId) {
        data = StoryOps.viewers(storyId)
        loaded = true
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(data?.let { trf("بازدیدکنندگان ({0})", "Viewers ({0})", it.first) } ?: tr("بازدیدکنندگان", "Viewers")) },
        text = {
            val d = data
            when {
                !loaded -> Text(tr("در حال بارگذاری…", "Loading…"), color = c.subtext)
                d == null -> Text(tr("تلگرام فهرست بازدیدکنندگان این استوری را نمایش نمی‌دهد.", "Telegram doesn't show the viewers of this story."), color = c.subtext)
                d.second.isEmpty() -> Text(tr("هنوز کسی ندیده است", "Nobody has seen it yet"), color = c.subtext)
                else -> Column(Modifier.height(280.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    d.second.forEach { r ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(r.name, color = c.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            if (r.reaction.isNotEmpty()) Text(r.reaction, fontSize = 18.sp)
                            if (r.time > 0) Text(Td.fmtTime(r.time), color = c.subtext, fontSize = 12.sp)
                        }
                    }
                    Spacer(Modifier.height(2.dp))
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("بستن", "Close")) } },
    )
}
