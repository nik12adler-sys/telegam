package com.mahan.mahantgram

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.drinkless.tdlib.TdApi

@Composable
private fun Section(content: @Composable () -> Unit) {
    val c = LocalMahan.current
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(c.glassTint.copy(alpha = 0.35f)).border(1.dp, c.glassBorder, shape).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) { content() }
}

@Composable
private fun Wide(text: String, danger: Boolean = false, onClick: () -> Unit) {
    val c = LocalMahan.current
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(c.glassTint.copy(alpha = 0.4f)).clickable(onClick = onClick).padding(16.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = if (danger) Color(0xFFFF6B6B) else Green, fontSize = 16.sp) }
}

@Composable
private fun Garage() {
    Row(Modifier.fillMaxWidth().height(120.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.Bottom) {
        Image(painterResource(R.drawable.car_gtr_small), null, Modifier.height(60.dp))
    }
}

// ------------------------------------------------------------------ profile

@Composable
fun LiveProfile(
    onBack: () -> Unit,
    onSettings: () -> Unit,
    embedded: Boolean = false,
    topPad: androidx.compose.ui.unit.Dp = 0.dp,
    bottomPad: androidx.compose.ui.unit.Dp = 0.dp,
    onPremium: () -> Unit = {},
) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me = Td.me
    var bio by remember { mutableStateOf("") }
    var edit by remember { mutableStateOf(false) }
    LaunchedEffect(me?.id) { me?.let { bio = runCatching { Td.bio(it.id) }.getOrDefault("") } }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            scope.launch {
                val p = withContext(Dispatchers.IO) { copyUriToCache(ctx, it) }
                if (p != null) Td.setProfilePhoto(p)?.let { e -> toast(ctx, e) }
            }
        }
    }
    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            scope.launch {
                val p = withContext(Dispatchers.IO) { copyUriToCache(ctx, it) }
                if (p != null) {
                    val err = Premium.setAnimatedPhoto(p)
                    if (err == null) toast(ctx, tr("عکس متحرک ثبت شد", "Animated photo set"))
                    else if (err.contains("premium", true)) { toast(ctx, tr("این قابلیت به تلگرام پرمیوم نیاز دارد", "This needs Telegram Premium")); onPremium() }
                    else toast(ctx, friendlyError(err))
                }
            }
        }
    }
    Column(
        (if (embedded) {
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, top = topPad + 8.dp, bottom = bottomPad)
        } else {
            Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp).navigationBarsPadding()
        }),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        if (!embedded) Row(Modifier.fillMaxWidth()) { BackButton(onBack) }
        Avatar(me?.photoFileId ?: 0, me?.name ?: "M", 112.dp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(me?.name ?: "", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (me?.verified == true) {
                Spacer(Modifier.width(5.dp))
                Icon(Icons.Rounded.Verified, null, tint = VerifiedBlue, modifier = Modifier.size(20.dp))
            }
            if (me?.premium == true) {
                Spacer(Modifier.width(5.dp))
                PremiumBadge(me.statusEmojiId, 20.dp)
            }
        }
        Text(tr("آنلاین", "online"), color = Green, fontSize = 14.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile(Icons.Rounded.AddAPhoto, tr("تنظیم عکس", "Set Photo"), Modifier.weight(1f)) { pick.launch("image/*") }
            Tile(Icons.Rounded.Edit, tr("ویرایش اطلاعات", "Edit Info"), Modifier.weight(1f)) { edit = true }
            Tile(Icons.Rounded.Settings, tr("تنظیمات", "Settings"), Modifier.weight(1f), onSettings)
        }
        Section {
            Info(if (me?.phone.isNullOrEmpty()) "" else "+" + me?.phone, tr("موبایل", "Mobile"))
            Info(bio, tr("بیوگرافی", "Bio"))
            Info(me?.username?.let { if (it.isEmpty()) "" else "@$it" } ?: "", tr("نام کاربری", "Username"))
        }
        Wide(tr("عکس پروفایل متحرک ⭐", "Animated profile photo ⭐")) {
            if (!Premium.active) { toast(ctx, tr("این قابلیت به تلگرام پرمیوم نیاز دارد", "This needs Telegram Premium")); onPremium() }
            else pickVideo.launch("video/*")
        }
        Garage()
        Wide(tr("خروج از حساب", "Log out"), danger = true) { Td.logOut() }
    }
    if (edit) {
        val full = (me?.name ?: "")
        var first by remember { mutableStateOf(full.substringBefore(' ')) }
        var last by remember { mutableStateOf(full.substringAfter(' ', "")) }
        var b by remember { mutableStateOf(bio) }
        var user by remember { mutableStateOf(me?.username ?: "") }
        AlertDialog(
            onDismissRequest = { edit = false },
            title = { Text(tr("ویرایش اطلاعات", "Edit info")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    InputField(first, { first = it }, tr("نام", "First name"), Modifier.fillMaxWidth())
                    InputField(last, { last = it }, tr("نام خانوادگی", "Last name"), Modifier.fillMaxWidth())
                    InputField(b, { b = it }, tr("بیوگرافی", "Bio"), Modifier.fillMaxWidth())
                    InputField(user, { user = it }, tr("نام کاربری", "Username"), Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    edit = false
                    scope.launch {
                        val errs = listOfNotNull(
                            Td.setName(first, last), Td.setBio(b),
                            if (user != (me?.username ?: "")) Td.setUsername(user) else null,
                        )
                        bio = b
                        errs.firstOrNull()?.let { toast(ctx, it) }
                    }
                }) { Text(tr("ذخیره", "Save")) }
            },
            dismissButton = { TextButton(onClick = { edit = false }) { Text(tr("لغو", "Cancel")) } },
        )
    }
}

@Composable
private fun Tile(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    val c = LocalMahan.current
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.clip(shape).background(c.glassTint.copy(alpha = 0.45f)).border(1.dp, c.glassBorder, shape).clickable(onClick = onClick).padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(icon, null, tint = c.text)
        Text(label, color = c.text, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
private fun Info(value: String, label: String) {
    val c = LocalMahan.current
    Column(Modifier.fillMaxWidth()) {
        Text(value.ifEmpty { "—" }, color = c.text, fontSize = 16.sp)
        Text(label, color = c.subtext, fontSize = 12.sp)
    }
}

// ------------------------------------------------------------------ proxy

private class ProxyParams(val server: String, val port: Int, val secret: String, val user: String, val pass: String)

private fun parseProxy(text: String): ProxyParams? {
    val uri = runCatching { Uri.parse(text.trim()) }.getOrNull() ?: return null
    val server = uri.getQueryParameter("server") ?: return null
    val port = uri.getQueryParameter("port")?.toIntOrNull() ?: return null
    return ProxyParams(
        server, port, uri.getQueryParameter("secret") ?: "",
        uri.getQueryParameter("user") ?: "", uri.getQueryParameter("pass") ?: "",
    )
}

@Composable
fun LiveProxy(onBack: () -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<Map<String, Any?>>>(emptyList()) }
    var pings by remember { mutableStateOf<Map<Int, String>>(emptyMap()) }
    var adding by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) { list = runCatching { Td.proxies() }.getOrDefault(emptyList()) }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BackButton(onBack)
            Text(tr("پروکسی", "Proxy"), color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Section {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(tr("استفاده از پروکسی", "Use proxy"), color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Switch(
                    checked = list.any { it["enabled"] == true },
                    onCheckedChange = { on ->
                        scope.launch {
                            val err = if (on) list.firstOrNull()?.let { Td.enableProxy((it["id"] as Number).toInt()) } else Td.disableProxy()
                            err?.let { toast(ctx, it) }
                            tick++
                        }
                    },
                    colors = SwitchDefaults.colors(checkedTrackColor = Green, checkedThumbColor = Color.White),
                )
            }
            if (connectionText().isNotEmpty()) Text(connectionText(), color = c.subtext, fontSize = 12.sp)
        }
        list.forEach { p ->
            val id = (p["id"] as? Number)?.toInt() ?: 0
            val on = p["enabled"] == true
            val shape = RoundedCornerShape(20.dp)
            Row(
                Modifier.fillMaxWidth().clip(shape).background(c.glassTint.copy(alpha = 0.4f))
                    .border(if (on) 1.5.dp else 1.dp, if (on) Green else c.glassBorder, shape)
                    .clickable { scope.launch { (if (on) Td.disableProxy() else Td.enableProxy(id))?.let { toast(ctx, it) }; tick++ } }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Box(Modifier.size(10.dp).background(if (on) Green else Color(0xFF777777), CircleShape))
                Column(Modifier.weight(1f)) {
                    Text(((p["type"] as? String) ?: "").removePrefix("ProxyType") + if (on) " · " + tr("فعال", "Active") else "", color = c.text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("${p["server"]}:${p["port"]}", color = c.subtext, fontSize = 12.sp)
                }
                Text(
                    pings[id] ?: "🏓", color = c.subtext, fontSize = 13.sp,
                    modifier = Modifier.clip(CircleShape).clickable { scope.launch { pings = pings + (id to "…"); pings = pings + (id to Td.pingProxy(id)) } }.padding(8.dp),
                )
                Text("✕", color = Color(0xFFFF6B6B), modifier = Modifier.clip(CircleShape).clickable { scope.launch { Td.removeProxy(id); tick++ } }.padding(8.dp))
            }
        }
        Wide(tr("افزودن پروکسی", "Add proxy")) { adding = true }
    }
    if (adding) {
        var link by remember { mutableStateOf("") }
        var server by remember { mutableStateOf("") }
        var port by remember { mutableStateOf("") }
        var secret by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text(tr("افزودن پروکسی", "Add proxy")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    InputField(link, { link = it }, tr("لینک پروکسی (tg://proxy…)", "Proxy link (tg://proxy…)"), Modifier.fillMaxWidth())
                    Text(tr("یا دستی:", "or manually:"), fontSize = 12.sp)
                    InputField(server, { server = it }, tr("سرور", "Server"), Modifier.fillMaxWidth())
                    InputField(port, { port = it.filter { ch -> ch.isDigit() } }, tr("پورت", "Port"), Modifier.fillMaxWidth(), KeyboardType.Number)
                    InputField(secret, { secret = it }, tr("سکرت (MTProto)", "Secret (MTProto)"), Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val p = if (link.isNotBlank()) parseProxy(link)
                    else port.toIntOrNull()?.let { ProxyParams(server.trim(), it, secret.trim(), "", "") }
                    if (p == null || p.server.isEmpty()) {
                        toast(ctx, tr("اطلاعات پروکسی درست نیست", "Invalid proxy details"))
                    } else {
                        adding = false
                        scope.launch { Td.addProxy(p.server, p.port, p.secret, p.user, p.pass)?.let { toast(ctx, it) }; tick++ }
                    }
                }) { Text(tr("افزودن", "Add")) }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text(tr("لغو", "Cancel")) } },
        )
    }
}

// ------------------------------------------------------------------ sessions

@Composable
fun LiveSessions(onBack: () -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<TdApi.Session>>(emptyList()) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) { list = runCatching { Td.sessions() }.getOrDefault(emptyList()) }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BackButton(onBack)
            Text(tr("دستگاه‌های متصل", "Active sessions"), color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        list.forEach { s ->
            Section {
                Text(s.applicationName + if (s.isCurrent) " · " + tr("این دستگاه", "this device") else "", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(s.deviceModel + " · " + s.platform, color = c.subtext, fontSize = 13.sp)
                Text(Td.fmtTime(s.lastActiveDate), color = c.subtext, fontSize = 12.sp)
                if (!s.isCurrent) {
                    Text(
                        tr("پایان نشست", "Terminate"), color = Color(0xFFFF6B6B), fontSize = 14.sp,
                        modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable {
                            scope.launch { Td.terminateSession(s.id)?.let { toast(ctx, it) }; tick++ }
                        }.padding(vertical = 6.dp),
                    )
                }
            }
        }
    }
}
