@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mahan.mahantgram

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.ui.focus.focusRequester
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Done
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun LiveChatRow(chat: UiChat, onLongClick: (() -> Unit)? = null, onAvatar: (() -> Unit)? = null, onClick: () -> Unit) {
    val c = LocalMahan.current
    Row(
        Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick).padding(horizontal = 16.dp, vertical = AppPrefs.rowPad.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(62.dp).then(if (onAvatar != null) Modifier.clip(CircleShape).clickable(onClick = onAvatar) else Modifier),
            contentAlignment = Alignment.Center,
        ) {
            StoryAvatar(chat.photoFileId, chat.title, 54.dp, chat.storyState)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (chat.saved) tr("پیام‌های ذخیره‌شده", "Saved Messages") else chat.title,
                    color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
                )
                if (chat.verified) {
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Rounded.Verified, null, tint = VerifiedBlue, modifier = Modifier.size(16.dp))
                }
                if (chat.premium) {
                    Spacer(Modifier.width(4.dp))
                    PremiumBadge(chat.statusEmojiId)
                }
                if (chat.bot) {
                    Spacer(Modifier.width(6.dp))
                    Text(
                        tr("ربات", "BOT"), color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.background(VerifiedBlue, RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 1.dp),
                    )
                }
                if (chat.muted) Text(" 🔕", fontSize = 12.sp)
            }
            Text(chat.last, color = c.subtext, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Delivery status of my own last message: one tick = sent, two green ticks = read.
                if (chat.lastOutgoing) {
                    Icon(
                        if (chat.lastRead) Icons.Rounded.DoneAll else Icons.Rounded.Done, null,
                        tint = if (chat.lastRead) Green else c.subtext, modifier = Modifier.size(16.dp),
                    )
                    Spacer(Modifier.width(3.dp))
                }
                Text(chat.time, color = c.subtext, fontSize = 12.sp)
            }
            if (chat.unread > 0) {
                Box(
                    Modifier
                        .padding(top = 6.dp)
                        .defaultMinSize(minWidth = 22.dp)
                        .height(22.dp)
                        .background(if (chat.muted) c.subtext else Green, CircleShape)
                        .padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(chat.unread.toString(), color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            } else if (chat.pinned) {
                Text("📌", fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

/** Real chat list. kind = null shows every chat, otherwise only groups or channels. */
@Composable
fun LiveChatList(
    kind: ChatKind?,
    query: String,
    topPad: Dp,
    bottomPad: Dp,
    onOpen: (Long) -> Unit,
    onCreate: (() -> Unit)?,
    onAvatar: ((Long) -> Unit)? = null,
    onQuery: ((String) -> Unit)? = null,
    focusTick: Int = 0,
) {
    val c = LocalMahan.current
    val listState = rememberLazyListState()
    val searchFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(focusTick) {
        if (focusTick > 0) {
            listState.scrollToItem(0)
            delay(80)
            runCatching { searchFocus.requestFocus() }
        }
    }
    var viewingStory by remember { mutableStateOf<Long?>(null) }
    var categoryFor by remember { mutableStateOf<UiChat?>(null) }
    var vaultFor by remember { mutableStateOf<UiChat?>(null) }
    val all = Td.chats
    val cats = CategoryStore.categories
    val selected = cats.firstOrNull { it.id == CategoryStore.selectedId } ?: cats.firstOrNull()
    val shown = all.filter { ch ->
        (kind == null || ch.kind == kind) &&
            // While searching, look through every chat; otherwise show only the selected category.
            (kind != null || query.isNotBlank() || selected == null || CategoryStore.matches(selected, ch)) &&
            (query.isBlank() || ch.title.contains(query, true) || ch.last.contains(query, true))
    }
    // Global search (like Telegram): channels/groups you have not joined, bots, new users, public chats.
    var globalHits by remember { mutableStateOf<List<UiChat>>(emptyList()) }
    var globalBusy by remember { mutableStateOf(false) }
    LaunchedEffect(query) {
        val q = query.trim()
        if (q.length < 2) { globalHits = emptyList(); globalBusy = false; return@LaunchedEffect }
        globalBusy = true
        delay(450) // wait for the person to stop typing
        globalHits = runCatching { Td.searchGlobal(q) }.getOrDefault(emptyList())
        globalBusy = false
    }
    val shownIds = shown.mapTo(HashSet()) { it.id }
    val globalShown = if (query.isBlank()) emptyList() else globalHits.filter { (kind == null || it.kind == kind) && it.id !in shownIds }
    if ((all.isEmpty() && query.isBlank()) || (shown.isEmpty() && kind != null && query.isBlank())) {
        val st = connectionText()
        val (img, asp, acc) = when (kind) {
            ChatKind.GROUP -> Triple(R.drawable.car_gtr_small, CAR_ASPECT, Green)
            ChatKind.CHANNEL -> Triple(R.drawable.car_gtr_small, CAR_ASPECT, VerifiedBlue)
            else -> Triple(R.drawable.car_gtr_small, CAR_ASPECT, Color(0xFFFF7AB8))
        }
        EmptyTab(
            title = when (kind) {
                ChatKind.GROUP -> tr("هنوز گروهی نداری", "No groups yet")
                ChatKind.CHANNEL -> tr("هنوز کانالی نداری", "No channels yet")
                else -> tr("هنوز چتی نیست", "No chats yet")
            },
            sub = st.ifEmpty { tr("بعد از همگام‌سازی، چت‌هایت اینجا می‌آیند.", "Your chats will appear here after syncing.") },
            tag = if (onCreate != null) tr("برای ساختن، دکمه‌ی + را بزن", "Tap + to create one") else "",
            img = img, aspect = asp, accent = acc, topPad = topPad,
        )
        return
    }
    LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(top = topPad, bottom = bottomPad)) {
        if (kind == null) {
            item(key = "stories") { StoriesBar { viewingStory = it } }
        }
        // The search bar sits right under the stories bar.
        if (kind == null && onQuery != null) {
            item(key = "searchBar") { ChatSearchBar(query, onQuery, searchFocus) }
        }
        if (kind == null) {
            item(key = "categories") { CategoryBar() }
            if (shown.isEmpty() && (query.isBlank() || (globalShown.isEmpty() && !globalBusy))) {
                item(key = "emptyCategory") {
                    Text(
                        if (query.isBlank()) tr("گفتگویی در این دسته نیست", "No chats in this category")
                        else tr("نتیجه‌ای پیدا نشد", "No results"),
                        color = c.subtext, fontSize = 14.sp,
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                    )
                }
            }
        }
        items(shown, key = { it.id }) { ch ->
            LiveChatRow(
                ch, onLongClick = { categoryFor = ch },
                onAvatar = onAvatar?.let { cb -> { cb(ch.id) } },
            ) { onOpen(ch.id) }
        }
        if (query.isNotBlank() && (globalShown.isNotEmpty() || globalBusy)) {
            item(key = "globalHeader") {
                Text(
                    if (globalBusy && globalShown.isEmpty()) tr("در حال جستجو در تلگرام…", "Searching Telegram…")
                    else tr("نتایج جستجوی جهانی", "Global search results"),
                    color = Green, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
            items(globalShown, key = { "g${it.id}" }) { ch ->
                LiveChatRow(ch, onAvatar = onAvatar?.let { cb -> { cb(ch.id) } }) { onOpen(ch.id) }
            }
        }
    }
    viewingStory?.let { id -> StoryViewer(id) { viewingStory = null } }
    categoryFor?.let { ch ->
        ChatCategoryDialog(
            ch,
            onDismiss = { categoryFor = null },
            onMoveToVault = { vaultFor = ch; categoryFor = null },
        )
    }
    vaultFor?.let { ch -> HideToVaultFlow(listOf(ch.id)) { vaultFor = null } }
}

/** Always-visible search field under the stories bar. */
@Composable
fun ChatSearchBar(query: String, onQuery: (String) -> Unit, focus: androidx.compose.ui.focus.FocusRequester) {
    val c = LocalMahan.current
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .height(46.dp)
            .clip(shape)
            .background(c.glassTint.copy(alpha = 0.5f))
            .androidxBorder(c.glassBorder, shape)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Search, null, tint = c.subtext, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        androidx.compose.foundation.text.BasicTextField(
            value = query,
            onValueChange = onQuery,
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(color = c.text, fontSize = 16.sp),
            cursorBrush = androidx.compose.ui.graphics.SolidColor(Green),
            modifier = Modifier.weight(1f).androidxFocus(focus),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (query.isEmpty()) Text(tr("جستجو", "Search"), color = c.subtext, fontSize = 16.sp)
                    inner()
                }
            },
        )
        if (query.isNotEmpty()) {
            Icon(
                Icons.Rounded.Close, null, tint = c.text,
                modifier = Modifier.size(28.dp).clip(CircleShape).clickable { onQuery("") }.padding(4.dp),
            )
        }
    }
}

private fun Modifier.androidxBorder(color: Color, shape: androidx.compose.ui.graphics.Shape): Modifier =
    this.then(Modifier.border(1.dp, color, shape))

private fun Modifier.androidxFocus(r: androidx.compose.ui.focus.FocusRequester): Modifier =
    this.then(Modifier.focusRequester(r))

@Composable
fun LiveContacts(
    topPad: Dp, bottomPad: Dp,
    onProfile: (Long) -> Unit = {},
    onInfo: (Long) -> Unit = {},
    onOpen: (Long) -> Unit,
) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var finding by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { runCatching { Td.loadContacts() } }
    val hiddenUsers = Td.hiddenUserIds
    val list = Td.contacts.filter { it.id !in hiddenUsers }
    if (list.isEmpty()) {
        EmptyTab(
            tr("مخاطبی نیست", "No contacts"),
            tr("مخاطبین تلگرامت اینجا نمایش داده می‌شوند.", "Your Telegram contacts will appear here."),
            "", R.drawable.car_gtr_small, CAR_ASPECT, Color(0xFFFF7AB8), topPad,
        )
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = topPad, bottom = bottomPad)) {
        item(key = "find-username") {
            Text(
                tr("🔎 جست‌وجوی نام کاربری", "🔎 Find by username"), color = Green, fontSize = 16.sp,
                modifier = Modifier.fillMaxWidth().clickable { finding = true }.padding(horizontal = 16.dp, vertical = 14.dp),
            )
        }
        items(list, key = { it.id }) { u ->
            Row(
                Modifier.fillMaxWidth()
                    .clickable { scope.launch { runCatching { Td.openPrivateChat(u.id) }.getOrNull()?.let(onOpen) } }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.clip(CircleShape).clickable { onProfile(u.id) }) { Avatar(u.photoFileId, u.name, 48.dp) }
                Spacer(Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(u.name, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        if (u.verified) {
                            Spacer(Modifier.width(4.dp))
                            Icon(Icons.Rounded.Verified, null, tint = VerifiedBlue, modifier = Modifier.size(16.dp))
                        }
                        if (u.premium) {
                            Spacer(Modifier.width(4.dp))
                            PremiumBadge(u.statusEmojiId)
                        }
                    }
                    Text(u.status, color = c.subtext, fontSize = 13.sp)
                }
            }
        }
    }
    if (finding) {
        var name by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { if (!busy) finding = false },
            title = { Text(tr("جست‌وجوی نام کاربری", "Find by username")) },
            text = { InputField(name, { name = it }, "@username", Modifier.fillMaxWidth()) },
            confirmButton = {
                TextButton(enabled = !busy && name.isNotBlank(), onClick = {
                    busy = true
                    scope.launch {
                        val id = try { Td.findPublic(name) } catch (e: TdException) { null }
                        busy = false
                        if (id == null) toast(ctx, tr("کاربر یا گفتگویی با این نام پیدا نشد", "Nothing found with this username"))
                        else { finding = false; onInfo(id) }
                    }
                }) { Text(tr("جست‌وجو", "Search")) }
            },
            dismissButton = { TextButton(onClick = { if (!busy) finding = false }) { Text(tr("لغو", "Cancel")) } },
        )
    }
}

@Composable
fun CreateChatDialog(channel: Boolean, onDismiss: () -> Unit, onCreated: (Long) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (channel) tr("ساخت کانال", "New channel") else tr("ساخت گروه", "New group")) },
        text = { InputField(title, { title = it }, tr("نام", "Name"), Modifier.fillMaxWidth()) },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank() && !busy,
                onClick = {
                    busy = true
                    scope.launch {
                        try {
                            onCreated(Td.createChat(title.trim(), channel))
                        } catch (e: Exception) {
                            toast(ctx, e.message ?: "error")
                            busy = false
                        }
                    }
                },
            ) { Text(tr("ساخت", "Create")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}
