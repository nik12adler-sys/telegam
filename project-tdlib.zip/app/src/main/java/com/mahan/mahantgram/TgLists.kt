package com.mahan.mahantgram

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun LiveChatRow(chat: UiChat, onClick: () -> Unit) {
    val c = LocalMahan.current
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(chat.photoFileId, chat.title, 54.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (chat.saved) tr("پیام‌های ذخیره‌شده", "Saved Messages") else chat.title,
                    color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
                )
                if (chat.verified) {
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Rounded.Verified, null, tint = VerifiedBlue, modifier = Modifier.size(16.dp))
                }
                if (chat.muted) Text(" 🔕", fontSize = 12.sp)
            }
            Text(chat.last, color = c.subtext, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(chat.time, color = c.subtext, fontSize = 12.sp)
            if (chat.unread > 0) {
                Box(
                    Modifier
                        .padding(top = 6.dp)
                        .defaultMinSize(minWidth = 22.dp)
                        .height(22.dp)
                        .background(if (chat.muted) c.subtext else Green, CircleShape)
                        .padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center,
                ) { Text(chat.unread.toString(), color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            } else if (chat.pinned) {
                Text("📌", fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

/** Real chat list. kind = null shows every chat, otherwise only groups or channels. */
@Composable
fun LiveChatList(
    kind: ChatKind?,
    query: String,
    topPad: Dp,
    bottomPad: Dp,
    onOpen: (Long) -> Unit,
    onCreate: (() -> Unit)?,
) {
    val c = LocalMahan.current
    var unreadOnly by remember { mutableStateOf(false) }
    val all = Td.chats
    val shown = all.filter { ch ->
        (kind == null || ch.kind == kind) &&
            (!unreadOnly || ch.unread > 0) &&
            (query.isBlank() || ch.title.contains(query, true) || ch.last.contains(query, true))
    }
    if (all.isEmpty() || (shown.isEmpty() && kind != null && query.isBlank())) {
        val st = connectionText()
        val (img, asp, acc) = when (kind) {
            ChatKind.GROUP -> Triple(R.drawable.car_gtr_small, CAR_ASPECT, Green)
            ChatKind.CHANNEL -> Triple(R.drawable.bike_bmw, BMW_ASPECT, VerifiedBlue)
            else -> Triple(R.drawable.bike_pink, PINK_ASPECT, Color(0xFFFF7AB8))
        }
        EmptyTab(
            title = when (kind) {
                ChatKind.GROUP -> tr("هنوز گروهی نداری", "No groups yet")
                ChatKind.CHANNEL -> tr("هنوز کانالی نداری", "No channels yet")
                else -> tr("هنوز چتی نیست", "No chats yet")
            },
            sub = st.ifEmpty { tr("بعد از همگام‌سازی، چت‌هایت اینجا می‌آیند.", "Your chats will appear here after syncing.") },
            tag = if (onCreate != null) tr("برای ساختن، دکمه‌ی + را بزن", "Tap + to create one") else "",
            img = img, aspect = asp, accent = acc, topPad = topPad,
        )
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = topPad, bottom = bottomPad)) {
        if (kind == null) {
            item {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Pill(tr("همه", "All"), !unreadOnly) { unreadOnly = false }
                    Pill(tr("خوانده‌نشده", "Unread"), unreadOnly) { unreadOnly = true }
                }
            }
        }
        items(shown, key = { it.id }) { ch -> LiveChatRow(ch) { onOpen(ch.id) } }
    }
}

@Composable
fun LiveContacts(topPad: Dp, bottomPad: Dp, onOpen: (Long) -> Unit) {
    val c = LocalMahan.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { runCatching { Td.loadContacts() } }
    val list = Td.contacts
    if (list.isEmpty()) {
        EmptyTab(
            tr("مخاطبی نیست", "No contacts"),
            tr("مخاطبین تلگرامت اینجا نمایش داده می‌شوند.", "Your Telegram contacts will appear here."),
            "", R.drawable.bike_pink, PINK_ASPECT, Color(0xFFFF7AB8), topPad,
        )
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = topPad, bottom = bottomPad)) {
        items(list, key = { it.id }) { u ->
            Row(
                Modifier.fillMaxWidth()
                    .clickable { scope.launch { runCatching { Td.openPrivateChat(u.id) }.getOrNull()?.let(onOpen) } }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Avatar(u.photoFileId, u.name, 48.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(u.name, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        if (u.verified) {
                            Spacer(Modifier.width(4.dp))
                            Icon(Icons.Rounded.Verified, null, tint = VerifiedBlue, modifier = Modifier.size(16.dp))
                        }
                    }
                    Text(u.status, color = c.subtext, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun CreateChatDialog(channel: Boolean, onDismiss: () -> Unit, onCreated: (Long) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (channel) tr("ساخت کانال", "New channel") else tr("ساخت گروه", "New group")) },
        text = { InputField(title, { title = it }, tr("نام", "Name"), Modifier.fillMaxWidth()) },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank() && !busy,
                onClick = {
                    busy = true
                    scope.launch {
                        try {
                            onCreated(Td.createChat(title.trim(), channel))
                        } catch (e: Exception) {
                            toast(ctx, e.message ?: "error")
                            busy = false
                        }
                    }
                },
            ) { Text(tr("ساخت", "Create")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}
