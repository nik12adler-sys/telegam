package com.mahan.mahantgram

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.TextUnit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/** One clickable piece of a message. target = url, "@username" or "tguser:<id>". */
class LinkSpan(val start: Int, val end: Int, val target: String)

object TgLinks {
    private val tme = Regex("^(?:https?://)?(?:www\\.)?(?:t|telegram)\\.me/([A-Za-z][A-Za-z0-9_]{3,31})(?:/\\d+)?/?(?:\\?.*)?$", RegexOption.IGNORE_CASE)
    private val mentionRe = Regex("(?<![A-Za-z0-9_/.])@([A-Za-z][A-Za-z0-9_]{3,31})")
    private val urlRe = Regex("(?i)(?<![A-Za-z0-9_@])((?:https?://|www\\.|t\\.me/|telegram\\.me/|tg://)[^\\s<>\"]+)")
    private const val TRAILING = ".,;:!?)]}»…"

    /** Links from TDLib's own entities, plus a text scan for anything TDLib did not mark (for example fresh outgoing messages). */
    fun spans(text: String, entities: List<UiEntity>): List<LinkSpan> {
        val out = ArrayList<LinkSpan>()
        for (e in entities) {
            val s = e.offset
            val en = minOf(e.offset + e.length, text.length)
            if (s < 0 || s >= en) continue
            when (e.type) {
                1, 2 -> out.add(LinkSpan(s, en, text.substring(s, en)))
                3 -> if (e.url.isNotBlank()) out.add(LinkSpan(s, en, e.url))
                4 -> out.add(LinkSpan(s, en, "tguser:${e.userId}"))
            }
        }
        fun overlaps(s: Int, e: Int) = out.any { s < it.end && e > it.start }
        for (m in urlRe.findAll(text)) {
            var v = m.groupValues[1]
            while (v.isNotEmpty() && v.last() in TRAILING) v = v.dropLast(1)
            val s = m.groups[1]!!.range.first
            val e = s + v.length
            if (v.isNotEmpty() && !overlaps(s, e)) out.add(LinkSpan(s, e, v))
        }
        for (m in mentionRe.findAll(text)) {
            val s = m.range.first
            val e = m.range.last + 1
            if (!overlaps(s, e)) out.add(LinkSpan(s, e, m.value))
        }
        out.sortBy { it.start }
        return out
    }

    /** Opens a link: Telegram usernames and t.me links open inside the app, everything else goes to the browser. */
    fun open(
        ctx: Context, scope: CoroutineScope, target: String,
        onOpenChat: (Long) -> Unit, onUser: (Long) -> Unit,
    ) {
        if (target.startsWith("tguser:")) {
            target.removePrefix("tguser:").toLongOrNull()?.let(onUser)
            return
        }
        var name: String? = null
        if (target.startsWith("@")) {
            name = target.removePrefix("@")
        } else if (target.startsWith("tg://resolve", true)) {
            name = runCatching { Uri.parse(target).getQueryParameter("domain") }.getOrNull()
        } else {
            tme.find(target.trim())?.let { name = it.groupValues[1] }
        }
        val n = name
        if (!n.isNullOrEmpty()) {
            scope.launch {
                val id = Td.chatByUsername(n)
                if (id == null) toast(ctx, tr("چنین کاربر یا گفتگویی پیدا نشد", "Nothing found with this username")) else onOpenChat(id)
            }
            return
        }
        val url = if (Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:").containsMatchIn(target)) target else "https://$target"
        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { toast(ctx, tr("لینک باز نشد", "Could not open the link")) }
    }
}

/** Message text whose links and @usernames can be tapped; a long press still goes to the message menu. */
@Composable
fun LinkedText(
    text: String,
    entities: List<UiEntity>,
    color: Color,
    fontSize: TextUnit,
    modifier: Modifier = Modifier,
    onLink: (String) -> Unit,
    onLongPress: () -> Unit,
) {
    val spans = remember(text, entities) { TgLinks.spans(text, entities) }
    val annotated = remember(text, spans) {
        buildAnnotatedString {
            append(text)
            for (sp in spans) addStyle(SpanStyle(color = VerifiedBlue, textDecoration = TextDecoration.Underline), sp.start, sp.end)
        }
    }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val link by rememberUpdatedState(onLink)
    val long by rememberUpdatedState(onLongPress)
    Text(
        annotated, color = color, fontSize = fontSize,
        onTextLayout = { layout = it },
        modifier = modifier.pointerInput(spans) {
            detectTapGestures(
                onLongPress = { long() },
                onTap = { pos ->
                    val l = layout ?: return@detectTapGestures
                    if (text.isEmpty()) return@detectTapGestures
                    val off = l.getOffsetForPosition(pos)
                    val hit = spans.firstOrNull { off >= it.start && off < it.end } ?: return@detectTapGestures
                    val box = l.getBoundingBox(off.coerceIn(0, text.length - 1))
                    if (pos.y >= box.top - 12f && pos.y <= box.bottom + 12f) link(hit.target)
                },
            )
        },
    )
}
