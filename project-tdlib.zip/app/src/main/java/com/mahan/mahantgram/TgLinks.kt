package com.mahan.mahantgram

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.TextUnit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/** One clickable piece of a message. target = url, "@username" or "tguser:<id>". */
class LinkSpan(val start: Int, val end: Int, val target: String, val label: String = "") {
    /** Text to put on the clipboard when the person copies this link. */
    val copyText: String get() = if (target.startsWith("tguser:")) label else target
}

object TgLinks {
    private val tme = Regex("^(?:https?://)?(?:www\\.)?(?:t|telegram)\\.me/([A-Za-z][A-Za-z0-9_]{3,31})(?:/\\d+)?/?(?:\\?.*)?$", RegexOption.IGNORE_CASE)
    private val mentionRe = Regex("(?<![A-Za-z0-9_/.])@([A-Za-z][A-Za-z0-9_]{3,31})")
    private val urlRe = Regex("(?i)(?<![A-Za-z0-9_@])((?:https?://|www\\.|t\\.me/|telegram\\.me/|tg://)[^\\s<>\"]+)")
    private const val TRAILING = ".,;:!?)]}»…"

    /** Links from TDLib's own entities, plus a text scan for anything TDLib did not mark (for example fresh outgoing messages). */
    fun spans(text: String, entities: List<UiEntity>): List<LinkSpan> {
        val out = ArrayList<LinkSpan>()
        for (e in entities) {
            val s = e.offset
            val en = minOf(e.offset + e.length, text.length)
            if (s < 0 || s >= en) continue
            when (e.type) {
                1, 2 -> out.add(LinkSpan(s, en, text.substring(s, en), text.substring(s, en)))
                3 -> if (e.url.isNotBlank()) out.add(LinkSpan(s, en, e.url, text.substring(s, en)))
                4 -> out.add(LinkSpan(s, en, "tguser:${e.userId}", text.substring(s, en)))
            }
        }
        fun overlaps(s: Int, e: Int) = out.any { s < it.end && e > it.start }
        for (m in urlRe.findAll(text)) {
            var v = m.groupValues[1]
            while (v.isNotEmpty() && v.last() in TRAILING) v = v.dropLast(1)
            val s = m.groups[1]!!.range.first
            val e = s + v.length
            if (v.isNotEmpty() && !overlaps(s, e)) out.add(LinkSpan(s, e, v, v))
        }
        for (m in mentionRe.findAll(text)) {
            val s = m.range.first
            val e = m.range.last + 1
            if (!overlaps(s, e)) out.add(LinkSpan(s, e, m.value, m.value))
        }
        out.sortBy { it.start }
        return out
    }

    /** Opens a link: Telegram usernames and t.me links open inside the app, everything else goes to the browser. */
    fun open(
        ctx: Context, scope: CoroutineScope, target: String,
        onOpenChat: (Long) -> Unit, onUser: (Long) -> Unit,
    ) {
        if (target.startsWith("tguser:")) {
            target.removePrefix("tguser:").toLongOrNull()?.let(onUser)
            return
        }
        var name: String? = null
        if (target.startsWith("@")) {
            name = target.removePrefix("@")
        } else if (target.startsWith("tg://resolve", true)) {
            name = runCatching { Uri.parse(target).getQueryParameter("domain") }.getOrNull()
        } else {
            tme.find(target.trim())?.let { name = it.groupValues[1] }
        }
        val n = name
        if (!n.isNullOrEmpty()) {
            scope.launch {
                val id = Td.chatByUsername(n)
                if (id == null) toast(ctx, tr("چنین کاربر یا گفتگویی پیدا نشد", "Nothing found with this username")) else onOpenChat(id)
            }
            return
        }
        val url = if (Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:").containsMatchIn(target)) target else "https://$target"
        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            .onFailure { toast(ctx, tr("لینک باز نشد", "Could not open the link")) }
    }
}

/** Message text whose links and @usernames can be tapped; a long press still goes to the message menu. */
@Composable
fun LinkedText(
    text: String,
    entities: List<UiEntity>,
    color: Color,
    fontSize: TextUnit,
    modifier: Modifier = Modifier,
    onLink: (String) -> Unit,
    onLongPress: (LinkSpan?) -> Unit,
) {
    val spans = remember(text, entities) { TgLinks.spans(text, entities) }
    // Custom emoji (Premium) are drawn inline; their placeholder text has the same length as the original emoji, so link offsets stay valid.
    val emojis = remember(text, entities) {
        entities.filter { it.type == 5 && it.length > 0 && it.offset >= 0 && it.offset + it.length <= text.length }.sortedBy { it.offset }
    }
    val annotated = remember(text, spans, emojis) {
        buildAnnotatedString {
            var pos = 0
            for (e in emojis) {
                if (e.offset < pos) continue
                append(text.substring(pos, e.offset))
                appendInlineContent("ce${e.userId}_${e.offset}", text.substring(e.offset, e.offset + e.length))
                pos = e.offset + e.length
            }
            append(text.substring(pos))
            for (sp in spans) addStyle(SpanStyle(color = VerifiedBlue, textDecoration = TextDecoration.Underline), sp.start, sp.end)
        }
    }
    val inline = remember(emojis, fontSize) {
        emojis.associate { e ->
            "ce${e.userId}_${e.offset}" to InlineTextContent(
                Placeholder(fontSize * 1.25f, fontSize * 1.25f, PlaceholderVerticalAlign.TextCenter),
            ) { CustomEmojiView(e.userId, Modifier.fillMaxSize()) }
        }
    }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val link by rememberUpdatedState(onLink)
    val long by rememberUpdatedState(onLongPress)
    Text(
        annotated, color = color, fontSize = fontSize,
        inlineContent = inline,
        onTextLayout = { layout = it },
        modifier = modifier.pointerInput(spans) {
            fun spanAt(pos: androidx.compose.ui.geometry.Offset): LinkSpan? {
                val l = layout ?: return null
                if (text.isEmpty()) return null
                val off = l.getOffsetForPosition(pos)
                val hit = spans.firstOrNull { off >= it.start && off < it.end } ?: return null
                val box = l.getBoundingBox(off.coerceIn(0, text.length - 1))
                return if (pos.y >= box.top - 12f && pos.y <= box.bottom + 12f) hit else null
            }
            detectTapGestures(
                onLongPress = { pos -> long(spanAt(pos)) },
                onTap = { pos -> spanAt(pos)?.let { link(it.target) } },
            )
        },
    )
}
