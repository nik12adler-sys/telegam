package com.mahan.mahantgram

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

// ====================================================================== Telegram Premium
// Everything comes from real TDLib calls (getPremiumState, getPremiumFeatures, applyPremiumGiftCode,
// chat boosts, recognizeSpeech). Premium itself is sold by Telegram, not by this app: the buy button
// opens the purchase link TDLib returns (@PremiumBot). Once Telegram activates it, UpdateUser flips
// isPremium and every feature below switches on by itself.

private val PremiumPurple = Color(0xFF8E6CFF)
private val PremiumPink = Color(0xFFFF6FB5)

private fun Any?.fo(name: String): Any? = this?.fieldOrNull(name)

class PremiumRequired : Exception("premium required")

class PremiumPlan(val months: Int, val price: String, val discount: Int, val current: Boolean)
class PremiumLimitRow(val key: String, val free: Int, val premium: Int)
class PremiumData(
    val intro: String, val features: List<String>, val limits: List<PremiumLimitRow>,
    val plans: List<PremiumPlan>, val buyUrl: String,
)

class BoostInfo(
    val level: Int, val boosts: Int, val currentLevelBoosts: Int, val nextLevelBoosts: Int,
    val premiumMembers: Int, val premiumPercent: Double, val url: String,
)

class BoostSlot(val id: Int, val chatId: Long, val cooldownUntil: Int, val expires: Int)

object Premium {
    const val MAX_UPLOAD_PREMIUM = 4_000_000_000L
    private const val FALLBACK_BUY = "https://t.me/PremiumBot"

    val active: Boolean get() = Td.me?.premium == true

    /** Upload limit of this account: 2 GB, or 4 GB with Premium. */
    fun maxUpload(): Long = if (active) MAX_UPLOAD_PREMIUM else MAX_UPLOAD_BYTES

    private fun money(currency: String, amount: Long): String {
        val digits = runCatching { java.util.Currency.getInstance(currency).defaultFractionDigits }.getOrDefault(2).coerceAtLeast(0)
        var div = 1.0
        repeat(digits) { div *= 10 }
        val v = amount / div
        return (if (digits == 0) "%.0f".format(v) else "%.2f".format(v)) + " " + currency
    }

    suspend fun load(): PremiumData? {
        val feats = runCatching {
            Td.req(mk<TdApi.Object>("GetPremiumFeatures", "source" to mk<TdApi.Object>("PremiumSourceSettings")))
        }.getOrNull()
        val state = runCatching { Td.req(mk<TdApi.Object>("GetPremiumState")) }.getOrNull()
        if (feats == null && state == null) return null
        val names = (feats.fo("features") as? Array<*>)
            ?.mapNotNull { it?.javaClass?.simpleName?.removePrefix("PremiumFeature") } ?: emptyList()
        val limits = (feats.fo("limits") as? Array<*>)?.mapNotNull { l ->
            val k = l.fo("type")?.javaClass?.simpleName?.removePrefix("PremiumLimitType") ?: return@mapNotNull null
            val d = (l.fo("defaultValue") as? Number)?.toInt() ?: return@mapNotNull null
            val p = (l.fo("premiumValue") as? Number)?.toInt() ?: return@mapNotNull null
            PremiumLimitRow(k, d, p)
        } ?: emptyList()
        val plans = (state.fo("paymentOptions") as? Array<*>)?.mapNotNull { o ->
            val po = o.fo("paymentOption") ?: return@mapNotNull null
            val cur = po.fo("currency") as? String ?: return@mapNotNull null
            val amount = (po.fo("amount") as? Number)?.toLong() ?: return@mapNotNull null
            PremiumPlan(
                months = (po.fo("monthCount") as? Number)?.toInt() ?: 0,
                price = money(cur, amount),
                discount = (po.fo("discountPercentage") as? Number)?.toInt() ?: 0,
                current = (o.fo("isCurrent") as? Boolean) == true,
            )
        } ?: emptyList()
        val intro = (state.fo("state") as? TdApi.FormattedText)?.text ?: ""
        val link = feats.fo("paymentLink")
        val url = if (link != null) runCatching {
            Td.req(mk<TdApi.Object>("GetInternalLink", "type" to link, "isHttp" to true)).fo("url") as? String
        }.getOrNull() else null
        return PremiumData(intro, names, limits, plans, url?.takeIf { it.isNotBlank() } ?: FALLBACK_BUY)
    }

    private fun codeOf(raw: String): String {
        val s = raw.trim()
        return if ("slug=" in s) s.substringAfter("slug=").substringBefore('&')
        else s.substringBefore('?').trimEnd('/').substringAfterLast('/')
    }

    /** Redeems a Premium gift code or t.me/giftcode link. Returns an error text, or null on success. */
    suspend fun redeem(raw: String): String? {
        val code = codeOf(raw)
        if (code.isEmpty()) return tr("کد خالی است", "The code is empty")
        val err = Td.tryReq(mk("ApplyPremiumGiftCode", "code" to code))
        if (err == null) runCatching { Td.loadMe() }
        return err
    }

    // ------------------------------------------------------------ boosts

    suspend fun boostStatus(chatId: Long): BoostInfo? {
        val s = runCatching { Td.req(mk<TdApi.Object>("GetChatBoostStatus", "chatId" to chatId)) }.getOrNull() ?: return null
        fun i(n: String) = (s.fo(n) as? Number)?.toInt() ?: 0
        return BoostInfo(
            level = i("level"), boosts = i("boostCount"),
            currentLevelBoosts = i("currentLevelBoostCount"), nextLevelBoosts = i("nextLevelBoostCount"),
            premiumMembers = i("premiumMemberCount"),
            premiumPercent = (s.fo("premiumMemberPercentage") as? Number)?.toDouble() ?: 0.0,
            url = (s.fo("boostUrl") as? String) ?: "",
        )
    }

    suspend fun slots(): List<BoostSlot> {
        val r = runCatching { Td.req(mk<TdApi.Object>("GetAvailableChatBoostSlots")) }.getOrNull() ?: return emptyList()
        return (r.fo("slots") as? Array<*>)?.mapNotNull { s ->
            val id = (s.fo("slotId") as? Number)?.toInt() ?: return@mapNotNull null
            BoostSlot(
                id = id,
                chatId = (s.fo("currentlyBoostedChatId") as? Number)?.toLong() ?: 0L,
                cooldownUntil = (s.fo("cooldownUntilDate") as? Number)?.toInt() ?: 0,
                expires = (s.fo("expirationDate") as? Number)?.toInt() ?: 0,
            )
        } ?: emptyList()
    }

    suspend fun boost(chatId: Long, slotIds: List<Int>): String? =
        Td.tryReq(mk("BoostChat", "chatId" to chatId, "slotIds" to slotIds.toIntArray()))

    // ------------------------------------------------------------ emoji status / animated photo

    private fun idsOf(r: Any?): List<Long> =
        (r.fo("customEmojiIds") as? LongArray)?.toList()
            ?: (r.fo("emojiStatuses") as? Array<*>)?.mapNotNull { (it.fo("customEmojiId") ?: it.fo("type").fo("customEmojiId")) as? Long }
            ?: emptyList()

    /** TDLib's suggested emoji statuses, with their artwork. */
    suspend fun statusChoices(): List<Pair<Long, StickerRef>> {
        var ids = idsOf(runCatching { Td.req(mk<TdApi.Object>("GetThemedEmojiStatuses")) }.getOrNull())
        if (ids.isEmpty()) ids = idsOf(runCatching { Td.req(mk<TdApi.Object>("GetDefaultEmojiStatuses")) }.getOrNull())
        if (ids.isEmpty()) return emptyList()
        return CustomEmoji.many(ids.take(48))
    }

    /** Sets (or with null removes) the emoji status. Returns an error text or null. */
    suspend fun setStatus(id: Long?): String? {
        if (id == null) return Td.tryReq(mk("SetEmojiStatus", "emojiStatus" to null))
        val st = runCatching {
            mk<TdApi.Object>("EmojiStatus", "type" to mk<TdApi.Object>("EmojiStatusTypeCustomEmoji", "customEmojiId" to id), "expirationDate" to 0)
        }.getOrNull() ?: mk<TdApi.Object>("EmojiStatus", "customEmojiId" to id)
        return Td.tryReq(mk("SetEmojiStatus", "emojiStatus" to st))
    }

    /** Sets a short video as the animated profile photo (Premium). */
    suspend fun setAnimatedPhoto(path: String): String? = Td.tryReq(
        mk(
            "SetProfilePhoto",
            "photo" to mk<TdApi.Object>("InputChatPhotoAnimation", "animation" to mk<TdApi.Object>("InputFileLocal", "path" to path), "mainFrameTimestamp" to 0.0),
            "isPublic" to false,
        ),
    )

    // ------------------------------------------------------------ voice to text

    /** Transcribes a voice note / video note. Throws PremiumRequired when Telegram asks for Premium. */
    suspend fun transcribe(chatId: Long, messageId: Long): String {
        try {
            Td.req(mk<TdApi.Object>("RecognizeSpeech", "chatId" to chatId, "messageId" to messageId))
        } catch (e: TdException) {
            if (e.message?.contains("premium", true) == true) throw PremiumRequired()
            throw e
        }
        repeat(30) {
            val msg = Td.req(mk<TdApi.Object>("GetMessage", "chatId" to chatId, "messageId" to messageId))
            val content = msg.fo("content")
            val note = content.fo("voiceNote") ?: content.fo("videoNote")
            val res = note.fo("speechRecognitionResult")
            when (res?.javaClass?.simpleName) {
                "SpeechRecognitionResultText" -> return (res.fo("text") as? String).orEmpty()
                "SpeechRecognitionResultError" -> {
                    val m = (res.fo("error").fo("message") as? String).orEmpty()
                    if (m.contains("premium", true)) throw PremiumRequired()
                    throw Exception(m.ifEmpty { "error" })
                }
            }
            delay(1500)
        }
        throw Exception("timeout")
    }
}

@Composable
fun PremiumStar(size: Dp = 16.dp) {
    Icon(Icons.Rounded.Star, null, tint = PremiumPurple, modifier = Modifier.size(size))
}

// ---------------------------------------------------------------------- texts

private class FMeta(val icon: String, val title: String, val desc: String, val inApp: Boolean)

private fun featureMeta(key: String): FMeta = when (key) {
    "IncreasedLimits" -> FMeta("⬆️", tr("حدهای بیشتر", "Doubled limits"), tr("کانال، سنجاق، لینک و … بیشتر؛ تلگرام اعمال می‌کند.", "More channels, pins, links and more, enforced by Telegram."), true)
    "IncreasedUploadFileSize" -> FMeta("📁", tr("آپلود تا ۴ گیگابایت", "Uploads up to 4 GB"), tr("ارسال فایل بزرگ‌تر از ۲ گیگابایت.", "Send files larger than 2 GB."), true)
    "ImprovedDownloadSpeed" -> FMeta("🚀", tr("دانلود سریع‌تر", "Faster downloads"), tr("سرعت دانلود را تلگرام بالا می‌برد.", "Telegram raises your download speed."), true)
    "VoiceToText" -> FMeta("🎙️", tr("تبدیل صدا به متن", "Voice to text"), tr("از منوی پیام صوتی یا ویدیوی گرد.", "From the menu of a voice or video message."), true)
    "DisabledAds" -> FMeta("🚫", tr("بدون تبلیغ", "No ads"), tr("تبلیغ کانال‌ها نمایش داده نمی‌شود.", "Sponsored messages are hidden."), true)
    "ProfileBadge" -> FMeta("⭐", tr("نشان پرمیوم", "Premium badge"), tr("ستاره کنار نام تو در لیست و پروفایل.", "A star next to your name in lists and profile."), true)
    "ChatBoost" -> FMeta("🚀", tr("بوست کانال‌ها", "Boost channels"), tr("از صفحه‌ی اطلاعات کانال یا سوپرگروه.", "From a channel's or supergroup's info page."), true)
    "UniqueReactions" -> FMeta("😍", tr("واکنش‌های ویژه", "Exclusive reactions"), "", false)
    "UniqueStickers" -> FMeta("🎭", tr("استیکرهای ویژه", "Premium stickers"), tr("از پنل استیکر ارسال می‌شوند (افکت تمام‌صفحه نه).", "Send them from the sticker panel (no full-screen effect)."), true)
    "CustomEmoji" -> FMeta("✨", tr("ایموجی سفارشی", "Custom emoji"), tr("در متن پیام‌ها دیده می‌شوند؛ ارسال‌شان هنوز نه.", "Shown inside messages; sending them is not supported yet."), true)
    "AdvancedChatManagement" -> FMeta("🗂️", tr("مدیریت پیشرفته‌ی گفتگوها", "Advanced chat management"), "", false)
    "EmojiStatus" -> FMeta("😎", tr("وضعیت ایموجی", "Emoji status"), tr("از همین صفحه انتخاب می‌شود و کنار نامت دیده می‌شود.", "Pick it on this page; it shows next to your name."), true)
    "AnimatedProfilePhoto" -> FMeta("🎞️", tr("عکس پروفایل متحرک", "Animated profile photo"), tr("از صفحه‌ی پروفایل، یک ویدیوی کوتاه انتخاب کن.", "From your profile page, pick a short video."), true)
    "RealTimeChatTranslation" -> FMeta("🌐", tr("ترجمه‌ی لحظه‌ای", "Real-time translation"), tr("دکمه‌ی 🌐 بالای گفتگو.", "The 🌐 button at the top of a chat."), true)
    "UpgradedStories" -> FMeta("📸", tr("استوری‌های ارتقایافته", "Upgraded stories"), "", false)
    else -> FMeta("⭐", key.replace(Regex("([a-z])([A-Z])"), "\$1 \$2"), "", false)
}

private fun limitTitle(key: String): String? = when (key) {
    "SupergroupCount" -> tr("کانال و گروه‌های عضو", "Joined channels and groups")
    "PinnedChatCount" -> tr("چت سنجاق‌شده", "Pinned chats")
    "CreatedPublicChatCount" -> tr("لینک عمومی", "Public links")
    "SavedAnimationCount" -> tr("گیف ذخیره‌شده", "Saved GIFs")
    "FavoriteStickerCount" -> tr("استیکر مورد علاقه", "Favorite stickers")
    "ChatFolderCount" -> tr("پوشه", "Folders")
    "ChatFolderChosenChatCount" -> tr("چت در هر پوشه", "Chats per folder")
    "PinnedArchivedChatCount" -> tr("سنجاق در آرشیو", "Pinned in archive")
    "CaptionLength" -> tr("طول کپشن", "Caption length")
    "BioLength" -> tr("طول بیو", "Bio length")
    else -> null
}

private fun planName(months: Int): String = when (months) {
    1 -> tr("۱ ماهه", "1 month")
    3 -> tr("۳ ماهه", "3 months")
    6 -> tr("۶ ماهه", "6 months")
    12 -> tr("۱ ساله", "1 year")
    24 -> tr("۲ ساله", "2 years")
    else -> trf("{0} ماهه", "{0} months", months)
}

// ---------------------------------------------------------------------- small UI

@Composable
private fun PSection(content: @Composable () -> Unit) {
    val c = LocalMahan.current
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(c.glassTint.copy(alpha = 0.35f)).border(1.dp, c.glassBorder, shape).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) { content() }
}

@Composable
private fun PWide(text: String, premium: Boolean = false, onClick: () -> Unit) {
    val c = LocalMahan.current
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier.fillMaxWidth().clip(shape)
            .then(if (premium) Modifier.background(Brush.horizontalGradient(listOf(PremiumPurple, PremiumPink))) else Modifier.background(c.glassTint.copy(alpha = 0.4f)))
            .clickable(onClick = onClick).padding(16.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = if (premium) Color.White else Green, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center) }
}

// ---------------------------------------------------------------------- Premium screen

@Composable
fun PremiumScreen(onBack: () -> Unit, onOpenChat: (Long) -> Unit, onUser: (Long) -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var data by remember { mutableStateOf<PremiumData?>(null) }
    var loaded by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val active = Premium.active
    LaunchedEffect(tick) { data = Premium.load(); loaded = true }
    val d = data
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BackButton(onBack)
            Text("Telegram Premium", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(PremiumPurple, PremiumPink))).padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(Icons.Rounded.Star, null, tint = Color.White, modifier = Modifier.size(56.dp))
            Text(
                if (active) tr("پرمیوم روی حساب تو فعال است", "Premium is active on your account") else tr("تلگرام پرمیوم", "Telegram Premium"),
                color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            )
            val intro = d?.intro.orEmpty()
            if (!active && intro.isNotEmpty()) Text(intro, color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp, textAlign = TextAlign.Center)
        }

        if (!loaded) Text(tr("در حال بارگذاری…", "Loading…"), color = c.subtext)
        if (loaded && d == null) {
            Text(tr("اطلاعات پرمیوم از تلگرام دریافت نشد.", "Could not load Premium information from Telegram."), color = c.subtext)
            PWide(tr("تلاش دوباره", "Retry")) { loaded = false; tick++ }
        }

        if (!active) {
            d?.plans?.takeIf { it.isNotEmpty() }?.let { plans ->
                PSection {
                    Text(tr("اشتراک‌ها", "Plans"), color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    plans.forEach { p ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(planName(p.months), color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                            if (p.discount > 0) {
                                Text("-${p.discount}%", color = PremiumPink, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(8.dp))
                            }
                            Text(p.price, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            if (d != null) PWide(tr("خرید پرمیوم", "Buy Premium"), premium = true) {
                TgLinks.open(ctx, scope, d.buyUrl, onOpenChat, onUser)
            }
            Text(
                tr(
                    "پرداخت را خود تلگرام (@PremiumBot) انجام می‌دهد. بعد از پرداخت، پرمیوم روی همین حساب فعال می‌شود و همه‌ی امکانات پایین خودکار روشن می‌شوند.",
                    "Telegram itself (@PremiumBot) handles the payment. After you pay, Premium turns on for this account and the features below switch on automatically.",
                ),
                color = c.subtext, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
            )
            PWide(tr("پرداخت کردم؛ بررسی وضعیت", "I paid, check status")) {
                scope.launch {
                    runCatching { Td.loadMe() }
                    tick++
                    toast(
                        ctx,
                        if (Td.me?.premium == true) tr("پرمیوم فعال شد 🎉", "Premium is active 🎉")
                        else tr("هنوز فعال نشده؛ کمی بعد دوباره بررسی کن.", "Not active yet; check again in a moment."),
                    )
                }
            }
        }

        PSection {
            Text(tr("کد هدیه‌ی پرمیوم", "Premium gift code"), color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            InputField(code, { code = it }, tr("کد یا لینک t.me/giftcode/…", "Code or t.me/giftcode/… link"), Modifier.fillMaxWidth(), ltr = true)
            PWide(if (busy) tr("در حال بررسی…", "Checking…") else tr("فعال‌سازی کد", "Redeem code")) {
                if (busy || code.isBlank()) return@PWide
                busy = true
                scope.launch {
                    val err = Premium.redeem(code)
                    busy = false
                    if (err != null) toast(ctx, err)
                    else { code = ""; toast(ctx, tr("کد اعمال شد 🎉", "Code applied 🎉")); tick++ }
                }
            }
        }

        if (active) {
            var choices by remember { mutableStateOf<List<Pair<Long, StickerRef>>>(emptyList()) }
            LaunchedEffect(Unit) { choices = Premium.statusChoices() }
            if (choices.isNotEmpty()) PSection {
                Text(tr("وضعیت ایموجی", "Emoji status"), color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                val cur = Td.me?.statusEmojiId ?: 0L
                choices.chunked(6).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { (id, ref) ->
                            Box(
                                Modifier.size(46.dp).clip(RoundedCornerShape(12.dp))
                                    .background(if (id == cur) PremiumPurple.copy(alpha = 0.35f) else Color.Transparent)
                                    .clickable {
                                        scope.launch { Premium.setStatus(id)?.let { toast(ctx, friendlyError(it)) } }
                                    },
                                contentAlignment = Alignment.Center,
                            ) { StickerImage(ref, Modifier.size(32.dp), animate = false) }
                        }
                    }
                }
                if (cur != 0L) PWide(tr("برداشتن وضعیت", "Remove status")) {
                    scope.launch { Premium.setStatus(null)?.let { toast(ctx, friendlyError(it)) } }
                }
            }
        }

        if (d != null && d.features.isNotEmpty()) {
            PSection {
                Text(tr("امکانات", "Features"), color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                d.features.forEach { key ->
                    val f = featureMeta(key)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(f.icon, fontSize = 22.sp)
                        Column(Modifier.weight(1f)) {
                            Text(f.title, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            if (f.desc.isNotEmpty()) Text(f.desc, color = c.subtext, fontSize = 12.sp)
                            Text(
                                if (f.inApp) tr("در این برنامه کار می‌کند", "Works in this app")
                                else tr("روی حساب فعال می‌شود؛ هنوز در این برنامه پشتیبانی نمی‌شود", "Enabled on your account; not supported in this app yet"),
                                color = if (f.inApp) Green else c.subtext, fontSize = 11.sp,
                            )
                        }
                    }
                }
            }
        }
        val lims = d?.limits?.mapNotNull { l -> limitTitle(l.key)?.let { it to l } } ?: emptyList()
        if (lims.isNotEmpty()) {
            PSection {
                Text(tr("حدها: رایگان ← پرمیوم", "Limits: free → Premium"), color = Green, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                lims.forEach { (title, l) ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(title, color = c.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        Text("${l.free} → ${l.premium}", color = c.subtext, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------------- Boost screen

@Composable
fun BoostScreen(chatId: Long, onBack: () -> Unit, onPremium: () -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var info by remember(chatId) { mutableStateOf<BoostInfo?>(null) }
    var slots by remember(chatId) { mutableStateOf<List<BoostSlot>>(emptyList()) }
    var loaded by remember(chatId) { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    val active = Premium.active
    val title = Td.chatById(chatId)?.title ?: ""
    LaunchedEffect(chatId, tick, active) {
        info = Premium.boostStatus(chatId)
        slots = if (active) Premium.slots() else emptyList()
        loaded = true
    }
    val now = (System.currentTimeMillis() / 1000).toInt()
    val mine = slots.count { it.chatId == chatId }
    val free = slots.firstOrNull { it.chatId == 0L }
    val movable = slots.firstOrNull { it.chatId != 0L && it.chatId != chatId && it.cooldownUntil <= now }
    val pick = free ?: movable
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BackButton(onBack)
            Text(tr("بوست", "Boosts") + if (title.isNotEmpty()) " · $title" else "", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        val i = info
        if (!loaded) Text(tr("در حال بارگذاری…", "Loading…"), color = c.subtext)
        else if (i == null) Text(tr("بوست برای این گفتگو در دسترس نیست.", "Boosts are not available for this chat."), color = c.subtext)
        else {
            PSection {
                Text(trf("سطح {0}", "Level {0}", i.level), color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(trf("{0} بوست", "{0} boosts", i.boosts), color = c.subtext, fontSize = 14.sp)
                val span = i.nextLevelBoosts - i.currentLevelBoosts
                if (i.nextLevelBoosts > 0 && span > 0) {
                    val frac = ((i.boosts - i.currentLevelBoosts).toFloat() / span).coerceIn(0f, 1f)
                    LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth(), color = PremiumPurple, trackColor = Color(0x22000000))
                    Text(trf("تا سطح بعد: {0} بوست", "To next level: {0} boosts", (i.nextLevelBoosts - i.boosts).coerceAtLeast(0)), color = c.subtext, fontSize = 12.sp)
                }
                if (i.premiumMembers > 0) Text(
                    trf("اعضای پرمیوم: {0} ({1}٪)", "Premium members: {0} ({1}%)", i.premiumMembers, "%.1f".format(i.premiumPercent)),
                    color = c.subtext, fontSize = 13.sp,
                )
            }
            if (!active) {
                PWide(tr("برای بوست، پرمیوم لازم است", "Premium is needed to boost"), premium = true) { onPremium() }
            } else {
                if (mine > 0) Text(trf("بوست‌های تو در این گفتگو: {0}", "Your boosts here: {0}", mine), color = Green, fontSize = 14.sp)
                if (pick != null) {
                    PWide(
                        if (busy) tr("در حال بوست…", "Boosting…") else tr("بوست این گفتگو 🚀", "Boost this chat 🚀"),
                        premium = true,
                    ) {
                        if (busy) return@PWide
                        busy = true
                        scope.launch {
                            val err = Premium.boost(chatId, listOf(pick.id))
                            busy = false
                            if (err != null) toast(ctx, friendlyError(err)) else { toast(ctx, tr("بوست شد 🎉", "Boosted 🎉")); tick++ }
                        }
                    }
                    if (free == null) Text(tr("این بوست از گفتگوی دیگری منتقل می‌شود.", "This boost is moved from another chat."), color = c.subtext, fontSize = 12.sp)
                } else {
                    val next = slots.filter { it.chatId != chatId }.minOfOrNull { it.cooldownUntil } ?: 0
                    Text(
                        if (slots.isEmpty()) tr("اسلات بوستی برای حساب تو در دسترس نیست.", "No boost slots are available for your account.")
                        else if (next > now) trf("بوست بعدی از {0} ممکن است.", "Your next boost is possible from {0}.", Td.fmtTime(next))
                        else tr("همه‌ی بوست‌های تو روی همین گفتگو هستند.", "All your boosts are on this chat."),
                        color = c.subtext, fontSize = 13.sp,
                    )
                }
            }
            if (i.url.isNotEmpty()) PWide(tr("کپی لینک بوست", "Copy boost link")) {
                (ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                    .setPrimaryClip(android.content.ClipData.newPlainText("boost", i.url))
                toast(ctx, tr("کپی شد", "Copied"))
            }
        }
    }
}
