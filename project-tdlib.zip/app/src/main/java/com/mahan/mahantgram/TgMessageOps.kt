package com.mahan.mahantgram

import org.drinkless.tdlib.TdApi

// ====================================================================== step 5: message operations
// Everything here asks TDLib what is really allowed (getMessageProperties, chat/group rights,
// available reactions) instead of guessing. TDLib fields are read by name so a renamed field in
// another TDLib version cannot break the build.

private fun Any?.fo(name: String): Any? = this?.fieldOrNull(name)
private fun Any?.bo(name: String): Boolean? = this.fo(name) as? Boolean
private fun Any?.so(name: String): String = (this.fo(name) as? String) ?: ""

/** What the current user may do with one message. null in TDLib's answer falls back to our own rules. */
data class MsgCaps(
    val canReply: Boolean,
    val canEdit: Boolean,
    val canForward: Boolean,
    val canCopy: Boolean,
    val canPin: Boolean,
    val canDeleteSelf: Boolean,
    val canDeleteAll: Boolean,
    val canReport: Boolean,
    val canSeeReactors: Boolean,
)

class ReportOpt(val id: ByteArray, val text: String)

/** One step of Telegram's report dialog. */
sealed class ReportStep {
    object Done : ReportStep()
    class Options(val title: String, val options: List<ReportOpt>) : ReportStep()
    class Text(val optionId: ByteArray, val optional: Boolean) : ReportStep()
    class Failed(val message: String) : ReportStep()
}

class Reactor(val name: String, val emoji: String, val date: Int, val mine: Boolean)

object MsgOps {
    private const val EDIT_WINDOW_SECONDS = 48 * 3600

    private val pinCache = java.util.concurrent.ConcurrentHashMap<Long, Boolean>()

    // ---------------------------------------------------------------- permissions

    /** Local rules used while TDLib has not answered yet, or when it does not report a field. */
    fun guess(m: UiMessage): MsgCaps {
        val chat = Td.rawChat(m.chatId)
        val sent = m.id > 0 && !m.sending && !m.failed
        val age = (System.currentTimeMillis() / 1000).toInt() - m.date
        val editableKind = m.kind == MsgKind.TEXT || m.kind == MsgKind.PHOTO || m.kind == MsgKind.VIDEO ||
            m.kind == MsgKind.DOC || m.kind == MsgKind.AUDIO || m.kind == MsgKind.ANIMATION
        val protectedChat = chat.bo("hasProtectedContent") == true
        return MsgCaps(
            canReply = sent,
            canEdit = sent && m.outgoing && editableKind && age < EDIT_WINDOW_SECONDS,
            canForward = sent && !protectedChat,
            canCopy = m.text.isNotEmpty() && !protectedChat,
            canPin = sent && (pinCache[m.chatId] ?: false),
            canDeleteSelf = sent,
            canDeleteAll = sent && m.outgoing,
            canReport = sent && !m.outgoing,
            canSeeReactors = m.reactions.isNotEmpty(),
        )
    }

    /** Asks TDLib for the real properties of the message and merges them over our own rules. */
    suspend fun caps(m: UiMessage): MsgCaps {
        val base = guess(m)
        if (m.id <= 0 || m.sending || m.failed) return base
        val pin = canPinInChat(m.chatId)
        val p = try {
            Td.req(mk<TdApi.Object>("GetMessageProperties", "chatId" to m.chatId, "messageId" to m.id))
        } catch (e: Throwable) {
            return base.copy(canPin = pin)
        }
        return MsgCaps(
            canReply = p.bo("canBeReplied") ?: base.canReply,
            canEdit = p.bo("canBeEdited") ?: base.canEdit,
            canForward = p.bo("canBeForwarded") ?: base.canForward,
            canCopy = (p.bo("canBeSaved") ?: base.canCopy) && m.text.isNotEmpty(),
            canPin = p.bo("canBePinned") ?: pin,
            canDeleteSelf = p.bo("canBeDeletedOnlyForSelf") ?: base.canDeleteSelf,
            canDeleteAll = p.bo("canBeDeletedForAllUsers") ?: base.canDeleteAll,
            canReport = (p.bo("canReportChat") ?: base.canReport) && !m.outgoing,
            canSeeReactors = m.reactions.isNotEmpty(),
        )
    }

    /** Pin rights of this user in a chat, computed from the real chat type and member status. */
    suspend fun canPinInChat(chatId: Long): Boolean {
        pinCache[chatId]?.let { return it }
        val chat = Td.rawChat(chatId) ?: return false
        val perms = chat.permissions
        fun adminCan(status: Any?, channel: Boolean): Boolean {
            val rights = status.fo("rights") ?: status
            return if (channel) (rights.bo("canEditMessages") == true || rights.bo("canPinMessages") == true)
            else rights.bo("canPinMessages") == true
        }
        val ok = try {
            when (val t = chat.type) {
                is TdApi.ChatTypePrivate, is TdApi.ChatTypeSecret -> true
                is TdApi.ChatTypeBasicGroup -> {
                    val st = Td.req(mk<TdApi.Object>("GetBasicGroup", "basicGroupId" to t.basicGroupId)).fo("status")
                    when (st) {
                        is TdApi.ChatMemberStatusCreator -> true
                        is TdApi.ChatMemberStatusAdministrator -> adminCan(st, false)
                        is TdApi.ChatMemberStatusMember -> perms.bo("canPinMessages") == true
                        else -> false
                    }
                }
                is TdApi.ChatTypeSupergroup -> {
                    val st = Td.req(mk<TdApi.Object>("GetSupergroup", "supergroupId" to t.supergroupId)).fo("status")
                    when (st) {
                        is TdApi.ChatMemberStatusCreator -> true
                        is TdApi.ChatMemberStatusAdministrator -> adminCan(st, t.isChannel)
                        is TdApi.ChatMemberStatusMember -> !t.isChannel && perms.bo("canPinMessages") == true
                        is TdApi.ChatMemberStatusRestricted -> st.fo("permissions").bo("canPinMessages") == true
                        else -> false
                    }
                }
                else -> false
            }
        } catch (e: Throwable) {
            false
        }
        pinCache[chatId] = ok
        return ok
    }

    /** Called when a group's rights or the user's status in it may have changed. */
    fun clearPinRights() { pinCache.clear() }

    fun isPrivate(chatId: Long): Boolean = Td.rawChat(chatId)?.type.let { it is TdApi.ChatTypePrivate || it is TdApi.ChatTypeSecret }

    // ---------------------------------------------------------------- pin

    suspend fun pin(chatId: Long, id: Long, onlyForSelf: Boolean): String? = Td.tryReq(
        mk("PinChatMessage", "chatId" to chatId, "messageId" to id, "disableNotification" to true, "onlyForSelf" to onlyForSelf),
    )

    suspend fun unpin(chatId: Long, id: Long): String? = Td.tryReq(mk("UnpinChatMessage", "chatId" to chatId, "messageId" to id))

    // ---------------------------------------------------------------- edit

    /** Edits text, or the caption when the message is a media message. */
    suspend fun edit(m: UiMessage, newText: String): String? =
        if (m.kind == MsgKind.TEXT) Td.editText(m.chatId, m.id, newText)
        else Td.tryReq(mk("EditMessageCaption", "chatId" to m.chatId, "messageId" to m.id, "caption" to ft(newText)))

    // ---------------------------------------------------------------- forward

    /** Forwards one message to several chats. Returns the number of chats that failed and the first error. */
    suspend fun forwardTo(targets: List<Long>, fromChat: Long, id: Long, asCopy: Boolean): Pair<Int, String?> {
        var failed = 0
        var first: String? = null
        for (t in targets) {
            val err = Td.tryReq(
                mk(
                    "ForwardMessages", "chatId" to t, "fromChatId" to fromChat, "messageIds" to longArrayOf(id),
                    "sendCopy" to asCopy, "removeCaption" to false,
                ),
            )
            if (err != null) { failed++; if (first == null) first = err }
        }
        return failed to first
    }

    // ---------------------------------------------------------------- translate

    /** Translates a message text into the app language with Telegram's own translator. */
    suspend fun translate(text: String): Result<String> = try {
        val r = Td.req(mk("TranslateText", "text" to ft(text), "toLanguageCode" to Td.lang))
        val out = (r as? TdApi.FormattedText)?.text ?: r.so("text")
        if (out.isBlank()) Result.failure(Exception("empty")) else Result.success(out)
    } catch (e: Throwable) {
        Result.failure(e)
    }

    // ---------------------------------------------------------------- report

    private fun reportable(m: UiMessage) = m.id > 0 && !m.sending && !m.failed

    /** Starts (or continues, with an option id and text) Telegram's report dialog for one message. */
    suspend fun report(m: UiMessage, optionId: ByteArray = ByteArray(0), text: String = ""): ReportStep {
        if (!reportable(m)) return ReportStep.Failed(tr("این پیام قابل گزارش نیست", "This message can't be reported"))
        return try {
            val r = Td.req(
                mk<TdApi.Object>(
                    "ReportChat", "chatId" to m.chatId, "optionId" to optionId,
                    "messageIds" to longArrayOf(m.id), "text" to text,
                ),
            )
            when (r.javaClass.simpleName) {
                "ReportChatResultOk" -> ReportStep.Done
                "ReportChatResultOptionRequired" -> {
                    val opts = (r.fo("options") as? Array<*>)?.mapNotNull { o ->
                        val id = o.fo("id") as? ByteArray ?: return@mapNotNull null
                        ReportOpt(id, o.so("text"))
                    } ?: emptyList()
                    if (opts.isEmpty()) ReportStep.Failed(tr("گزینه‌ای برای گزارش در دسترس نیست", "No report options available"))
                    else ReportStep.Options(r.so("title"), opts)
                }
                "ReportChatResultTextRequired" ->
                    ReportStep.Text((r.fo("optionId") as? ByteArray) ?: optionId, r.bo("isOptional") ?: true)
                "ReportChatResultMessagesRequired" -> ReportStep.Failed(tr("پیام برای گزارش لازم است", "A message is required"))
                else -> ReportStep.Done
            }
        } catch (e: TdException) {
            ReportStep.Failed(friendlyError(e.message ?: "error"))
        } catch (e: Throwable) {
            // Older TDLib that still wants a fixed reason instead of an option id.
            reportOldStyle(m)
        }
    }

    private suspend fun reportOldStyle(m: UiMessage): ReportStep = try {
        Td.req(
            mk<TdApi.Object>(
                "ReportChat", "chatId" to m.chatId, "messageIds" to longArrayOf(m.id),
                "reason" to mk<TdApi.Object>("ReportReasonSpam"), "text" to "",
            ),
        )
        ReportStep.Done
    } catch (e: Throwable) {
        ReportStep.Failed(friendlyError(e.message ?: "error"))
    }

    // ---------------------------------------------------------------- reactions

    /** Emoji reactions this chat allows on this message (top first, then recent and popular). Empty = reactions are off. */
    suspend fun availableReactions(m: UiMessage): List<String> {
        if (m.id <= 0 || m.sending || m.failed) return emptyList()
        return try {
            val r = Td.req(mk<TdApi.Object>("GetMessageAvailableReactions", "chatId" to m.chatId, "messageId" to m.id, "rowSize" to 8))
            val out = LinkedHashSet<String>()
            for (key in listOf("topReactions", "recentReactions", "popularReactions")) {
                (r.fo(key) as? Array<*>)?.forEach { a ->
                    val e = (a.fo("type") as? TdApi.ReactionTypeEmoji)?.emoji
                    if (e != null) out.add(e)
                }
            }
            out.toList()
        } catch (e: Throwable) {
            emptyList()
        }
    }

    /** Sets, changes or removes the user's own reaction. Choosing the emoji already chosen removes it. */
    suspend fun react(m: UiMessage, emoji: String): String? {
        val chosen = m.reactions.any { it.emoji == emoji && it.chosen }
        return Td.react(m.chatId, m.id, emoji, chosen)
    }

    /** Who reacted with what (TDLib getMessageAddedReactions). null = Telegram does not allow it here. */
    suspend fun reactors(m: UiMessage, emoji: String? = null): List<Reactor>? {
        return try {
            val fields = mutableListOf<Pair<String, Any?>>("chatId" to m.chatId, "messageId" to m.id, "offset" to "", "limit" to 100)
            if (emoji != null) fields.add("reactionType" to mk<TdApi.Object>("ReactionTypeEmoji", "emoji" to emoji))
            val r = Td.req(mk<TdApi.Object>("GetMessageAddedReactions", *fields.toTypedArray()))
            (r.fo("reactions") as? Array<*>)?.mapNotNull { a ->
                val e = (a.fo("type") as? TdApi.ReactionTypeEmoji)?.emoji ?: return@mapNotNull null
                val name = when (val s = a.fo("senderId")) {
                    is TdApi.MessageSenderUser -> runCatching { Td.loadUser(s.userId) }.getOrNull()
                        ?.let { "${it.firstName} ${it.lastName}".trim() } ?: s.userId.toString()
                    is TdApi.MessageSenderChat -> Td.rawChat(s.chatId)?.title ?: s.chatId.toString()
                    else -> ""
                }
                Reactor(name, e, (a.fo("date") as? Number)?.toInt() ?: 0, a.bo("isOutgoing") == true)
            } ?: emptyList()
        } catch (e: Throwable) {
            null
        }
    }
}
