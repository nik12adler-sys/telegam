package com.mahan.mahantgram;

import org.drinkless.tdlib.Client;
import org.drinkless.tdlib.TdApi;

/** Thin Java layer so the Kotlin code does not depend on TdApi.Function generics. */
public final class TdBridge {
    private TdBridge() {}

    public interface Handler {
        void onResult(TdApi.Object obj);
    }

    public static Client create(final Handler updates) {
        return Client.create(new Client.ResultHandler() {
            @Override
            public void onResult(TdApi.Object object) {
                updates.onResult(object);
            }
        }, null, null);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public static void send(Client client, TdApi.Object function, final Handler handler) {
        client.send((TdApi.Function) function, new Client.ResultHandler() {
            @Override
            public void onResult(TdApi.Object object) {
                if (handler != null) handler.onResult(object);
            }
        });
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public static TdApi.Object execute(TdApi.Object function) {
        return Client.execute((TdApi.Function) function);
    }
}
