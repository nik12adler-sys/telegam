package com.mahan.mahantgram

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec

/**
 * AjiMaji: the private, password protected space.
 *
 * Everything persistent lives in ONE blob that is encrypted with an AES-256-GCM key kept in the
 * Android Keystore: password hash + salt, hidden chat ids (real TDLib chat ids), hide time,
 * the categories a chat belonged to, security settings and the failed-attempt counter.
 * The password itself is never stored; only PBKDF2-HMAC-SHA256 (random salt) of it.
 *
 * Hiding is UI-only: nothing is ever deleted or archived in the real Telegram account.
 */
object Vault {
    enum class Result { OK, WRONG, LOCKED_OUT, ERROR }

    data class Hidden(val id: Long, val at: Long, val cats: List<String>)

    data class Settings(
        /** Seconds the app may stay in the background before locking. 0 = at once, -1 = never (manual / screen off only). */
        val lockDelaySec: Int = 0,
        val lockOnScreenOff: Boolean = true,
        /** FLAG_SECURE: blocks screenshots and blanks the recent-apps preview while AjiMaji is open. */
        val secureScreen: Boolean = true,
    )

    const val MIN_LEN = 6
    private const val PREFS = "ajimaji_vault"
    private const val KEY_BLOB = "blob"
    private const val KEY_ALIAS = "ajimaji_vault_key_v1"
    private const val AAD = "ajimaji.v1"
    private const val ITER = 150_000
    private const val FREE_ATTEMPTS = 5
    private const val MAX_LOCKOUT_MS = 30 * 60_000L
    private const val EXTERNAL_GRACE_MS = 180_000L

    private val COMMON = setOf(
        "123456", "1234567", "12345678", "123456789", "654321", "111111", "000000", "123123",
        "password", "qwerty", "qwerty123", "abcdef", "abc123", "147258", "123321", "iloveyou",
    )

    private var prefs: SharedPreferences? = null
    private val mutex = Mutex()
    private val rnd = SecureRandom()

    private var salt = ByteArray(0)
    private var hash = ByteArray(0)
    private var iter = ITER
    private var fails = 0
    private val hiddenInfo = LinkedHashMap<Long, Hidden>()

    var configured by mutableStateOf(false)
        private set
    var unlocked by mutableStateOf(false)
        private set
    /** The stored blob exists but cannot be decrypted (Keystore key lost). */
    var corrupt by mutableStateOf(false)
        private set
    var hiddenIds by mutableStateOf<Set<Long>>(emptySet())
        private set
    var settings by mutableStateOf(Settings())
        private set
    /** Wall-clock time until which password attempts are refused (0 = no lockout). */
    var lockUntil by mutableStateOf(0L)
        private set

    // ------------------------------------------------------------ init / storage

    fun init(context: Context) {
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        val raw = p.getString(KEY_BLOB, null) ?: return
        val bytes = decrypt(raw)
        if (bytes == null) {
            corrupt = true
            return
        }
        runCatching {
            val o = JSONObject(String(bytes, Charsets.UTF_8))
            salt = Base64.decode(o.getString("salt"), Base64.NO_WRAP)
            hash = Base64.decode(o.getString("hash"), Base64.NO_WRAP)
            iter = o.optInt("iter", ITER)
            fails = o.optInt("fails", 0)
            val now = System.currentTimeMillis()
            // A clock moved backwards must not extend the lockout beyond its maximum.
            lockUntil = o.optLong("lockUntil", 0L).let { if (it - now > MAX_LOCKOUT_MS) now + MAX_LOCKOUT_MS else it }
            val arr = o.optJSONArray("hidden") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val h = arr.getJSONObject(i)
                val cats = ArrayList<String>()
                h.optJSONArray("cats")?.let { a -> for (j in 0 until a.length()) cats.add(a.getString(j)) }
                hiddenInfo[h.getLong("id")] = Hidden(h.getLong("id"), h.optLong("at", 0L), cats)
            }
            settings = Settings(
                lockDelaySec = o.optInt("lockDelay", 0),
                lockOnScreenOff = o.optBoolean("screenOff", true),
                secureScreen = o.optBoolean("secure", true),
            )
            hiddenIds = hiddenInfo.keys.toSet()
            configured = salt.isNotEmpty() && hash.isNotEmpty()
        }.onFailure { corrupt = true }
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return kg.generateKey()
    }

    private fun encrypt(plain: ByteArray): String? = runCatching {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        c.updateAAD(AAD.toByteArray(Charsets.UTF_8))
        val ct = c.doFinal(plain)
        Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
    }.getOrNull()

    private fun decrypt(s: String): ByteArray? = runCatching {
        val all = Base64.decode(s, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
        c.updateAAD(AAD.toByteArray(Charsets.UTF_8))
        c.doFinal(all, 12, all.size - 12)
    }.getOrNull()

    private fun persist(): Boolean {
        val p = prefs ?: return false
        val o = JSONObject()
        o.put("v", 1)
        o.put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
        o.put("hash", Base64.encodeToString(hash, Base64.NO_WRAP))
        o.put("iter", iter)
        o.put("fails", fails)
        o.put("lockUntil", lockUntil)
        val arr = JSONArray()
        for (h in hiddenInfo.values) {
            arr.put(JSONObject().put("id", h.id).put("at", h.at).put("cats", JSONArray(h.cats)))
        }
        o.put("hidden", arr)
        o.put("lockDelay", settings.lockDelaySec)
        o.put("screenOff", settings.lockOnScreenOff)
        o.put("secure", settings.secureScreen)
        val enc = encrypt(o.toString().toByteArray(Charsets.UTF_8)) ?: return false
        return p.edit().putString(KEY_BLOB, enc).commit()
    }

    // ------------------------------------------------------------ password

    fun passwordIssue(pw: String): String? {
        if (pw.length < MIN_LEN) return tr("رمز باید دست‌کم ۶ نویسه باشد", "Use at least 6 characters")
        if (pw.toSet().size < 3 || pw.lowercase() in COMMON) {
            return tr("این رمز خیلی ساده است", "That password is too easy to guess")
        }
        return null
    }

    private fun pbkdf2(pw: CharArray, salt: ByteArray, iterations: Int): ByteArray {
        val spec = PBEKeySpec(pw, salt, iterations, 256)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    private suspend fun derive(password: String, s: ByteArray, iterations: Int): ByteArray {
        val chars = password.toCharArray()
        return withContext(Dispatchers.Default) {
            try {
                pbkdf2(chars, s, iterations)
            } finally {
                chars.fill('\u0000')
            }
        }
    }

    /** Creates the password. unlockAfter = false is for "hide this chat" flows that start from the public list. */
    suspend fun setup(password: String, unlockAfter: Boolean = true): Boolean = mutex.withLock {
        if (configured || passwordIssue(password) != null) return@withLock false
        val s = ByteArray(16).also { rnd.nextBytes(it) }
        val h = derive(password, s, ITER)
        salt = s; hash = h; iter = ITER; fails = 0; lockUntil = 0L
        if (!persist()) {
            salt = ByteArray(0); hash = ByteArray(0)
            return@withLock false
        }
        configured = true
        corrupt = false
        unlocked = unlockAfter
        true
    }

    /** Checks a password with brute-force protection: 5 free tries, then 30 s, 1 min, 2 min ... up to 30 min. */
    private suspend fun check(password: String): Result = mutex.withLock {
        if (!configured) return@withLock Result.ERROR
        val now = System.currentTimeMillis()
        if (lockUntil > now) return@withLock Result.LOCKED_OUT
        val got = derive(password, salt, iter)
        val ok = MessageDigest.isEqual(got, hash)
        got.fill(0)
        if (ok) {
            if (fails != 0 || lockUntil != 0L) {
                fails = 0; lockUntil = 0L
                persist()
            }
            return@withLock Result.OK
        }
        fails++
        if (fails >= FREE_ATTEMPTS) {
            val step = (fails - FREE_ATTEMPTS).coerceAtMost(6)
            lockUntil = System.currentTimeMillis() + (30_000L shl step).coerceAtMost(MAX_LOCKOUT_MS)
        }
        persist()
        Result.WRONG
    }

    suspend fun unlock(password: String): Result {
        val r = check(password)
        if (r == Result.OK) unlocked = true
        return r
    }

    /** Verifies the password without opening the space (used before hiding a chat from the public list). */
    suspend fun verify(password: String): Result = check(password)

    suspend fun changePassword(old: String, new: String): Result {
        if (passwordIssue(new) != null) return Result.ERROR
        val r = check(old)
        if (r != Result.OK) return r
        return mutex.withLock {
            val oldSalt = salt; val oldHash = hash; val oldIter = iter
            val s = ByteArray(16).also { rnd.nextBytes(it) }
            val h = derive(new, s, ITER)
            salt = s; hash = h; iter = ITER
            if (persist()) Result.OK else {
                salt = oldSalt; hash = oldHash; iter = oldIter
                Result.ERROR
            }
        }
    }

    // ------------------------------------------------------------ lock

    fun lock() {
        if (!unlocked) return
        unlocked = false
        // Nothing from the private space may keep playing or stay cached once it is locked.
        AudioPlayer.stop()
        BitmapCache.clear()
    }

    fun updateSettings(s: Settings) {
        settings = s
        persist()
    }

    // ------------------------------------------------------------ hidden chats

    fun isHidden(chatId: Long): Boolean = chatId in hiddenIds

    /** Moves chats into AjiMaji. Their custom-category memberships are saved here and removed from the public store. */
    fun hide(ids: Collection<Long>): Boolean {
        if (!configured || ids.isEmpty()) return false
        val now = System.currentTimeMillis()
        val added = ArrayList<Long>()
        for (id in ids) {
            if (hiddenInfo.containsKey(id)) continue
            hiddenInfo[id] = Hidden(id, now, CategoryStore.membership(id))
            added.add(id)
        }
        if (added.isEmpty()) return true
        if (!persist()) {
            added.forEach { hiddenInfo.remove(it) }
            return false
        }
        added.forEach { CategoryStore.detachChat(it) }
        hiddenIds = hiddenInfo.keys.toSet()
        Td.onHiddenChanged()
        return true
    }

    /** Returns chats to the public list and restores their earlier categories. */
    fun restore(ids: Collection<Long>): Boolean {
        val gone = ids.mapNotNull { hiddenInfo[it] }
        if (gone.isEmpty()) return true
        gone.forEach { hiddenInfo.remove(it.id) }
        if (!persist()) {
            gone.forEach { hiddenInfo[it.id] = it }
            return false
        }
        gone.forEach { CategoryStore.attachChat(it.id, it.cats) }
        hiddenIds = hiddenInfo.keys.toSet()
        Td.onHiddenChanged()
        return true
    }

    /** Forgets everything (used when the Telegram account is logged out, or to reset a damaged vault). */
    fun wipe() {
        hiddenInfo.values.forEach { CategoryStore.attachChat(it.id, it.cats) }
        hiddenInfo.clear()
        salt = ByteArray(0); hash = ByteArray(0); fails = 0
        prefs?.edit()?.remove(KEY_BLOB)?.commit()
        runCatching { KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry(KEY_ALIAS) }
        configured = false; unlocked = false; corrupt = false
        lockUntil = 0L
        settings = Settings()
        hiddenIds = emptySet()
        Td.onHiddenChanged()
    }

    // ------------------------------------------------------------ app lifecycle (auto-lock)

    private var leftAt = 0L
    private var leftExternal = false
    private var externalUntil = 0L

    /** Called when the app opens a picker / another app: leaving then is not "exiting" the app. */
    fun noteExternalLaunch() {
        externalUntil = SystemClock.elapsedRealtime() + EXTERNAL_GRACE_MS
    }

    fun onAppStop(changingConfig: Boolean) {
        if (changingConfig) return
        val now = SystemClock.elapsedRealtime()
        leftAt = now
        leftExternal = now < externalUntil
        if (unlocked && settings.lockDelaySec == 0 && !leftExternal) lock()
    }

    fun onAppStart() {
        val away = if (leftAt == 0L) 0L else SystemClock.elapsedRealtime() - leftAt
        val d = settings.lockDelaySec
        if (unlocked && leftAt != 0L && d >= 0) {
            val limit = if (leftExternal) maxOf(d * 1000L, EXTERNAL_GRACE_MS) else d * 1000L
            if (away >= limit) lock()
        }
        leftAt = 0L
        externalUntil = 0L
    }

    fun onScreenOff() {
        if (unlocked && settings.lockOnScreenOff) lock()
    }

    fun onAppExit() = lock()
}
