package com.mahan.mahantgram

import android.content.SharedPreferences
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeSource
import org.drinkless.tdlib.TdApi

@Composable
fun MahanApp(prefs: SharedPreferences) {
    var lang by remember { mutableStateOf(prefs.getString("lang", "fa") ?: "fa") }
    var themeMode by remember { mutableStateOf(prefs.getString("theme", "system") ?: "system") }
    var blurOn by remember { mutableStateOf(prefs.getBoolean("blur", true)) }
    var glassAlpha by remember { mutableFloatStateOf(prefs.getFloat("alpha", 0.45f)) }
    // rememberSaveable: the screen you were on survives the system recreating the app.
    var tab by rememberSaveable { mutableStateOf(prefs.getInt("tab", 0)) }
    var route by rememberSaveable { mutableStateOf("splash") }
    var chatIndex by rememberSaveable { mutableStateOf(0) }
    var chatId by rememberSaveable { mutableStateOf(0L) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var createFor by remember { mutableStateOf<Boolean?>(null) }
    var entered by remember { mutableStateOf(prefs.getBoolean("entered", false)) }

    val live = Td.enabled
    val ready = !live || Td.authState is TdApi.AuthorizationStateReady
    val fa = lang == "fa"
    val s = if (fa) FaStr else EnStr
    SideEffect { Td.fa = fa }
    val dark = when (themeMode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }

    BackHandler(enabled = route != "main" && route != "splash" && !(route == "login" && !entered)) {
        route = if (route == "info") "chat" else "main"
    }

    MahanTheme(dark) {
        CompositionLocalProvider(
            LocalLayoutDirection provides if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr,
        ) {
            val c = LocalMahan.current
            val hazeState = remember { HazeState() }
            val topPad = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 64.dp
            val bottomPad = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 110.dp

            val tabs = listOf(
                TabItem(Icons.Rounded.ChatBubble, s.chats),
                TabItem(Icons.Rounded.Groups, s.groups),
                TabItem(Icons.Rounded.Campaign, s.channels),
                TabItem(Icons.Rounded.Contacts, s.contacts),
                TabItem(Icons.Rounded.Settings, s.settings),
            )

            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c.bgTop, c.bg)))) {
                // Soft green glows behind every screen.
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = 80.dp, y = (-60).dp)
                        .size(320.dp)
                        .background(Brush.radialGradient(listOf(Green.copy(alpha = 0.28f), Color.Transparent)), CircleShape),
                )
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .offset(x = (-90).dp, y = 60.dp)
                        .size(300.dp)
                        .background(Brush.radialGradient(listOf(Green.copy(alpha = 0.18f), Color.Transparent)), CircleShape),
                )

                if (live && !ready && route != "splash" && route != "proxy") {
                    AuthScreen(onProxy = { route = "proxy" })
                } else when (route) {
                    "splash" -> SplashScreen(s) { route = if (live || entered) "main" else "login" }
                    "login" -> LoginScreen(s) {
                        prefs.edit().putBoolean("entered", true).apply()
                        entered = true
                        route = "main"
                    }
                    "profile" -> if (live) {
                        LiveProfile(onBack = { route = "main" }, onSettings = { tab = 4; route = "main" })
                    } else {
                        ProfileScreen(s, onBack = { route = "main" }, onOpenSettings = { tab = 4; route = "main" })
                    }
                    "proxy" -> if (live) LiveProxy { route = "main" } else ProxyScreen(s) { route = "main" }
                    "chat" -> if (live) {
                        LiveChatScreen(chatId, onBack = { route = "main" }, onInfo = { route = "info" })
                    } else {
                        ChatScreen(s, fa, demoChats(fa)[chatIndex], chatIndex) { route = "main" }
                    }
                    "info" -> LiveChatInfo(chatId, onBack = { route = "chat" }, onLeft = { route = "main" })
                    "sessions" -> LiveSessions { route = "main" }
                    else -> {
                        // Everything inside this box is what the glass bars blur.
                        Box(Modifier.fillMaxSize().hazeSource(hazeState)) {
                            when (tab) {
                                0 -> if (live) {
                                    LiveChatList(null, query, topPad, bottomPad, { chatId = it; route = "chat" }, null)
                                } else {
                                    ChatListScreen(s, fa, topPad, bottomPad, query) { chatIndex = it; route = "chat" }
                                }
                                1 -> if (live) {
                                    LiveChatList(ChatKind.GROUP, query, topPad, bottomPad, { chatId = it; route = "chat" }, { createFor = false })
                                } else {
                                    EmptyTab(s.emptyGroupsT, s.emptyGroupsS, s.demoTag, R.drawable.car_gtr_small, CAR_ASPECT, Green, topPad)
                                }
                                2 -> if (live) {
                                    LiveChatList(ChatKind.CHANNEL, query, topPad, bottomPad, { chatId = it; route = "chat" }, { createFor = true })
                                } else {
                                    EmptyTab(s.emptyChannelsT, s.emptyChannelsS, s.demoTag, R.drawable.bike_bmw, BMW_ASPECT, VerifiedBlue, topPad)
                                }
                                3 -> if (live) {
                                    LiveContacts(topPad, bottomPad) { chatId = it; route = "chat" }
                                } else {
                                    EmptyTab(s.emptyContactsT, s.emptyContactsS, s.demoTag, R.drawable.bike_pink, PINK_ASPECT, Color(0xFFFF7AB8), topPad)
                                }
                                else -> SettingsScreen(
                                    s = s,
                                    lang = lang,
                                    onLang = { lang = it; prefs.edit().putString("lang", it).apply() },
                                    themeMode = themeMode,
                                    onTheme = { themeMode = it; prefs.edit().putString("theme", it).apply() },
                                    blurOn = blurOn,
                                    onBlur = { blurOn = it; prefs.edit().putBoolean("blur", it).apply() },
                                    glassAlpha = glassAlpha,
                                    onAlpha = { glassAlpha = it; prefs.edit().putFloat("alpha", it).apply() },
                                    topPad = topPad,
                                    bottomPad = bottomPad,
                                    onOpenProfile = { route = "profile" },
                                    onOpenProxy = { route = "proxy" },
                                    onShowLogin = { route = "login" },
                                    live = live,
                                    onSessions = { route = "sessions" },
                                    onLogout = { Td.logOut() },
                                    profileName = Td.me?.name?.ifEmpty { null } ?: "MahanTgram",
                                    profileUser = Td.me?.username?.let { if (it.isEmpty()) "" else "@$it" } ?: "@username",
                                )
                            }
                        }
                        GlassTopBar(
                            title = if (live && Td.connection.isNotEmpty()) connectionText() else s.appName,
                            hazeState = hazeState,
                            blurOn = blurOn,
                            glassAlpha = glassAlpha,
                            searching = searching,
                            query = query,
                            onQuery = { query = it },
                            onToggleSearch = {
                                if (searching) { searching = false; query = "" } else { searching = true; tab = 0 }
                            },
                            searchHint = s.searchHint,
                            modifier = Modifier.align(Alignment.TopCenter),
                        )
                        if (live && (tab == 1 || tab == 2)) {
                            Box(
                                Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(end = 20.dp, bottom = 190.dp)
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(Green)
                                    .clickable { createFor = (tab == 2) },
                                contentAlignment = Alignment.Center,
                            ) { Text("+", color = Color.Black, fontSize = 28.sp) }
                        }
                        GlassBottomBar(
                            tabs = tabs,
                            selected = tab,
                            onSelect = { tab = it; prefs.edit().putInt("tab", it).apply() },
                            hazeState = hazeState,
                            blurOn = blurOn,
                            glassAlpha = glassAlpha,
                            modifier = Modifier.align(Alignment.BottomCenter),
                        )
                    }
                }

                createFor?.let { ch ->
                    CreateChatDialog(
                        channel = ch,
                        onDismiss = { createFor = null },
                        onCreated = { id -> createFor = null; chatId = id; route = "chat" },
                    )
                }
            }
        }
    }
}
