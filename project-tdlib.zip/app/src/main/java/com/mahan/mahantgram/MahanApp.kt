package com.mahan.mahantgram

import android.content.SharedPreferences
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.Contacts
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeSource
import org.drinkless.tdlib.TdApi

@Composable
fun MahanApp(prefs: SharedPreferences) {
    var lang by remember { mutableStateOf(prefs.getString("lang", "fa") ?: "fa") }
    var themeMode by remember { mutableStateOf(prefs.getString("theme", "system") ?: "system") }
    var pattern by remember { mutableStateOf(prefs.getInt("pattern", 0)) }
    var blurOn by remember { mutableStateOf(prefs.getBoolean("blur", true)) }
    var glassAlpha by remember { mutableFloatStateOf(prefs.getFloat("alpha", 0.45f)) }
    // rememberSaveable: the screen you were on survives the system recreating the app.
    // Tabs: 0 = Settings, 1 = Chats, 2 = Contacts, 3 = Profile (new key so old saved values are ignored)
    var tab by rememberSaveable { mutableStateOf(prefs.getInt("tab4", 1)) }
    var route by rememberSaveable { mutableStateOf("splash") }
    var chatIndex by rememberSaveable { mutableStateOf(0) }
    var chatId by rememberSaveable { mutableStateOf(0L) }
    var infoBack by rememberSaveable { mutableStateOf("chat") }
    var profUser by rememberSaveable { mutableStateOf(0L) }
    var profBack by rememberSaveable { mutableStateOf("main") }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var searchFocus by rememberSaveable { mutableStateOf(0) }
    var createFor by remember { mutableStateOf<Boolean?>(null) }
    var newMenu by remember { mutableStateOf(false) }
    var entered by remember { mutableStateOf(prefs.getBoolean("entered", false)) }

    val live = Td.enabled
    val ready = !live || Td.authState is TdApi.AuthorizationStateReady
    val fa = lang == "fa"
    val s = when (lang) {
        "fa" -> FaStr
        "ru" -> RuStr
        "de" -> DeStr
        "fr" -> FrStr
        else -> EnStr
    }
    remember(lang) { Td.fa = fa; Td.lang = lang }
    SideEffect { Td.fa = fa; Td.lang = lang }
    val dark = when (themeMode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }

    // A hidden chat opened from AjiMaji returns to AjiMaji, never to the public list.
    fun chatExit(): String = if (Vault.isHidden(chatId) && Vault.unlocked) "vault" else "main"

    BackHandler(enabled = route != "main" && route != "splash" && !(route == "login" && !entered)) {
        route = when (route) {
            "info" -> infoBack
            "user" -> profBack
            "chat" -> chatExit()
            else -> "main"
        }
    }

    // Locking (manual, screen off, leaving the app) throws the user out of every private screen.
    val vaultOpen = Vault.unlocked
    LaunchedEffect(vaultOpen) {
        if (!vaultOpen && (route == "vault" || ((route == "chat" || route == "info") && Vault.isHidden(chatId)) || (route == "user" && Vault.isHidden(profUser)))) {
            route = "main"
        }
    }

    // While AjiMaji is open: no screenshots, blank recent-apps preview.
    val activity = LocalContext.current as? android.app.Activity
    val secure = Vault.settings.secureScreen && (Vault.unlocked || route == "vault")
    SideEffect {
        val w = activity?.window
        if (w != null) {
            if (secure) w.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
            else w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    MahanTheme(dark) {
        CompositionLocalProvider(
            LocalLayoutDirection provides if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr,
        ) {
            val c = LocalMahan.current
            val hazeState = remember { HazeState() }
            val topPad = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 64.dp
            val bottomPad = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 110.dp

            val tabs = listOf(
                TabItem(Icons.Rounded.Settings, s.settings),
                TabItem(Icons.Rounded.ChatBubble, s.chats),
                TabItem(Icons.Rounded.Contacts, s.contacts),
                TabItem(Icons.Rounded.Person, tr("پروفایل", "Profile")),
            )

            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c.bgTop, c.bg)))) {
                // Soft green glows behind every screen.
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = 80.dp, y = (-60).dp)
                        .size(320.dp)
                        .background(Brush.radialGradient(listOf(Green.copy(alpha = 0.28f), Color.Transparent)), CircleShape),
                )
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .offset(x = (-90).dp, y = 60.dp)
                        .size(300.dp)
                        .background(Brush.radialGradient(listOf(Green.copy(alpha = 0.18f), Color.Transparent)), CircleShape),
                )

                PatternBackground(pattern, Green.copy(alpha = 0.16f), Modifier.fillMaxSize())

                if (live && !ready && route != "splash" && route != "proxy") {
                    AuthScreen(onProxy = { route = "proxy" })
                } else when (route) {
                    "splash" -> SplashScreen(s) { route = if (live || entered) "main" else "login" }
                    "login" -> LoginScreen(s) {
                        prefs.edit().putBoolean("entered", true).apply()
                        entered = true
                        route = "main"
                    }
                    "profile" -> if (live) {
                        LiveProfile(onBack = { route = "main" }, onSettings = { tab = 0; route = "main" })
                    } else {
                        ProfileScreen(s, onBack = { route = "main" }, onOpenSettings = { tab = 0; route = "main" })
                    }
                    "proxy" -> if (live) LiveProxy { route = "main" } else ProxyScreen(s) { route = "main" }
                    "chat" -> if (live) {
                        androidx.compose.runtime.key(chatId) {
                            LiveChatScreen(
                                chatId, onBack = { route = chatExit() },
                                onInfo = { infoBack = "chat"; route = "info" },
                                onUser = { profUser = it; profBack = "chat"; route = "user" },
                                onOpenChat = { chatId = it; route = "chat" },
                            )
                        }
                    } else {
                        ChatScreen(s, fa, demoChats(fa)[chatIndex], chatIndex) { route = "main" }
                    }
                    "info" -> LiveChatInfo(
                        chatId,
                        onBack = { route = infoBack },
                        onLeft = { route = chatExit() },
                        onUser = { profUser = it; profBack = "info"; route = "user" },
                        onOpenChat = { chatId = it; route = "chat" },
                    )
                    "user" -> UserProfileScreen(
                        profUser,
                        onBack = { route = profBack },
                        onChat = { chatId = it; route = "chat" },
                    )
                    "vault" -> VaultRoot(
                        onBack = { route = "main" },
                        onOpenChat = { chatId = it; route = "chat" },
                    )
                    "sessions" -> LiveSessions { route = "main" }
                    else -> {
                        // Everything inside this box is what the glass bars blur.
                        Box(Modifier.fillMaxSize().hazeSource(hazeState)) {
                            when (tab) {
                                1 -> if (live) {
                                    LiveChatList(
                                        null, query, topPad, bottomPad, { chatId = it; route = "chat" }, null,
                                        onAvatar = { chatId = it; infoBack = "main"; route = "info" },
                                        onQuery = { query = it },
                                        focusTick = searchFocus,
                                    )
                                } else {
                                    ChatListScreen(s, fa, topPad, bottomPad, query) { chatIndex = it; route = "chat" }
                                }
                                2 -> if (live) {
                                    LiveContacts(
                                        topPad, bottomPad,
                                        onProfile = { profUser = it; profBack = "main"; route = "user" },
                                        onInfo = { chatId = it; infoBack = "main"; route = "info" },
                                    ) { chatId = it; route = "chat" }
                                } else {
                                    EmptyTab(s.emptyContactsT, s.emptyContactsS, s.demoTag, R.drawable.car_gtr_small, CAR_ASPECT, Color(0xFFFF7AB8), topPad)
                                }
                                3 -> if (live) {
                                    LiveProfile(
                                        onBack = { tab = 1 },
                                        onSettings = { tab = 0 },
                                        embedded = true,
                                        topPad = topPad,
                                        bottomPad = bottomPad,
                                    )
                                } else {
                                    ProfileScreen(s, onBack = { tab = 1 }, onOpenSettings = { tab = 0 })
                                }
                                else -> SettingsScreen(
                                    s = s,
                                    lang = lang,
                                    onLang = { lang = it; prefs.edit().putString("lang", it).apply() },
                                    themeMode = themeMode,
                                    onTheme = { themeMode = it; prefs.edit().putString("theme", it).apply() },
                                    blurOn = blurOn,
                                    onBlur = { blurOn = it; prefs.edit().putBoolean("blur", it).apply() },
                                    glassAlpha = glassAlpha,
                                    onAlpha = { glassAlpha = it; prefs.edit().putFloat("alpha", it).apply() },
                                    onAccent = { Accent.color = Color(it); prefs.edit().putInt("accent", it).apply() },
                                    pattern = pattern,
                                    onPattern = { pattern = it; prefs.edit().putInt("pattern", it).apply() },
                                    topPad = topPad,
                                    bottomPad = bottomPad,
                                    onOpenProfile = { tab = 3; prefs.edit().putInt("tab4", 3).apply() },
                                    onOpenProxy = { route = "proxy" },
                                    onShowLogin = { route = "login" },
                                    live = live,
                                    onSessions = { route = "sessions" },
                                    onLogout = { Td.logOut() },
                                    onOpenVault = { route = "vault" },
                                    profileName = Td.me?.name?.ifEmpty { null } ?: "MahanTgram",
                                    profileUser = Td.me?.username?.let { if (it.isEmpty()) "" else "@$it" } ?: "@username",
                                )
                            }
                        }
                        GlassTopBar(
                            title = if (live && Td.connection.isNotEmpty()) connectionText() else s.appName,
                            hazeState = hazeState,
                            blurOn = blurOn,
                            glassAlpha = glassAlpha,
                            searching = false,
                            query = query,
                            onQuery = { query = it },
                            // The search field now lives under the stories bar; the magnifier jumps to it.
                            onToggleSearch = { tab = 1; searchFocus++ },
                            searchHint = s.searchHint,
                            onVault = if (live && tab == 1) ({ route = "vault" }) else null,
                            modifier = Modifier.align(Alignment.TopCenter),
                        )
                        if (live && tab == 1) {
                            Box(
                                Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(end = 20.dp, bottom = 190.dp)
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(Green)
                                    .clickable { newMenu = true },
                                contentAlignment = Alignment.Center,
                            ) { Text("+", color = Color.Black, fontSize = 28.sp) }
                        }
                        GlassBottomBar(
                            tabs = tabs,
                            selected = tab,
                            onSelect = { tab = it; prefs.edit().putInt("tab4", it).apply() },
                            hazeState = hazeState,
                            blurOn = blurOn,
                            glassAlpha = glassAlpha,
                            modifier = Modifier.align(Alignment.BottomCenter),
                        )
                    }
                }

                if (newMenu) {
                    androidx.compose.material3.AlertDialog(
                        onDismissRequest = { newMenu = false },
                        title = { Text(tr("ساخت جدید", "Create new")) },
                        text = {
                            Column {
                                androidx.compose.material3.TextButton(onClick = { newMenu = false; createFor = false }) {
                                    Text(tr("گروه جدید", "New group"))
                                }
                                androidx.compose.material3.TextButton(onClick = { newMenu = false; createFor = true }) {
                                    Text(tr("کانال جدید", "New channel"))
                                }
                            }
                        },
                        confirmButton = {},
                        dismissButton = {
                            androidx.compose.material3.TextButton(onClick = { newMenu = false }) { Text(tr("لغو", "Cancel")) }
                        },
                    )
                }
                createFor?.let { ch ->
                    CreateChatDialog(
                        channel = ch,
                        onDismiss = { createFor = null },
                        onCreated = { id -> createFor = null; chatId = id; route = "chat" },
                    )
                }
            }
        }
    }
}
