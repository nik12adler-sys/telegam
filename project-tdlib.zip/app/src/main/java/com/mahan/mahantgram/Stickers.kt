package com.mahan.mahantgram

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.rememberLottieComposition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.drinkless.tdlib.TdApi
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.GZIPInputStream

// ====================================================================== shared sticker drawing
// Used by gifts, custom emoji in messages and emoji statuses, so all of them show the real
// Telegram artwork: TGS (Lottie) animated, WebP as an image, WebM through its static preview.

private fun Any?.fo(name: String): Any? = this?.fieldOrNull(name)

/** format: 0 = webp, 1 = tgs (animated), 2 = webm (video, shown by its preview). */
class StickerRef(val fileId: Int, val format: Int, val thumbFileId: Int, val emoji: String)

object StickerKit {
    /** Reads a TDLib Sticker object and starts downloading what is needed to draw it. */
    fun ref(sticker: Any?): StickerRef? {
        val f = sticker.fo("sticker") as? TdApi.File ?: return null
        val fmt = when (sticker.fo("format")) {
            is TdApi.StickerFormatTgs -> 1
            is TdApi.StickerFormatWebm -> 2
            else -> 0
        }
        val th = sticker.fo("thumbnail").fo("file") as? TdApi.File
        Td.registerFile(f, fmt != 2)
        if (th != null) Td.registerFile(th, true)
        return StickerRef(f.id, fmt, th?.id ?: 0, (sticker.fo("emoji") as? String).orEmpty())
    }
}

@Composable
fun StickerImage(s: StickerRef?, modifier: Modifier = Modifier.size(64.dp), animate: Boolean = true) {
    if (s == null) { Box(modifier); return }
    val path = Td.files[s.fileId]
    val thumb = Td.files[s.thumbFileId]
    when {
        s.format == 1 && path != null && (animate || thumb == null) -> LottieSticker(path, modifier, animate)
        s.format == 0 && path != null -> {
            val bmp = rememberBitmap(path, 512)
            if (bmp != null) Image(bmp, null, modifier, contentScale = ContentScale.Fit) else Box(modifier)
        }
        thumb != null -> {
            val bmp = rememberBitmap(thumb, 300)
            if (bmp != null) Image(bmp, null, modifier, contentScale = ContentScale.Fit) else Box(modifier)
        }
        else -> Box(modifier, contentAlignment = Alignment.Center) { Text(s.emoji.ifEmpty { "🎁" }, fontSize = 24.sp) }
    }
}

@Composable
private fun LottieSticker(path: String, modifier: Modifier, animate: Boolean) {
    val json by produceState<String?>(null, path) {
        value = withContext(Dispatchers.IO) {
            runCatching { GZIPInputStream(File(path).inputStream()).bufferedReader().use { it.readText() } }.getOrNull()
        }
    }
    val j = json
    if (j == null) { Box(modifier); return }
    val comp by rememberLottieComposition(LottieCompositionSpec.JsonString(j))
    if (animate) LottieAnimation(composition = comp, iterations = LottieConstants.IterateForever, modifier = modifier)
    else LottieAnimation(composition = comp, progress = { 0f }, modifier = modifier)
}

// ====================================================================== custom emoji

object CustomEmoji {
    private val cache = ConcurrentHashMap<Long, StickerRef>()

    suspend fun get(id: Long): StickerRef? {
        cache[id]?.let { return it }
        val r = runCatching { Td.req(mk<TdApi.Object>("GetCustomEmojiStickers", "customEmojiIds" to longArrayOf(id))) }.getOrNull()
        val st = (r.fo("stickers") as? Array<*>)?.firstOrNull() ?: return null
        val ref = StickerKit.ref(st) ?: return null
        cache[id] = ref
        return ref
    }

    /** Several at once (the status picker). Keeps TDLib's order. */
    suspend fun many(ids: List<Long>): List<Pair<Long, StickerRef>> {
        val r = runCatching { Td.req(mk<TdApi.Object>("GetCustomEmojiStickers", "customEmojiIds" to ids.toLongArray())) }.getOrNull()
            ?: return emptyList()
        val out = ArrayList<Pair<Long, StickerRef>>()
        (r.fo("stickers") as? Array<*>)?.forEachIndexed { i, st ->
            val ref = StickerKit.ref(st) ?: return@forEachIndexed
            val id = ids.getOrNull(i) ?: return@forEachIndexed
            cache[id] = ref
            out.add(id to ref)
        }
        return out
    }
}

@Composable
fun CustomEmojiView(id: Long, modifier: Modifier = Modifier.size(16.dp), animate: Boolean = false) {
    val ref by produceState<StickerRef?>(null, id) { value = CustomEmoji.get(id) }
    StickerImage(ref, modifier, animate)
}

/** The badge next to a Premium user's name: their emoji status when they have one, else the Premium star. */
@Composable
fun PremiumBadge(statusEmojiId: Long, size: Dp = 16.dp) {
    if (statusEmojiId != 0L) CustomEmojiView(statusEmojiId, Modifier.size(size), animate = true)
    else PremiumStar(size)
}
