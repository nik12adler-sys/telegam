# MahanTgram for Kali / Debian-based Linux

Install the .deb produced by the "linux" CI job:

    sudo apt install ./mahantgram_0.2.0-1_amd64.deb
    /opt/mahantgram/bin/mahantgram

Data lives in ~/.config/mahantgram.
