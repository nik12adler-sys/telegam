package android.os

object Build {
    object VERSION { const val SDK_INT = 35; val RELEASE: String = "Linux" }
    val MODEL: String = System.getProperty("os.name") + " " + System.getProperty("os.version")
}
object SystemClock { fun elapsedRealtime(): Long = System.nanoTime() / 1_000_000 }
class Looper private constructor() { companion object { private val L = Looper(); fun getMainLooper() = L } }
class Handler(@Suppress("UNUSED_PARAMETER") looper: Looper) {
    fun post(r: Runnable): Boolean { javax.swing.SwingUtilities.invokeLater(r); return true }
    fun postDelayed(r: Runnable, ms: Long): Boolean {
        javax.swing.Timer(ms.toInt()) { r.run() }.apply { isRepeats = false; start() }; return true
    }
}
class Bundle
class CancellationSignal
