package android.widget
import android.content.Context
class Toast private constructor(private val msg: String) {
    fun show() { System.err.println("[toast] $msg") }
    companion object {
        const val LENGTH_SHORT = 0; const val LENGTH_LONG = 1
        fun makeText(c: Context?, t: CharSequence, d: Int) = Toast(t.toString())
        fun makeText(c: Context?, id: Int, d: Int) = Toast("")
    }
}
