package android.provider
object OpenableColumns { const val DISPLAY_NAME = "_display_name"; const val SIZE = "_size" }
object ContactsContract { object CommonDataKinds { object Phone {
    val CONTENT_URI: android.net.Uri = android.net.Uri.parse("content://contacts/phones")
    const val NUMBER = "data1"; const val DISPLAY_NAME = "display_name"
} } }
