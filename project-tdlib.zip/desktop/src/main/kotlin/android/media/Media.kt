package android.media
import android.content.Context
/** Desktop stubs: voice notes / audio playback land in stage D4. */
class MediaMetadataRetriever {
    companion object { const val METADATA_KEY_TITLE = 7; const val METADATA_KEY_ARTIST = 2; const val METADATA_KEY_DURATION = 9 }
    fun setDataSource(path: String) {}
    fun extractMetadata(key: Int): String? = null
    fun release() {}
}
class MediaRecorder() {
    constructor(@Suppress("UNUSED_PARAMETER") c: Context) : this()
    object AudioSource { const val MIC = 1 }
    object OutputFormat { const val OGG = 11 }
    object AudioEncoder { const val OPUS = 7 }
    fun setAudioSource(s: Int) {}; fun setOutputFormat(f: Int) {}; fun setAudioEncoder(e: Int) {}
    fun setOutputFile(p: String) {}; fun setAudioEncodingBitRate(b: Int) {}; fun setAudioSamplingRate(r: Int) {}
    fun prepare() {}; fun start() {}; fun stop() {}; fun release() {}
}
class MediaPlayer {
    var onComplete: (() -> Unit)? = null
    fun setDataSource(p: String) {}; fun prepare() {}; fun start() {}; fun pause() {}; fun stop() {}; fun release() {}
    fun setOnCompletionListener(l: (MediaPlayer) -> Unit) {}
    val isPlaying: Boolean get() = false
    val duration: Int get() = 0
    val currentPosition: Int get() = 0
    fun seekTo(ms: Int) {}
}
