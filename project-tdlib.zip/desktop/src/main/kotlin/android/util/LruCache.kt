package android.util
open class LruCache<K : Any, V : Any>(private val max: Int) {
    private val m = object : LinkedHashMap<K, V>(16, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<K, V>) = size > max
    }
    @Synchronized fun get(k: K): V? = m[k]
    @Synchronized fun put(k: K, v: V): V? = m.put(k, v)
    @Synchronized fun remove(k: K): V? = m.remove(k)
    @Synchronized fun evictAll() = m.clear()
}
