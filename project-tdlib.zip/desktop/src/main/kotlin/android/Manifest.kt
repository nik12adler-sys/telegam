package android
object Manifest { object permission {
    const val RECORD_AUDIO = "android.permission.RECORD_AUDIO"
    const val ACCESS_FINE_LOCATION = "android.permission.ACCESS_FINE_LOCATION"
    const val ACCESS_COARSE_LOCATION = "android.permission.ACCESS_COARSE_LOCATION"
} }
