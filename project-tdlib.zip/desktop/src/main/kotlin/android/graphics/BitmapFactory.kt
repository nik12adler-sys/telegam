package android.graphics
class Bitmap(val width: Int, val height: Int, val image: java.awt.image.BufferedImage? = null)
object BitmapFactory {
    class Options { var inJustDecodeBounds = false; var inSampleSize = 1; var outWidth = 0; var outHeight = 0 }
    fun decodeFile(path: String, o: Options? = null): Bitmap? = try {
        val img = javax.imageio.ImageIO.read(java.io.File(path)) ?: return null
        if (o != null && o.inJustDecodeBounds) { o.outWidth = img.width; o.outHeight = img.height; null }
        else Bitmap(img.width, img.height, img)
    } catch (_: Throwable) { null }
}
