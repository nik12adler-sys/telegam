package android.net

import java.io.File

class Uri private constructor(private val s: String) {
    val path: String? get() = if (s.startsWith("file://")) s.removePrefix("file://") else java.net.URI(s).path
    val lastPathSegment: String? get() = s.substringAfterLast('/', "").ifEmpty { null }
    val scheme: String? get() = s.substringBefore(":", "").ifEmpty { null }
    override fun toString() = s
    override fun equals(other: Any?) = other is Uri && other.s == s
    override fun hashCode() = s.hashCode()
    companion object {
        val EMPTY = Uri("")
        fun parse(s: String): Uri = Uri(s)
        fun fromFile(f: File): Uri = Uri("file://" + f.absolutePath)
    }
}
