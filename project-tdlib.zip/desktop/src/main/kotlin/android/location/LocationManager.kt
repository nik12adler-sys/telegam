package android.location
class LocationManager {
    companion object { const val GPS_PROVIDER = "gps"; const val NETWORK_PROVIDER = "network" }
    fun getProviders(enabledOnly: Boolean): List<String> = emptyList()
}
