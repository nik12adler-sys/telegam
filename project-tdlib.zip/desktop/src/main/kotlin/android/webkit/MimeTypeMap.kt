package android.webkit
class MimeTypeMap private constructor() {
    fun getMimeTypeFromExtension(ext: String): String? = try {
        java.net.URLConnection.guessContentTypeFromName("x." + ext.lowercase())
    } catch (_: Throwable) { null }
    fun getExtensionFromMimeType(m: String): String? = m.substringAfter('/', "").ifEmpty { null }
    companion object {
        private val I = MimeTypeMap()
        fun getSingleton() = I
        fun getFileExtensionFromUrl(u: String): String = u.substringAfterLast('.', "").substringBefore('?')
    }
}
