package android.hardware.biometrics
import android.app.Activity
/** Desktop: no biometrics. The app falls back to its own passcode. */
object BiometricManager { }
class BiometricPrompt private constructor() {
    class Builder(@Suppress("UNUSED_PARAMETER") a: Activity) {
        fun setTitle(t: CharSequence) = this
        fun setSubtitle(t: CharSequence) = this
        fun setNegativeButton(t: CharSequence, e: java.util.concurrent.Executor, l: android.content.DialogInterface.OnClickListener) = this
        fun build() = BiometricPrompt()
    }
    abstract class AuthenticationCallback {
        open fun onAuthenticationSucceeded(result: AuthenticationResult?) {}
        open fun onAuthenticationError(code: Int, msg: CharSequence?) {}
        open fun onAuthenticationFailed() {}
    }
    class AuthenticationResult
    fun authenticate(c: android.os.CancellationSignal, e: java.util.concurrent.Executor, cb: AuthenticationCallback) {
        cb.onAuthenticationError(0, "unavailable on desktop")
    }
}
