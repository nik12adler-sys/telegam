package android.content
interface DialogInterface { fun interface OnClickListener { fun onClick(d: DialogInterface, which: Int) } }
