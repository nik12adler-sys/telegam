package android.content

import java.io.File
import java.io.InputStream
import java.util.Properties

/** Desktop stand-in for android.content.Context (only what MahanTgram uses). */
open class Context {
    companion object {
        const val MODE_PRIVATE = 0
        const val LOCATION_SERVICE = "location"
        const val CLIPBOARD_SERVICE = "clipboard"
        const val AUDIO_SERVICE = "audio"
        const val RECEIVER_NOT_EXPORTED = 4
    }

    val applicationContext: Context get() = this
    val packageName: String = "com.mahan.mahantgram"

    private val base: File = File(System.getProperty("user.home"), ".config/mahantgram").also { it.mkdirs() }
    val filesDir: File = File(base, "files").also { it.mkdirs() }
    val cacheDir: File = File(base, "cache").also { it.mkdirs() }
    fun getExternalFilesDir(type: String?): File? = File(filesDir, type ?: "ext").also { it.mkdirs() }
    val externalCacheDir: File get() = cacheDir

    val contentResolver: ContentResolver = ContentResolver()
    val mainExecutor: java.util.concurrent.Executor = java.util.concurrent.Executor { it.run() }

    fun getString(id: Int): String = "MahanTgram"

    private val prefs = HashMap<String, SharedPreferences>()
    fun getSharedPreferences(name: String, mode: Int): SharedPreferences =
        prefs.getOrPut(name) { FilePrefs(File(base, "prefs/$name.properties")) }

    fun getSystemService(name: String): Any? = when (name) {
        CLIPBOARD_SERVICE -> ClipboardManager
        else -> null
    }

    fun startActivity(i: Intent) {
        val data = i.data?.toString() ?: return
        try {
            if (java.awt.Desktop.isDesktopSupported()) {
                java.awt.Desktop.getDesktop().browse(java.net.URI(data))
            } else {
                ProcessBuilder("xdg-open", data).start()
            }
        } catch (_: Throwable) {
            try { ProcessBuilder("xdg-open", data).start() } catch (_: Throwable) {}
        }
    }
}

/** android.app.Activity is a Context too. */
open class ContentResolver {
    fun openInputStream(uri: android.net.Uri): InputStream? =
        try { File(uri.path ?: return null).inputStream() } catch (_: Throwable) { null }
    fun getType(uri: android.net.Uri): String? = android.webkit.MimeTypeMap.getSingleton()
        .getMimeTypeFromExtension(android.webkit.MimeTypeMap.getFileExtensionFromUrl(uri.toString()))
    fun query(uri: android.net.Uri, a: Array<String>?, b: String?, c: Array<String>?, d: String?): android.database.Cursor? = null
    fun takePersistableUriPermission(uri: android.net.Uri, flags: Int) {}
}

interface SharedPreferences {
    fun getString(key: String, def: String?): String?
    fun getInt(key: String, def: Int): Int
    fun getLong(key: String, def: Long): Long
    fun getFloat(key: String, def: Float): Float
    fun getBoolean(key: String, def: Boolean): Boolean
    fun getStringSet(key: String, def: Set<String>?): Set<String>?
    fun contains(key: String): Boolean
    val all: Map<String, *>
    fun edit(): Editor

    interface Editor {
        fun putString(key: String, v: String?): Editor
        fun putInt(key: String, v: Int): Editor
        fun putLong(key: String, v: Long): Editor
        fun putFloat(key: String, v: Float): Editor
        fun putBoolean(key: String, v: Boolean): Editor
        fun putStringSet(key: String, v: Set<String>?): Editor
        fun remove(key: String): Editor
        fun clear(): Editor
        fun apply()
        fun commit(): Boolean
    }
}

/** SharedPreferences backed by a .properties file in ~/.config/mahantgram/prefs. */
internal class FilePrefs(private val file: File) : SharedPreferences {
    private val props = Properties()
    init {
        file.parentFile.mkdirs()
        if (file.exists()) try { file.inputStream().use { props.load(it) } } catch (_: Throwable) {}
    }
    private fun raw(k: String): String? = props.getProperty(k)
    override fun getString(key: String, def: String?) = raw(key)?.removePrefix("s:") ?: def
    override fun getInt(key: String, def: Int) = raw(key)?.removePrefix("i:")?.toIntOrNull() ?: def
    override fun getLong(key: String, def: Long) = raw(key)?.removePrefix("l:")?.toLongOrNull() ?: def
    override fun getFloat(key: String, def: Float) = raw(key)?.removePrefix("f:")?.toFloatOrNull() ?: def
    override fun getBoolean(key: String, def: Boolean) = raw(key)?.removePrefix("b:")?.toBooleanStrictOrNull() ?: def
    override fun getStringSet(key: String, def: Set<String>?): Set<String>? =
        raw(key)?.removePrefix("S:")?.let { if (it.isEmpty()) emptySet() else it.split('\u001F').toSet() } ?: def
    override fun contains(key: String) = props.containsKey(key)
    override val all: Map<String, *> get() = props.stringPropertyNames().associateWith { raw(it)?.drop(2) }
    override fun edit(): SharedPreferences.Editor = object : SharedPreferences.Editor {
        val pending = LinkedHashMap<String, String?>()
        var clearAll = false
        override fun putString(key: String, v: String?) = apply { pending[key] = v?.let { "s:$it" } }
        override fun putInt(key: String, v: Int) = apply { pending[key] = "i:$v" }
        override fun putLong(key: String, v: Long) = apply { pending[key] = "l:$v" }
        override fun putFloat(key: String, v: Float) = apply { pending[key] = "f:$v" }
        override fun putBoolean(key: String, v: Boolean) = apply { pending[key] = "b:$v" }
        override fun putStringSet(key: String, v: Set<String>?) = apply { pending[key] = v?.let { "S:" + it.joinToString("\u001F") } }
        override fun remove(key: String) = apply { pending[key] = null }
        override fun clear() = apply { clearAll = true }
        override fun apply() { commit() }
        override fun commit(): Boolean {
            synchronized(props) {
                if (clearAll) props.clear()
                for ((k, v) in pending) if (v == null) props.remove(k) else props.setProperty(k, v)
                return try { file.outputStream().use { props.store(it, null) }; true } catch (_: Throwable) { false }
            }
        }
    }
}

object ClipboardManager {
    fun setPrimaryClip(c: ClipData) {
        try {
            java.awt.Toolkit.getDefaultToolkit().systemClipboard
                .setContents(java.awt.datatransfer.StringSelection(c.text), null)
        } catch (_: Throwable) {}
    }
}
class ClipData private constructor(val text: String) {
    companion object { fun newPlainText(label: CharSequence?, text: CharSequence): ClipData = ClipData(text.toString()) }
}

open class Intent(val action: String? = null, var data: android.net.Uri? = null) {
    constructor(action: String, uri: android.net.Uri, @Suppress("UNUSED_PARAMETER") x: Any?) : this(action, uri)
    var flags: Int = 0
    var type: String? = null
    fun addFlags(f: Int): Intent { flags = flags or f; return this }
    fun setType(t: String): Intent { type = t; return this }
    fun putExtra(k: String, v: Any?): Intent = this
    companion object {
        const val ACTION_VIEW = "android.intent.action.VIEW"
        const val ACTION_PICK = "android.intent.action.PICK"
        const val ACTION_SCREEN_OFF = "android.intent.action.SCREEN_OFF"
        const val FLAG_ACTIVITY_NEW_TASK = 0x10000000
        const val FLAG_GRANT_READ_URI_PERMISSION = 1
    }
}
class IntentFilter(val action: String? = null)
abstract class BroadcastReceiver { abstract fun onReceive(context: Context, intent: Intent) }
