package android.security.keystore
/** Desktop: Vault key storage moves to a file-based key in stage D2 (AndroidKeyStore does not exist on JVM). */
object KeyProperties { const val PURPOSE_ENCRYPT = 1; const val PURPOSE_DECRYPT = 2; const val BLOCK_MODE_GCM = "GCM"; const val ENCRYPTION_PADDING_NONE = "NoPadding" }
class KeyGenParameterSpec private constructor() : java.security.spec.AlgorithmParameterSpec {
    class Builder(@Suppress("UNUSED_PARAMETER") alias: String, @Suppress("UNUSED_PARAMETER") purposes: Int) {
        fun setBlockModes(vararg m: String) = this
        fun setEncryptionPaddings(vararg p: String) = this
        fun setKeySize(s: Int) = this
        fun build() = KeyGenParameterSpec()
    }
}
