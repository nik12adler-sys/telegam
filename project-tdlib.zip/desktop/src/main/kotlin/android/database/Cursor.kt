package android.database
interface Cursor : java.io.Closeable {
    fun moveToFirst(): Boolean
    fun getColumnIndex(name: String): Int
    fun getString(i: Int): String?
    fun getLong(i: Int): Long
}
