package androidx.activity.result.contract
import android.content.Context
import android.content.Intent
import android.net.Uri
import java.awt.FileDialog
import java.awt.Frame
import java.io.File

abstract class ActivityResultContract<I, O> {
    abstract fun createIntent(context: Context, input: I): Intent
    abstract fun parseResult(resultCode: Int, intent: Intent?): O
    /** Desktop-only hook: run the picker directly. */
    open fun run(input: I): O = throw UnsupportedOperationException("not supported on desktop")
}

private fun pick(multi: Boolean): List<Uri> {
    val d = FileDialog(null as Frame?, "Select", FileDialog.LOAD)
    d.isMultipleMode = multi
    d.isVisible = true
    return d.files.map { Uri.fromFile(it) }
}

object ActivityResultContracts {
    class GetContent : ActivityResultContract<String, Uri?>() {
        override fun createIntent(context: Context, input: String) = Intent()
        override fun parseResult(resultCode: Int, intent: Intent?): Uri? = null
        override fun run(input: String): Uri? = pick(false).firstOrNull()
    }
    class GetMultipleContents : ActivityResultContract<String, List<Uri>>() {
        override fun createIntent(context: Context, input: String) = Intent()
        override fun parseResult(resultCode: Int, intent: Intent?): List<Uri> = emptyList()
        override fun run(input: String): List<Uri> = pick(true)
    }
    class PickVisualMedia : ActivityResultContract<androidx.activity.result.PickVisualMediaRequest, Uri?>() {
        object ImageAndVideo
        object ImageOnly
        object VideoOnly
        override fun createIntent(context: Context, input: androidx.activity.result.PickVisualMediaRequest) = Intent()
        override fun parseResult(resultCode: Int, intent: Intent?): Uri? = null
        override fun run(input: androidx.activity.result.PickVisualMediaRequest): Uri? = pick(false).firstOrNull()
    }
    class RequestPermission : ActivityResultContract<String, Boolean>() {
        override fun createIntent(context: Context, input: String) = Intent()
        override fun parseResult(resultCode: Int, intent: Intent?) = true
        override fun run(input: String) = true
    }
    class RequestMultiplePermissions : ActivityResultContract<Array<String>, Map<String, Boolean>>() {
        override fun createIntent(context: Context, input: Array<String>) = Intent()
        override fun parseResult(resultCode: Int, intent: Intent?): Map<String, Boolean> = emptyMap()
        override fun run(input: Array<String>) = input.associateWith { true }
    }
}
