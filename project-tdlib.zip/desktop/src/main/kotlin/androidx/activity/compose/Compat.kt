package androidx.activity.compose
import androidx.compose.runtime.*
import androidx.activity.result.contract.ActivityResultContract

@Composable
fun BackHandler(enabled: Boolean = true, onBack: () -> Unit) {
    // Desktop: Esc key handling can be added in Main.kt; no system back button here.
}

class ManagedActivityResultLauncher<I, O>(val launch: (I) -> Unit) {
    fun launch(input: I) = launch.invoke(input)
}

@Composable
fun <I, O> rememberLauncherForActivityResult(
    contract: ActivityResultContract<I, O>,
    onResult: (O) -> Unit,
): ManagedActivityResultLauncher<I, O> {
    val cb = rememberUpdatedState(onResult)
    return remember(contract) {
        ManagedActivityResultLauncher<I, O> { input ->
            // Runs the desktop file chooser off the UI thread, then calls back.
            Thread { cb.value(contract.run(input)) }.start()
        }
    }
}
