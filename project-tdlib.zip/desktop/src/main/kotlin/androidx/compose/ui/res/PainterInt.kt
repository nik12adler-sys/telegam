package androidx.compose.ui.res
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.painter.Painter

@Composable
fun painterResource(id: Int): Painter = remember(id) {
    BitmapPainter(useResource(com.mahan.mahantgram.R.path(id), ::loadImageBitmap))
}
