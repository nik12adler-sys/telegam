package androidx.compose.ui.platform
import androidx.compose.runtime.staticCompositionLocalOf
import android.content.Context
import android.app.Activity
/** Desktop: one global Context/Activity. */
val DesktopActivity: Activity = Activity()
val LocalContext = staticCompositionLocalOf<Context> { DesktopActivity }
