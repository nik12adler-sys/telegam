package androidx.compose.ui.viewinterop
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
/** Desktop: native Android views do not exist. Video/PlayerView is a TODO (stage D4). */
@Composable
fun <T : Any> AndroidView(factory: (android.content.Context) -> T, modifier: Modifier = Modifier, update: (T) -> Unit = {}) {}
