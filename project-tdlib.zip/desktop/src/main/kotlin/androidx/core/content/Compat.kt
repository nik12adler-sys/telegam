package androidx.core.content
import android.content.*
object ContextCompat {
    const val RECEIVER_NOT_EXPORTED = 4
    const val RECEIVER_EXPORTED = 2
    fun checkSelfPermission(c: Context, p: String) = android.content.pm.PackageManager.PERMISSION_GRANTED
    fun registerReceiver(c: Context, r: BroadcastReceiver, f: IntentFilter, flags: Int): Intent? = null
}
object FileProvider {
    fun getUriForFile(c: Context, authority: String, f: java.io.File) = android.net.Uri.fromFile(f)
}
