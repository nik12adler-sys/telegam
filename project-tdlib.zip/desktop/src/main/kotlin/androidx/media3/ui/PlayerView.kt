package androidx.media3.ui
class PlayerView(@Suppress("UNUSED_PARAMETER") c: android.content.Context) {
    var player: androidx.media3.common.Player? = null
    var useController: Boolean = true
}
