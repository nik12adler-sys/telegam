package androidx.media3.exoplayer
import androidx.media3.common.*
/** Desktop stub: no video playback yet (D4 will add VLC/JavaFX backend). */
class ExoPlayer private constructor() : Player {
    override var repeatMode = 0
    override var volume = 1f
    override var playWhenReady = false
    override fun setMediaItem(i: MediaItem) {}
    override fun prepare() {}
    override fun play() {}
    override fun pause() {}
    override fun release() {}
    class Builder(@Suppress("UNUSED_PARAMETER") c: android.content.Context) { fun build(): ExoPlayer = ExoPlayer() }
}
