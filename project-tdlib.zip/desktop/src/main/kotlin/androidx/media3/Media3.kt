package androidx.media3.common
class MediaItem private constructor(val uri: String) {
    companion object {
        fun fromUri(u: String) = MediaItem(u)
        fun fromUri(u: android.net.Uri) = MediaItem(u.toString())
    }
}
interface Player {
    companion object { const val REPEAT_MODE_ALL = 2; const val REPEAT_MODE_ONE = 1; const val REPEAT_MODE_OFF = 0 }
    var repeatMode: Int
    var volume: Float
    var playWhenReady: Boolean
    fun setMediaItem(i: MediaItem)
    fun prepare()
    fun play()
    fun pause()
    fun release()
}
