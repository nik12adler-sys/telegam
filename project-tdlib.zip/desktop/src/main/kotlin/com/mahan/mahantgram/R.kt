package com.mahan.mahantgram

/** Desktop stand-in for the generated Android R class. Ids map to classpath resources. */
object R {
    object drawable {
        const val car_gtr_small = 1
        const val ic_launcher_foreground = 2
    }
    object layout { const val looping_player_zoom = 3 }

    fun path(id: Int): String = when (id) {
        drawable.car_gtr_small -> "car_gtr_small.png"
        drawable.ic_launcher_foreground -> "ic_launcher_foreground.png"
        else -> error("unknown resource $id")
    }
}
