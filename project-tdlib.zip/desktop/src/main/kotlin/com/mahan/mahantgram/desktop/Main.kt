package com.mahan.mahantgram.desktop

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import androidx.compose.ui.platform.DesktopActivity
import com.mahan.mahantgram.*
import java.io.File

/** Loads libtdjni.so that the CI build bundles next to the app (or from ./native when running from Gradle). */
private fun loadTdlib() {
    val res = System.getProperty("compose.application.resources.dir")
    val candidates = listOfNotNull(
        res?.let { File(it, "libtdjni.so") },
        File("resources-native/linux-x64/libtdjni.so"),
        File("native/libtdjni.so"),
    )
    val lib = candidates.firstOrNull { it.exists() }
    if (lib != null) System.load(lib.absolutePath)
    else System.err.println("libtdjni.so not found; TDLib will fail to start (demo mode only)")
}

fun main() {
    loadTdlib()
    val ctx = DesktopActivity
    val prefs = ctx.getSharedPreferences("mahan", android.content.Context.MODE_PRIVATE)
    Accent.color = Color(prefs.getInt("accent", 0xFF22D17B.toInt()))
    Accounts.init(ctx)
    AppPrefs.init(ctx)
    AppLock.init(ctx)
    CategoryStore.init(ctx)
    Vault.init(ctx)
    Transfers.init()
    Td.start(ctx)
    Vault.onAppStart()
    AppLock.onStart()

    application {
        Window(
            onCloseRequest = {
                Vault.onAppExit()
                exitApplication()
            },
            title = "MahanTgram",
            state = rememberWindowState(size = DpSize(460.dp, 900.dp)),
        ) {
            MahanApp(prefs)
            AppLockOverlay()
        }
    }
}
