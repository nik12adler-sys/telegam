package com.airbnb.lottie.compose
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
/** Desktop stub: animated stickers render as empty for now (D4: Compottie). */
class LottieComposition
sealed class LottieCompositionSpec {
    class JsonString(val json: String) : LottieCompositionSpec()
    class Url(val url: String) : LottieCompositionSpec()
    class RawRes(val id: Int) : LottieCompositionSpec()
}
object LottieConstants { const val IterateForever = Int.MAX_VALUE }
@Composable
fun rememberLottieComposition(spec: LottieCompositionSpec): State<LottieComposition?> = remember { mutableStateOf<LottieComposition?>(null) }
@Composable
fun LottieAnimation(composition: LottieComposition?, modifier: Modifier = Modifier, iterations: Int = 1) {}
@Composable
fun LottieAnimation(composition: LottieComposition?, progress: () -> Float, modifier: Modifier = Modifier) {}
