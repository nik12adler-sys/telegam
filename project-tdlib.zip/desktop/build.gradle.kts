import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    id("org.jetbrains.kotlin.jvm")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.compose")
}

// Desktop (Kali / any Debian-based Linux) build of MahanTgram.
// It compiles the SAME sources as the Android app (app/src/main/java) plus a small
// "shim" layer (desktop/src/main/kotlin) that fakes the few android.* APIs the code uses.
kotlin { jvmToolchain(17) }

kotlin.sourceSets["main"].kotlin.apply {
    srcDir("../app/src/main/java")
    exclude("**/MainActivity.kt")   // Android entry point; desktop has its own Main.kt
}
java.sourceSets["main"].java.srcDir("../app/src/main/java")

val tgApiId = System.getenv("TG_API_ID")?.trim()?.toIntOrNull() ?: 0
val tgApiHash = System.getenv("TG_API_HASH")?.trim() ?: ""

// Generates BuildConfig for desktop (same names as the Android one).
val genBuildConfig by tasks.registering {
    val outDir = layout.buildDirectory.dir("generated/buildconfig")
    outputs.dir(outDir)
    doLast {
        val f = outDir.get().asFile.resolve("com/mahan/mahantgram/BuildConfig.kt")
        f.parentFile.mkdirs()
        f.writeText(
            """
            package com.mahan.mahantgram
            object BuildConfig {
                const val TG_API_ID: Int = $tgApiId
                const val TG_API_HASH: String = "$tgApiHash"
                const val VERSION_NAME: String = "0.2.0"
            }
            """.trimIndent()
        )
    }
}
kotlin.sourceSets["main"].kotlin.srcDir(genBuildConfig)

dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation(compose.materialIconsExtended)
    implementation("dev.chrisbanes.haze:haze:1.6.10")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.9.0")
    // TDLib Java classes (org.drinkless.tdlib.*) built from source in CI -> desktop/libs/
    implementation(fileTree("libs") { include("*.jar") })
}

compose.desktop {
    application {
        mainClass = "com.mahan.mahantgram.desktop.MainKt"
        // libtdjni.so is placed next to the app by the CI build (see workflow)
        jvmArgs += listOf("-Xmx1g", "-Dfile.encoding=UTF-8")
        nativeDistributions {
            targetFormats(TargetFormat.Deb)
            packageName = "mahantgram"
            packageVersion = "0.2.0"
            description = "MahanTgram desktop"
            linux {
                debMaintainer = "mahan@localhost"
                menuGroup = "Network"
                appCategory = "Network"
            }
            appResourcesRootDir.set(project.layout.projectDirectory.dir("resources-native"))
        }
    }
}

// Copy the two images the shared code loads through R.drawable into desktop classpath resources.
tasks.processResources {
    from("../app/src/main/res/drawable-nodpi") { include("car_gtr_small.png") }
    from("../app/src/main/res/drawable-xxxhdpi") { include("ic_launcher_foreground.png") }
}
