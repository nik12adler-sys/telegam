package com.mahan.mahantgram

import android.content.Context
import android.media.MediaMetadataRetriever
import androidx.compose.runtime.mutableStateMapOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.drinkless.tdlib.TdApi

private fun Any?.fo(name: String): Any? = this?.fieldOrNull(name)

private fun inputLocal(path: String): TdApi.Object = mk("InputFileLocal", "path" to path)
private fun inputId(id: Int): TdApi.Object = mk("InputFileId", "id" to id)

// ====================================================================== upload / download progress

/** Live upload and download progress (0..1) per TDLib file id, fed by UpdateFile. */
object Transfers {
    val progress = mutableStateMapOf<Int, Float>()
    private var started = false

    fun init() {
        if (started) return
        started = true
        Td.listeners.add { o ->
            if (o is TdApi.UpdateFile) {
                val f = o.file
                val p: Float? = when {
                    f.remote.isUploadingActive && f.size > 0 -> f.remote.uploadedSize.toFloat() / f.size
                    f.local.isDownloadingActive -> {
                        val total = if (f.expectedSize > 0) f.expectedSize else f.size
                        if (total > 0) f.local.downloadedSize.toFloat() / total else null
                    }
                    else -> null
                }
                val id = f.id
                Td.main.post { if (p == null) progress.remove(id) else progress[id] = p.coerceIn(0f, 1f) }
            }
        }
    }
}

// ====================================================================== errors

/** Turns raw Telegram / TDLib error text into something a person can act on. */
fun friendlyError(raw: String): String {
    val e = raw.lowercase()
    return when {
        "too many requests" in e -> {
            val n = Regex("retry after (\\d+)").find(e)?.groupValues?.get(1)
            if (n != null) tr("تعداد درخواست‌ها زیاد است؛ $n ثانیه دیگر دوباره امتحان کن.", "Too many requests. Try again in $n s.")
            else tr("تعداد درخواست‌ها زیاد است؛ کمی بعد دوباره امتحان کن.", "Too many requests. Try again shortly.")
        }
        "have no rights" in e || "not enough rights" in e || "chat_write_forbidden" in e ->
            tr("اجازه‌ی ارسال در این گفتگو را نداری.", "You don't have permission to send here.")
        "message is too long" in e || "message_too_long" in e ->
            tr("پیام بیش از حد طولانی است.", "The message is too long.")
        "message text is empty" in e || "message_empty" in e -> tr("پیام خالی است.", "The message is empty.")
        "file is too big" in e || "file_too_big" in e || "too big" in e ->
            tr("حجم فایل از حد مجاز تلگرام بیشتر است.", "The file is larger than Telegram allows.")
        "network" in e || "timeout" in e || "connection" in e ->
            tr("اتصال اینترنت برقرار نیست. پیام در صف می‌ماند و بعداً ارسال می‌شود.", "No connection. The message stays queued and is sent later.")
        "flood" in e -> tr("ارسال بیش از حد سریع است؛ کمی صبر کن.", "You're sending too fast. Please wait a bit.")
        "blocked" in e || "user_is_blocked" in e -> tr("این کاربر تو را مسدود کرده است.", "This user has blocked you.")
        else -> raw
    }
}

const val MAX_UPLOAD_BYTES = 2_000_000_000L // Telegram's limit for non-premium accounts (2 GB)

// ====================================================================== text

private fun cutIndex(s: String, max: Int = 4000): Int {
    if (s.length <= max) return s.length
    val window = s.substring(0, max)
    for (sep in listOf("\n\n", "\n", ". ", " ")) {
        val i = window.lastIndexOf(sep)
        if (i > max / 2) return i + sep.length
    }
    return if (Character.isHighSurrogate(s[max - 1])) max - 1 else max
}

/** Sends text of any length: Telegram's limit is 4096 characters, longer text goes out as several messages in order. */
suspend fun Td.sendLongText(chatId: Long, text: String, replyTo: Long = 0): String? {
    var rest = text.trim()
    var reply = replyTo
    while (rest.isNotEmpty()) {
        val cut = cutIndex(rest)
        val part = rest.substring(0, cut).trim()
        rest = rest.substring(cut).trimStart()
        if (part.isEmpty()) continue
        val err = sendText(chatId, part, reply)
        if (err != null) return err
        reply = 0
    }
    return null
}

// ====================================================================== media

private fun audioMeta(path: String): Triple<String, String, Int> = runCatching {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(path)
        Triple(
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: "",
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: "",
            ((r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000).toInt(),
        )
    } finally {
        r.release()
    }
}.getOrDefault(Triple("", "", 0))

suspend fun Td.sendAudio(chatId: Long, path: String, replyTo: Long = 0): String? {
    val (title, artist, secs) = withContext(Dispatchers.IO) { audioMeta(path) }
    return send(
        chatId,
        mk(
            "InputMessageAudio", "audio" to inputLocal(path), "duration" to secs,
            "title" to title, "performer" to artist, "caption" to ft(""),
        ),
        replyTo,
    )
}

suspend fun Td.sendLocation(chatId: Long, lat: Double, lon: Double, accuracy: Double, replyTo: Long = 0): String? =
    send(
        chatId,
        mk(
            "InputMessageLocation",
            "location" to mk<TdApi.Object>("Location", "latitude" to lat, "longitude" to lon, "horizontalAccuracy" to accuracy),
            "livePeriod" to 0, "heading" to 0, "proximityAlertRadius" to 0,
        ),
        replyTo,
    )

suspend fun Td.sendContact(chatId: Long, phone: String, first: String, last: String, userId: Long = 0, replyTo: Long = 0): String? =
    send(
        chatId,
        mk(
            "InputMessageContact",
            "contact" to mk<TdApi.Object>(
                "Contact", "phoneNumber" to phone, "firstName" to first, "lastName" to last, "vcard" to "", "userId" to userId,
            ),
        ),
        replyTo,
    )

/** Retries a message whose sending failed (only valid when TDLib says canRetry). */
suspend fun Td.resend(chatId: Long, id: Long): String? =
    tryReq(mk("ResendMessages", "chatId" to chatId, "messageIds" to longArrayOf(id)))

// ====================================================================== stickers

class PanelSticker(val fileId: Int, val previewFile: TdApi.File?, val width: Int, val height: Int, val emoji: String)
class PanelSet(val id: Long, val title: String, val cover: TdApi.File?)
class PanelGif(
    val fileId: Int, val previewFile: TdApi.File?, val width: Int, val height: Int, val duration: Int,
    val resultId: String = "", val queryId: Long = 0L,
)

private fun previewOf(sticker: Any?): TdApi.File? {
    val format = sticker.fo("format")
    val main = sticker.fo("sticker") as? TdApi.File
    val thumb = sticker.fo("thumbnail").fo("file") as? TdApi.File
    // A webp sticker is its own preview; animated / video stickers use their static thumbnail.
    return if (format is TdApi.StickerFormatWebp) main else (thumb ?: main)
}

private fun toSticker(o: Any?): PanelSticker? {
    val f = o.fo("sticker") as? TdApi.File ?: return null
    return PanelSticker(
        f.id, previewOf(o), (o.fo("width") as? Number)?.toInt() ?: 512,
        (o.fo("height") as? Number)?.toInt() ?: 512, (o.fo("emoji") as? String) ?: "",
    )
}

object StickerRepo {
    private suspend fun list(name: String, vararg f: Pair<String, Any?>): List<PanelSticker> = try {
        (Td.req(mk(name, *f)).fo("stickers") as? Array<*>)?.mapNotNull { toSticker(it) } ?: emptyList()
    } catch (e: TdException) {
        emptyList()
    }

    suspend fun recent() = list("GetRecentStickers", "isAttached" to false)
    suspend fun favorites() = list("GetFavoriteStickers")
    suspend fun inSet(setId: Long) = list("GetStickerSet", "setId" to setId)

    suspend fun sets(): List<PanelSet> = try {
        val r = Td.req(mk("GetInstalledStickerSets", "stickerType" to mk<TdApi.Object>("StickerTypeRegular")))
        (r.fo("sets") as? Array<*>)?.mapNotNull { s ->
            val id = (s.fo("id") as? Long) ?: return@mapNotNull null
            val cover = (s.fo("thumbnail").fo("file") as? TdApi.File)
                ?: (s.fo("covers") as? Array<*>)?.firstOrNull()?.let { previewOf(it) }
            PanelSet(id, (s.fo("title") as? String) ?: "", cover)
        } ?: emptyList()
    } catch (e: TdException) {
        emptyList()
    }

    /** Installs a pack from its name or t.me/addstickers link. Returns an error message or null. */
    suspend fun addSet(raw: String): String? {
        val name = raw.trim().substringAfterLast('/').substringBefore('?').removePrefix("@")
        if (name.isEmpty()) return tr("نام یا لینک پک را وارد کن", "Enter a pack name or link")
        return try {
            val set = Td.req(mk("SearchStickerSet", "name" to name, "ignoreCache" to false))
            val id = set.fo("id") as? Long ?: return tr("پک پیدا نشد", "Pack not found")
            Td.tryReq(mk("ChangeStickerSet", "setId" to id, "isInstalled" to true, "isArchived" to false))
        } catch (e: TdException) {
            e.message ?: "error"
        }
    }

    suspend fun setFavorite(s: PanelSticker, add: Boolean): String? =
        Td.tryReq(mk(if (add) "AddFavoriteSticker" else "RemoveFavoriteSticker", "sticker" to inputId(s.fileId)))
}

suspend fun Td.sendSticker(chatId: Long, s: PanelSticker, replyTo: Long = 0): String? =
    send(
        chatId,
        mk("InputMessageSticker", "sticker" to inputId(s.fileId), "width" to s.width, "height" to s.height, "emoji" to s.emoji),
        replyTo,
    )

// ====================================================================== GIFs

object GifRepo {
    private var botId = 0L

    private fun toGif(a: Any?, resultId: String = "", queryId: Long = 0L): PanelGif? {
        val f = a.fo("animation") as? TdApi.File ?: return null
        return PanelGif(
            f.id, a.fo("thumbnail").fo("file") as? TdApi.File,
            (a.fo("width") as? Number)?.toInt() ?: 0, (a.fo("height") as? Number)?.toInt() ?: 0,
            (a.fo("duration") as? Number)?.toInt() ?: 0, resultId, queryId,
        )
    }

    /** The user's own saved GIFs. */
    suspend fun saved(): List<PanelGif> = try {
        (Td.req(mk("GetSavedAnimations")).fo("animations") as? Array<*>)?.mapNotNull { toGif(it) } ?: emptyList()
    } catch (e: TdException) {
        emptyList()
    }

    private suspend fun bot(): Long? {
        if (botId != 0L) return botId
        return try {
            val chat = Td.req(mk("SearchPublicChat", "username" to "gif")) as TdApi.Chat
            (chat.type as? TdApi.ChatTypePrivate)?.userId?.also { botId = it }
        } catch (e: TdException) {
            null
        }
    }

    /** Trending (empty query) or searched GIFs, from Telegram's official @gif bot. */
    suspend fun search(chatId: Long, query: String): List<PanelGif> {
        val b = bot() ?: return emptyList()
        return try {
            val r = Td.req(mk("GetInlineQueryResults", "botUserId" to b, "chatId" to chatId, "query" to query, "offset" to ""))
            val qid = (r.fo("inlineQueryId") as? Long) ?: 0L
            (r.fo("results") as? Array<*>)?.mapNotNull { x -> toGif(x.fo("animation"), (x.fo("id") as? String) ?: "", qid) } ?: emptyList()
        } catch (e: TdException) {
            emptyList()
        }
    }
}

suspend fun Td.sendGif(chatId: Long, g: PanelGif, replyTo: Long = 0): String? {
    if (g.resultId.isNotEmpty()) {
        val fields = mutableListOf<Pair<String, Any?>>(
            "chatId" to chatId, "queryId" to g.queryId, "resultId" to g.resultId, "hideViaBot" to true,
        )
        if (replyTo != 0L) fields.add("replyTo" to mk<TdApi.Object>("InputMessageReplyToMessage", "messageId" to replyTo))
        return tryReq(mk("SendInlineQueryResultMessage", *fields.toTypedArray()))
    }
    return send(
        chatId,
        mk(
            "InputMessageAnimation", "animation" to inputId(g.fileId), "duration" to g.duration,
            "width" to g.width, "height" to g.height, "caption" to ft(""),
        ),
        replyTo,
    )
}

// ====================================================================== emoji

object EmojiStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("emoji", Context.MODE_PRIVATE)

    fun recent(ctx: Context): List<String> =
        prefs(ctx).getString("recent", "")!!.split(' ').filter { it.isNotEmpty() }

    fun push(ctx: Context, e: String) {
        val list = (listOf(e) + recent(ctx).filter { it != e }).take(30)
        prefs(ctx).edit().putString("recent", list.joinToString(" ")).apply()
    }

    /** Emoji search through TDLib, so it follows Telegram's own keywords in the person's languages. */
    suspend fun search(text: String): List<String> = try {
        val r = Td.req(mk("SearchEmojis", "text" to text, "inputLanguageCodes" to arrayOf("fa", "en")))
        (r.fo("emojis") as? Array<*>)?.filterIsInstance<String>() ?: emptyList()
    } catch (e: TdException) {
        emptyList()
    }
}
