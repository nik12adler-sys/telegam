@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mahan.mahantgram

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun CategoryChip(text: String, selected: Boolean, onClick: () -> Unit, onLongClick: (() -> Unit)? = null) {
    val c = LocalMahan.current
    Box(
        Modifier
            .clip(CircleShape)
            .background(if (selected) Green else c.glassTint.copy(alpha = 0.45f))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    ) {
        Text(text, color = if (selected) Color.Black else c.text, fontSize = 14.sp, maxLines = 1)
    }
}

/** Horizontal category bar. Tap = select, long press = rename / delete, "+" = new category. */
@Composable
fun CategoryBar() {
    val c = LocalMahan.current
    val cats = CategoryStore.categories
    val selId = CategoryStore.selectedId
    var menuFor by remember { mutableStateOf<ChatCategory?>(null) }
    var renameFor by remember { mutableStateOf<ChatCategory?>(null) }
    var deleteFor by remember { mutableStateOf<ChatCategory?>(null) }
    var creating by remember { mutableStateOf(false) }

    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (cat in cats) {
            CategoryChip(
                text = CategoryStore.label(cat),
                selected = cat.id == selId,
                onClick = { CategoryStore.select(cat.id) },
                onLongClick = { menuFor = cat },
            )
        }
        Box(
            Modifier.clip(CircleShape).background(c.glassTint.copy(alpha = 0.45f))
                .clickable { creating = true }.padding(horizontal = 10.dp, vertical = 8.dp),
        ) { Icon(Icons.Rounded.Add, tr("دسته جدید", "New category"), tint = c.text, modifier = Modifier.size(20.dp)) }
    }

    menuFor?.let { cat ->
        AlertDialog(
            onDismissRequest = { menuFor = null },
            title = { Text(CategoryStore.label(cat), maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    TextButton(onClick = { renameFor = cat; menuFor = null }, modifier = Modifier.fillMaxWidth()) {
                        Text(tr("تغییر نام", "Rename"))
                    }
                    if (cat.id != CategoryStore.ALL) {
                        TextButton(onClick = { deleteFor = cat; menuFor = null }, modifier = Modifier.fillMaxWidth()) {
                            Text(tr("حذف دسته", "Delete category"), color = Color(0xFFFF5A5F))
                        }
                    }
                    if (CategoryStore.missingDefaults()) {
                        TextButton(
                            onClick = { CategoryStore.restoreDefaults(); menuFor = null },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(tr("بازگردانی دسته‌های پیش‌فرض", "Restore default categories")) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { menuFor = null }) { Text(tr("بستن", "Close")) } },
        )
    }
    renameFor?.let { cat ->
        CategoryNameDialog(
            title = tr("تغییر نام دسته", "Rename category"),
            initial = CategoryStore.label(cat),
            onDismiss = { renameFor = null },
            onConfirm = { CategoryStore.rename(cat.id, it); renameFor = null },
        )
    }
    deleteFor?.let { cat ->
        AlertDialog(
            onDismissRequest = { deleteFor = null },
            title = { Text(tr("حذف دسته", "Delete category")) },
            text = {
                Text(
                    tr(
                        "«${CategoryStore.label(cat)}» حذف شود؟ گفتگوها از تلگرام پاک نمی‌شوند.",
                        "Delete “${CategoryStore.label(cat)}”? Your chats are not deleted from Telegram.",
                    ),
                )
            },
            confirmButton = {
                TextButton(onClick = { CategoryStore.delete(cat.id); deleteFor = null }) {
                    Text(tr("حذف", "Delete"), color = Color(0xFFFF5A5F))
                }
            },
            dismissButton = { TextButton(onClick = { deleteFor = null }) { Text(tr("لغو", "Cancel")) } },
        )
    }
    if (creating) {
        CategoryNameDialog(
            title = tr("دسته جدید", "New category"),
            initial = "",
            onDismiss = { creating = false },
            onConfirm = {
                CategoryStore.create(it)?.let { id -> CategoryStore.select(id) }
                creating = false
            },
        )
    }
}

@Composable
fun CategoryNameDialog(title: String, initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { InputField(name, { name = it.take(24) }, tr("نام دسته", "Category name"), Modifier.fillMaxWidth()) },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = { onConfirm(name) }) { Text(tr("تأیید", "OK")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}

/** Long press on a chat: tick the custom categories this chat belongs to (several are allowed). */
@Composable
fun ChatCategoryDialog(chat: UiChat, onDismiss: () -> Unit, onMoveToVault: (() -> Unit)? = null) {
    val c = LocalMahan.current
    val custom = CategoryStore.categories.filter { !it.builtin }
    var creating by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (chat.saved) tr("پیام‌های ذخیره‌شده", "Saved Messages") else chat.title,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        },
        text = {
            Column {
                Text(tr("افزودن به دسته", "Add to category"), color = c.subtext, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                if (custom.isEmpty()) {
                    Text(tr("هنوز دسته‌ای نساخته‌ای.", "You have no custom categories yet."), color = c.text)
                }
                for (cat in custom) {
                    val on = chat.id in cat.chatIds
                    Row(
                        Modifier.fillMaxWidth().clickable { CategoryStore.toggleChat(cat.id, chat.id) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = on, onCheckedChange = { CategoryStore.toggleChat(cat.id, chat.id) })
                        Text(cat.name, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                TextButton(onClick = { creating = true }) { Text(tr("+ دسته جدید", "+ New category")) }
                if (onMoveToVault != null) {
                    TextButton(onClick = onMoveToVault, modifier = Modifier.fillMaxWidth()) {
                        Text(tr("انتقال به اجی‌مجی", "Move to AjiMaji"))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("تمام", "Done")) } },
    )
    if (creating) {
        CategoryNameDialog(
            title = tr("دسته جدید", "New category"),
            initial = "",
            onDismiss = { creating = false },
            onConfirm = {
                CategoryStore.create(it)?.let { id -> CategoryStore.toggleChat(id, chat.id) }
                creating = false
            },
        )
    }
}
