@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mahan.mahantgram

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Danger = Color(0xFFFF5A5F)

// ------------------------------------------------------------------ small building blocks

@Composable
private fun VaultPasswordField(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    isError: Boolean = false,
) {
    val c = LocalMahan.current
    var visible by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier
            .height(52.dp)
            .clip(shape)
            .background(c.glassTint.copy(alpha = 0.5f))
            .border(1.dp, if (isError) Danger else c.glassBorder, shape)
            .padding(start = 14.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = c.text, fontSize = 16.sp),
            cursorBrush = SolidColor(Green),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) Text(hint, color = c.subtext, fontSize = 16.sp)
                    inner()
                }
            },
        )
        Box(
            Modifier.size(40.dp).clip(CircleShape).clickable { visible = !visible },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (visible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                if (visible) tr("مخفی کردن رمز", "Hide password") else tr("نمایش رمز", "Show password"),
                tint = c.subtext,
            )
        }
    }
}

@Composable
private fun LockBadge(open: Boolean = false) {
    Box(
        Modifier.size(84.dp).clip(CircleShape)
            .background(Green.copy(alpha = 0.18f))
            .border(1.dp, Green.copy(alpha = 0.5f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Icon(if (open) Icons.Rounded.LockOpen else Icons.Rounded.Lock, null, tint = Green, modifier = Modifier.size(40.dp))
    }
}

@Composable
private fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(16.dp))
            .background(if (enabled) Green else Green.copy(alpha = 0.35f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = Color.Black, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun RoundIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    val c = LocalMahan.current
    Box(
        Modifier.size(42.dp).clip(CircleShape)
            .background(c.glassTint.copy(alpha = 0.5f))
            .border(1.dp, c.glassBorder, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, tint = c.text, modifier = Modifier.size(22.dp)) }
}

@Composable
private fun rememberNow(): Long {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Vault.lockUntil) {
        while (true) {
            now = System.currentTimeMillis()
            if (Vault.lockUntil <= now) break
            delay(500)
        }
    }
    return now
}

// ------------------------------------------------------------------ password creation

@Composable
private fun SetupForm(unlockAfter: Boolean, onCreated: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val issue = if (pw.isEmpty()) null else Vault.passwordIssue(pw)
    val mismatch = pw2.isNotEmpty() && pw != pw2
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        VaultPasswordField(pw, { pw = it }, tr("رمز عبور", "Password"), Modifier.fillMaxWidth(), isError = issue != null)
        VaultPasswordField(pw2, { pw2 = it }, tr("تکرار رمز", "Repeat password"), Modifier.fillMaxWidth(), isError = mismatch)
        (issue ?: if (mismatch) tr("رمزها یکسان نیستند", "Passwords do not match") else null)?.let {
            Text(it, color = Danger, fontSize = 13.sp)
        }
        PrimaryButton(
            tr("ایجاد رمز", "Create password"),
            enabled = !busy && pw.isNotEmpty() && issue == null && pw == pw2,
        ) {
            busy = true
            scope.launch {
                val ok = Vault.setup(pw, unlockAfter)
                busy = false
                if (ok) onCreated() else toast(ctx, tr("ذخیره‌ی رمز ناموفق بود", "Could not save the password"))
            }
        }
    }
}

@Composable
private fun SetupScreen(onBack: () -> Unit) {
    val c = LocalMahan.current
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(Modifier.fillMaxWidth()) { BackButton(onBack) }
        Spacer(Modifier.height(10.dp))
        LockBadge()
        Text(tr("رمز اجی‌مجی را تعیین کن", "Set your AjiMaji password"), color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(
            tr(
                "گفتگوهای مخفی‌شده فقط با این رمز دیده می‌شوند. رمز بازیابی ندارد؛ اگر آن را فراموش کنی، تنها راه، خروج از حساب تلگرام است.",
                "Hidden chats can only be seen with this password. It can't be recovered; if you forget it, the only way back is logging out of Telegram.",
            ),
            color = c.subtext, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 22.sp,
        )
        SetupForm(unlockAfter = true) {}
    }
}

/** Used from the public chat list: create the password, then hide. */
@Composable
private fun SetupDialog(onDismiss: () -> Unit, onCreated: () -> Unit) {
    val c = LocalMahan.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("رمز اجی‌مجی", "AjiMaji password")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    tr("برای مخفی کردن گفتگو اول یک رمز تعیین کن.", "Set a password first to hide chats."),
                    color = c.subtext, fontSize = 13.sp,
                )
                SetupForm(unlockAfter = false, onCreated = onCreated)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel")) } },
    )
}

// ------------------------------------------------------------------ password entry

@Composable
fun VaultPasswordDialog(title: String, onDismiss: () -> Unit, onVerified: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pw by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val now = rememberNow()
    val wait = ((Vault.lockUntil - now + 999) / 1000).coerceAtLeast(0)
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                VaultPasswordField(pw, { pw = it; wrong = false }, tr("رمز اجی‌مجی", "AjiMaji password"), Modifier.fillMaxWidth(), isError = wrong)
                if (wait > 0) {
                    Text(tr("تلاش‌های ناموفق زیاد بود. $wait ثانیه دیگر دوباره امتحان کن.", "Too many attempts. Try again in $wait s."), color = Danger, fontSize = 13.sp)
                } else if (wrong) {
                    Text(tr("رمز اشتباه است", "Wrong password"), color = Danger, fontSize = 13.sp)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy && pw.isNotEmpty() && wait == 0L,
                onClick = {
                    busy = true
                    scope.launch {
                        when (Vault.verify(pw)) {
                            Vault.Result.OK -> onVerified()
                            Vault.Result.WRONG -> { wrong = true; pw = "" }
                            Vault.Result.LOCKED_OUT -> pw = ""
                            Vault.Result.ERROR -> toast(ctx, tr("خطا", "Error"))
                        }
                        busy = false
                    }
                },
            ) { Text(tr("تأیید", "OK")) }
        },
        dismissButton = { TextButton(onClick = { if (!busy) onDismiss() }) { Text(tr("لغو", "Cancel")) } },
    )
}

@Composable
private fun UnlockScreen(onBack: () -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pw by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var forgot by remember { mutableStateOf(false) }
    val now = rememberNow()
    val wait = ((Vault.lockUntil - now + 999) / 1000).coerceAtLeast(0)

    fun submit() {
        if (busy || pw.isEmpty() || wait > 0) return
        busy = true
        scope.launch {
            when (Vault.unlock(pw)) {
                Vault.Result.OK -> Unit
                Vault.Result.WRONG -> { wrong = true; pw = "" }
                Vault.Result.LOCKED_OUT -> pw = ""
                Vault.Result.ERROR -> toast(ctx, tr("خطا", "Error"))
            }
            busy = false
        }
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(Modifier.fillMaxWidth()) { BackButton(onBack) }
        Spacer(Modifier.height(10.dp))
        LockBadge()
        Text(tr("اجی‌مجی", "AjiMaji"), color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(tr("برای ورود رمز را وارد کن", "Enter your password to continue"), color = c.subtext, fontSize = 14.sp)
        VaultPasswordField(pw, { pw = it; wrong = false }, tr("رمز عبور", "Password"), Modifier.fillMaxWidth(), isError = wrong)
        if (wait > 0) {
            Text(
                tr("تلاش‌های ناموفق زیاد بود. $wait ثانیه دیگر دوباره امتحان کن.", "Too many attempts. Try again in $wait s."),
                color = Danger, fontSize = 13.sp, textAlign = TextAlign.Center,
            )
        } else if (wrong) {
            Text(tr("رمز اشتباه است", "Wrong password"), color = Danger, fontSize = 13.sp)
        }
        PrimaryButton(tr("ورود", "Unlock"), enabled = !busy && pw.isNotEmpty() && wait == 0L) { submit() }
        TextButton(onClick = { forgot = true }) {
            Text(tr("رمز را فراموش کرده‌ام", "I forgot my password"), color = c.subtext)
        }
    }

    if (forgot) {
        AlertDialog(
            onDismissRequest = { forgot = false },
            title = { Text(tr("بازنشانی اجی‌مجی", "Reset AjiMaji")) },
            text = {
                Text(
                    tr(
                        "رمز قابل بازیابی نیست. برای بازنشانی باید از حساب تلگرام خارج شوی؛ رمز و فهرست مخفی‌ها پاک می‌شود و بعد از ورود دوباره، همه‌ی گفتگوها در فهرست عمومی برمی‌گردند. هیچ گفتگویی از تلگرام حذف نمی‌شود.",
                        "The password can't be recovered. Resetting logs you out of Telegram: the password and hidden list are erased, and after you sign in again every chat is back in the public list. Nothing is deleted from Telegram.",
                    ),
                )
            },
            confirmButton = {
                TextButton(onClick = { forgot = false; Td.logOut() }) {
                    Text(tr("خروج و بازنشانی", "Log out and reset"), color = Danger)
                }
            },
            dismissButton = { TextButton(onClick = { forgot = false }) { Text(tr("لغو", "Cancel")) } },
        )
    }
}

@Composable
private fun CorruptScreen(onBack: () -> Unit) {
    val c = LocalMahan.current
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(Modifier.fillMaxWidth()) { BackButton(onBack) }
        Spacer(Modifier.height(10.dp))
        LockBadge()
        Text(tr("اطلاعات اجی‌مجی خوانده نشد", "AjiMaji data can't be read"), color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(
            tr(
                "کلید رمزنگاری دستگاه از بین رفته است. باید اجی‌مجی بازنشانی شود؛ گفتگوهای مخفی به فهرست عمومی برمی‌گردند و چیزی از تلگرام حذف نمی‌شود.",
                "The device encryption key was lost. AjiMaji must be reset; hidden chats return to the public list and nothing is deleted from Telegram.",
            ),
            color = c.subtext, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 22.sp,
        )
        PrimaryButton(tr("بازنشانی اجی‌مجی", "Reset AjiMaji")) { Vault.wipe() }
    }
}

// ------------------------------------------------------------------ entry from the public list

/** Hide flow used from the public chat list (long press): password creation or check first, then hide. */
@Composable
fun HideToVaultFlow(ids: List<Long>, onDone: () -> Unit) {
    val ctx = LocalContext.current
    fun doHide() {
        val ok = Vault.hide(ids)
        toast(ctx, if (ok) tr("به اجی‌مجی منتقل شد", "Moved to AjiMaji") else tr("ذخیره‌سازی ناموفق بود", "Could not save"))
        onDone()
    }
    when {
        Vault.corrupt -> AlertDialog(
            onDismissRequest = onDone,
            title = { Text(tr("اجی‌مجی", "AjiMaji")) },
            text = { Text(tr("اطلاعات اجی‌مجی خوانده نمی‌شود. از بخش اجی‌مجی آن را بازنشانی کن.", "AjiMaji data can't be read. Reset it from the AjiMaji section.")) },
            confirmButton = { TextButton(onClick = onDone) { Text(tr("باشه", "OK")) } },
        )
        !Vault.configured -> SetupDialog(onDismiss = onDone, onCreated = { doHide() })
        !Vault.unlocked -> VaultPasswordDialog(
            title = tr("رمز اجی‌مجی", "AjiMaji password"),
            onDismiss = onDone,
            onVerified = { doHide() },
        )
        else -> LaunchedEffect(Unit) { doHide() }
    }
}

// ------------------------------------------------------------------ root

@Composable
fun VaultRoot(onBack: () -> Unit, onOpenChat: (Long) -> Unit) {
    when {
        Vault.corrupt -> CorruptScreen(onBack)
        !Vault.configured -> SetupScreen(onBack)
        !Vault.unlocked -> UnlockScreen(onBack)
        else -> VaultHome(onBack, onOpenChat)
    }
}

// ------------------------------------------------------------------ home

@Composable
private fun VaultHome(onBack: () -> Unit, onOpenChat: (Long) -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    var sub by remember { mutableIntStateOf(0) } // 0 = list, 1 = add chats, 2 = security settings
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    val selecting = selected.isNotEmpty()

    BackHandler(enabled = sub != 0 || selecting) {
        if (sub != 0) sub = 0 else selected = emptySet()
    }

    fun toggle(id: Long) {
        selected = if (id in selected) selected - id else selected + id
    }

    Box(Modifier.fillMaxSize()) {
        when (sub) {
            1 -> HidePicker { sub = 0 }
            2 -> VaultSettings { sub = 0 }
            else -> {
                val hidden = Td.allChats.filter { it.id in Vault.hiddenIds }
                val shown = hidden.filter {
                    query.isBlank() || it.title.contains(query, true) || it.last.contains(query, true)
                }
                Column(Modifier.fillMaxSize().statusBarsPadding()) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (selecting) {
                            RoundIcon(Icons.Rounded.Close, tr("لغو انتخاب", "Clear selection")) { selected = emptySet() }
                            Spacer(Modifier.width(12.dp))
                            Text(
                                "${selected.size} " + tr("گفتگو انتخاب شد", "selected"),
                                color = c.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f),
                            )
                            Pill(tr("بازگرداندن به فهرست عمومی", "Restore to chats"), true) {
                                val ok = Vault.restore(selected.toList())
                                toast(ctx, if (ok) tr("به فهرست عمومی برگشت", "Restored to the chat list") else tr("ذخیره‌سازی ناموفق بود", "Could not save"))
                                selected = emptySet()
                            }
                        } else {
                            BackButton(onBack)
                            Spacer(Modifier.width(12.dp))
                            Icon(Icons.Rounded.LockOpen, null, tint = Green, modifier = Modifier.size(24.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                tr("اجی‌مجی", "AjiMaji"),
                                color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f),
                            )
                            RoundIcon(Icons.Rounded.Settings, tr("تنظیمات امنیتی", "Security settings")) { sub = 2 }
                            Spacer(Modifier.width(8.dp))
                            RoundIcon(Icons.Rounded.Lock, tr("قفل کردن", "Lock now")) { Vault.lock() }
                        }
                    }
                    InputField(
                        query, { query = it }, tr("جست‌وجو در گفتگوهای خصوصی", "Search private chats"),
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    )
                    if (shown.isEmpty()) {
                        Column(
                            Modifier.fillMaxWidth().padding(36.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Spacer(Modifier.height(24.dp))
                            LockBadge(open = true)
                            Text(
                                if (hidden.isEmpty()) tr("اجی‌مجی خالی است", "AjiMaji is empty") else tr("نتیجه‌ای پیدا نشد", "No results"),
                                color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                            )
                            if (hidden.isEmpty()) {
                                Text(
                                    tr(
                                        "با دکمه‌ی + گفتگوهایی را که می‌خواهی از فهرست اصلی مخفی شوند اینجا بیاور.",
                                        "Tap + to move chats here and keep them out of the main list.",
                                    ),
                                    color = c.subtext, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 22.sp,
                                )
                            }
                        }
                    } else {
                        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 6.dp, bottom = 110.dp)) {
                            items(shown, key = { it.id }) { ch ->
                                val on = ch.id in selected
                                Row(
                                    Modifier.fillMaxWidth().background(if (on) Green.copy(alpha = 0.12f) else Color.Transparent),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    if (selecting) {
                                        Checkbox(checked = on, onCheckedChange = { toggle(ch.id) }, modifier = Modifier.padding(start = 8.dp))
                                    }
                                    Box(Modifier.weight(1f)) {
                                        LiveChatRow(ch, onLongClick = { toggle(ch.id) }) {
                                            if (selecting) toggle(ch.id) else onOpenChat(ch.id)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (!selecting) {
                    Box(
                        Modifier
                            .align(Alignment.BottomEnd)
                            .navigationBarsPadding()
                            .padding(20.dp)
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(Green)
                            .clickable { sub = 1 },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.Add, tr("افزودن گفتگو", "Add chats"), tint = Color.Black) }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ add chats (multi-select)

private fun pickerMatches(filter: String, ch: UiChat): Boolean = when (filter) {
    "personal" -> ch.kind == ChatKind.PRIVATE && !ch.bot
    "groups" -> ch.kind == ChatKind.GROUP
    "channels" -> ch.kind == ChatKind.CHANNEL
    "bots" -> ch.bot
    else -> true
}

@Composable
private fun HidePicker(onClose: () -> Unit) {
    val c = LocalMahan.current
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("all") }
    var picked by remember { mutableStateOf(setOf<Long>()) }
    // Td.chats is the public list: chats that are already hidden are not offered again.
    val list = Td.chats.filter { ch ->
        pickerMatches(filter, ch) && (query.isBlank() || ch.title.contains(query, true))
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BackButton(onClose)
            Spacer(Modifier.width(12.dp))
            Text(tr("افزودن به اجی‌مجی", "Add to AjiMaji"), color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        InputField(query, { query = it }, tr("جست‌وجو", "Search"), Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp))
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Pill(tr("همه", "All"), filter == "all") { filter = "all" }
            Pill(tr("شخصی", "Personal"), filter == "personal") { filter = "personal" }
            Pill(tr("گروه‌ها", "Groups"), filter == "groups") { filter = "groups" }
            Pill(tr("کانال‌ها", "Channels"), filter == "channels") { filter = "channels" }
            Pill(tr("ربات‌ها", "Bots"), filter == "bots") { filter = "bots" }
        }
        if (list.isEmpty()) {
            Text(
                tr("گفتگویی برای افزودن نیست", "No chats to add"),
                color = c.subtext, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().weight(1f).padding(32.dp),
                textAlign = TextAlign.Center,
            )
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(list, key = { it.id }) { ch ->
                    val on = ch.id in picked
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { picked = if (on) picked - ch.id else picked + ch.id }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Avatar(ch.photoFileId, ch.title, 44.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (ch.saved) tr("پیام‌های ذخیره‌شده", "Saved Messages") else ch.title,
                                color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                when {
                                    ch.bot -> tr("ربات", "Bot")
                                    ch.kind == ChatKind.GROUP -> tr("گروه", "Group")
                                    ch.kind == ChatKind.CHANNEL -> tr("کانال", "Channel")
                                    else -> tr("چت شخصی", "Personal chat")
                                },
                                color = c.subtext, fontSize = 13.sp,
                            )
                        }
                        Checkbox(checked = on, onCheckedChange = { picked = if (on) picked - ch.id else picked + ch.id })
                    }
                }
            }
        }
        Box(Modifier.padding(16.dp)) {
            PrimaryButton(
                if (picked.isEmpty()) tr("گفتگویی انتخاب نشده", "Select chats")
                else tr("انتقال ${picked.size} گفتگو به اجی‌مجی", "Move ${picked.size} to AjiMaji"),
                enabled = picked.isNotEmpty(),
            ) {
                val ok = Vault.hide(picked.toList())
                toast(ctx, if (ok) tr("به اجی‌مجی منتقل شد", "Moved to AjiMaji") else tr("ذخیره‌سازی ناموفق بود", "Could not save"))
                if (ok) onClose()
            }
        }
    }
}

// ------------------------------------------------------------------ security settings

@Composable
private fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalMahan.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = c.text, fontSize = 16.sp)
            Text(desc, color = c.subtext, fontSize = 12.sp, lineHeight = 18.sp)
        }
        Spacer(Modifier.width(10.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Green, checkedThumbColor = Color.White),
        )
    }
}

@Composable
private fun ActionRow(text: String, danger: Boolean = false, onClick: () -> Unit) {
    val c = LocalMahan.current
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
            .background(c.glassTint.copy(alpha = 0.4f))
            .clickable(onClick = onClick).padding(16.dp),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = if (danger) Danger else Green, fontSize = 16.sp) }
}

@Composable
private fun VaultSettings(onBack: () -> Unit) {
    val c = LocalMahan.current
    val s = Vault.settings
    var changing by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BackButton(onBack)
            Spacer(Modifier.width(12.dp))
            Text(tr("تنظیمات امنیتی", "Security settings"), color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        GlassCard {
            Text(tr("قفل خودکار بعد از خروج از برنامه", "Auto-lock after leaving the app"), color = c.text, fontSize = 16.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    0 to tr("بلافاصله", "Immediately"),
                    60 to tr("۱ دقیقه", "1 min"),
                    300 to tr("۵ دقیقه", "5 min"),
                    900 to tr("۱۵ دقیقه", "15 min"),
                    -1 to tr("فقط دستی", "Manual only"),
                ).forEach { (sec, label) ->
                    Pill(label, s.lockDelaySec == sec) { Vault.updateSettings(s.copy(lockDelaySec = sec)) }
                }
            }
            Text(
                tr(
                    "با بستن کامل برنامه، اجی‌مجی همیشه قفل می‌شود. انتخاب فایل یا عکس از برنامه‌ی دیگر قفل را فوری نمی‌بندد.",
                    "Closing the app always locks AjiMaji. Picking a file or photo from another app does not lock it right away.",
                ),
                color = c.subtext, fontSize = 12.sp, lineHeight = 18.sp,
            )
        }
        GlassCard {
            SwitchRow(
                tr("قفل با خاموش شدن صفحه", "Lock when the screen turns off"),
                tr("با قفل یا خاموش شدن صفحه، اجی‌مجی فوراً قفل می‌شود.", "AjiMaji locks as soon as the screen locks or turns off."),
                s.lockOnScreenOff,
            ) { Vault.updateSettings(s.copy(lockOnScreenOff = it)) }
        }
        GlassCard {
            SwitchRow(
                tr("محافظت از اسکرین‌شات و برنامه‌های اخیر", "Block screenshots and recents preview"),
                tr("تا وقتی اجی‌مجی باز است، اسکرین‌شات گرفته نمی‌شود و پیش‌نمایش برنامه‌های اخیر خالی است.", "While AjiMaji is open, screenshots are blocked and the recent-apps preview is blank."),
                s.secureScreen,
            ) { Vault.updateSettings(s.copy(secureScreen = it)) }
        }
        ActionRow(tr("تغییر رمز", "Change password")) { changing = true }
        ActionRow(tr("قفل کردن اجی‌مجی", "Lock AjiMaji now"), danger = true) { Vault.lock() }
    }
    if (changing) ChangePasswordDialog { changing = false }
}

@Composable
private fun ChangePasswordDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var old by remember { mutableStateOf("") }
    var n1 by remember { mutableStateOf("") }
    var n2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val issue = when {
        n1.isEmpty() -> null
        n1 == old -> tr("رمز جدید باید با رمز قبلی فرق کند", "The new password must differ from the old one")
        else -> Vault.passwordIssue(n1)
    }
    val mismatch = n2.isNotEmpty() && n1 != n2
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text(tr("تغییر رمز", "Change password")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                VaultPasswordField(old, { old = it; error = null }, tr("رمز فعلی", "Current password"), Modifier.fillMaxWidth(), isError = error != null)
                VaultPasswordField(n1, { n1 = it }, tr("رمز جدید", "New password"), Modifier.fillMaxWidth(), isError = issue != null)
                VaultPasswordField(n2, { n2 = it }, tr("تکرار رمز جدید", "Repeat new password"), Modifier.fillMaxWidth(), isError = mismatch)
                (issue ?: error ?: if (mismatch) tr("رمزها یکسان نیستند", "Passwords do not match") else null)?.let {
                    Text(it, color = Danger, fontSize = 13.sp)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy && old.isNotEmpty() && n1.isNotEmpty() && issue == null && n1 == n2,
                onClick = {
                    busy = true
                    scope.launch {
                        when (Vault.changePassword(old, n1)) {
                            Vault.Result.OK -> {
                                toast(ctx, tr("رمز تغییر کرد", "Password changed"))
                                onDismiss()
                            }
                            Vault.Result.WRONG -> { error = tr("رمز فعلی اشتباه است", "Current password is wrong"); old = "" }
                            Vault.Result.LOCKED_OUT -> error = tr("تلاش ناموفق زیاد بود؛ کمی بعد دوباره امتحان کن", "Too many attempts. Try again later")
                            Vault.Result.ERROR -> error = tr("ذخیره‌سازی ناموفق بود", "Could not save")
                        }
                        busy = false
                    }
                },
            ) { Text(tr("ذخیره", "Save")) }
        },
        dismissButton = { TextButton(onClick = { if (!busy) onDismiss() }) { Text(tr("لغو", "Cancel")) } },
    )
}
